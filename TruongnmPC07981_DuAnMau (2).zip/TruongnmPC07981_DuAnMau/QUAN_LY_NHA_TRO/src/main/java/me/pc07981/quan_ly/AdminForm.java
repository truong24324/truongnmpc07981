package me.pc07981.quan_ly;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.Normalizer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 * 24 tiếng Ngày lên dự án đầu tháng 4
 *
 */
public class AdminForm extends javax.swing.JFrame {

    String url = "jdbc:sqlserver://localhost:1433;database=QUAN_LY_HOC_VIEN;integratedSecurity=false;user=sa;password=123;encrypt=true;trustServerCertificate=true;";
    private int height; // Declare height variable at the class level
// Tạo đối tượng Border với màu viền và độ dày mong muốn
    Border border = BorderFactory.createLineBorder(Color.RED, 2);

    public AdminForm() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH); // Phóng to fullscreen
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        txtID_NV.setBackground(new Color(0,0,0,0));
        height = screenSize.height;
        pnlStatic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlThematic.setVisible(false);
        pnlLearner.setVisible(false);
        pnlStatic.setVisible(false);
        pnlStudents.setVisible(false);
        pnlHome.setVisible(true);
        loadTable_CD();
        loadTable_KH();
        loadTable_NGUOI_HOC();
        loadTable_NHAN_VIEN();
        loadComboBoxData_KHOA_HOC();
        clickTable_CHUYEN_DE();
        clickTable_NGUOI_HOC();
        clickTable_NHAN_VIEN();
        clickTable_KHOA_HOC();
        initComboBoxListener();
        loadComboBoxData_HOC_VIEN_KH();
        rdoMale_NH.setSelected(true);
        rdoStaff_NV.setSelected(true);
        loadTable_NGUOIHOC_HV();
        loadComboBoxData_nameCD_HV();
        loadTable_NGUOI_HOC_TK();
        loadTable_CHUYENDE_TK();
        loadComboBoxData_KHOAHOC_THONGKE();
        loadComboBoxData_DOANHTHU_THONGKE();

        txtID_CD.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_CD();
            }
        });

        txtName_CD.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_CD();
            }
        });

        txtTuition_CD.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_CD();
            }
        });

        txtTime_CD.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_CD();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_CD();
            }
        });

        txtID_NH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NH();
            }
        });

        txtName_NH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NH();
            }
        });

        txtBrithday_NH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NH();
            }
        });

        txtPhone_NH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NH();
            }
        });

        txtEmail_NH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NH();
            }
        });

        txtID_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });

        txtUser_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });

        txtDate_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });

        txtOpening_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });
        txtTuition_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });

        txtTime_KH.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_KH();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_KH();
            }
        });

        txtIDStaff_NV.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NV();
            }
        });

        txtName_NV.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NV();
            }
        });

        txtConfirmPass_NV.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NV();
            }
        });

        txtPassword_NV.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInfor_NV();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInfor_NV();
            }
        });

        txtFind_HV.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                find();
            }

            public void removeUpdate(DocumentEvent e) {
                find();
            }

            public void insertUpdate(DocumentEvent e) {
                find();
            }
        });

        txtUser_KH.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy mã nhân viên từ txtUser_KH
                String maNV = txtUser_KH.getText();
                // Truy vấn cơ sở dữ liệu để lấy tên tương ứng với mã nhân viên
                String tenNV = getTenNhanVienFromMaNhanVien(maNV); // Phương thức này cần được xác định
                // Hiển thị tên nhân viên trong txtUser_KH
                txtUser_KH.setText(tenNV);
                if (tenNV == null) {
                    lblErrorUser_KH.setText("Mã nhân viên không tồn tại. Mời bạn nhập lại");
                } else {
                    lblErrorUser_KH.setText("");
                }
            }
        });

        txtDate_KH.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Lấy ngày hiện tại từ cơ sở dữ liệu
                    String currentDate = getDate();
                    // Hiển thị ngày hiện tại trong trường văn bản txtDate_KH
                    txtDate_KH.setText(currentDate);
                }
            }
        });

        txtID_CD.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Sinh số ngẫu nhiên từ 100 đến 9999
                    Random rd = new Random();
                    int randomNumber = rd.nextInt(9899) + 100; // Sinh số ngẫu nhiên trong khoảng từ 100 đến 9999

                    // Hiển thị số ngẫu nhiên trong trường văn bản txtID_CD
                    txtID_CD.setText("CD" + String.valueOf(randomNumber));
                }
            }
        });
        txtID_KH.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Sinh số ngẫu nhiên từ 100 đến 9999
                    Random rd = new Random();
                    int randomNumber = rd.nextInt(9899) + 100; // Sinh số ngẫu nhiên trong khoảng từ 100 đến 9999

                    // Hiển thị số ngẫu nhiên trong trường văn bản txtID_CD
                    txtID_KH.setText("KH" + String.valueOf(randomNumber));
                }
            }
        });

        txtIDStaff_NV.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Sinh số ngẫu nhiên từ 100 đến 9999
                    Random rd = new Random();
                    int randomNumber = rd.nextInt(9899) + 100; // Sinh số ngẫu nhiên trong khoảng từ 100 đến 9999

                    // Hiển thị số ngẫu nhiên trong trường văn bản txtID_CD
                    txtIDStaff_NV.setText("NV" + String.valueOf(randomNumber));
                }
            }
        });
        txtID_NH.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Sinh số ngẫu nhiên từ 100 đến 9999
                    Random rd = new Random();
                    int randomNumber = rd.nextInt(9899) + 100; // Sinh số ngẫu nhiên trong khoảng từ 100 đến 9999

                    // Hiển thị số ngẫu nhiên trong trường văn bản txtID_CD
                    txtID_NH.setText("NH" + String.valueOf(randomNumber));
                }
            }
        });

        txtEmail_NH.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Lấy tên từ trường văn bản txtName_NH
                    String name = txtName_NH.getText().trim();

                    if (name.isEmpty()) {
                        lblErrorEmail_NH.setText("Tên người đang bỏ trống nên không thể tạo");
                    } else {

                        // Chuyển tên thành chữ thường và loại bỏ các ký tự đặc biệt
                        name = name.toLowerCase().replaceAll("[^a-z ]", "");

                        // Loại bỏ dấu từ tên người học
                        name = Normalizer.normalize(name, Normalizer.Form.NFD);
                        name = name.replaceAll("[^\\p{ASCII}]", "");

                        // Tạo danh sách các phần tên từ tên người học
                        String[] parts = name.split("\\s+");
                        StringBuilder emailBuilder = new StringBuilder();

                        // Lấy phần cuối cùng của tên và thêm vào emailBuilder
                        if (parts.length > 0) {
                            String lastName = parts[parts.length - 1];
                            emailBuilder.append(lastName);
                        }

                        // Sinh số ngẫu nhiên từ 100 đến 9999
                        Random rd = new Random();
                        int randomNumber = rd.nextInt(9899) + 100; // Sinh số ngẫu nhiên trong khoảng từ 100 đến 9999

                        // Thêm số ngẫu nhiên và đuôi email vào emailBuilder
                        emailBuilder.append(randomNumber).append("@gmail.com");

                        // Hiển thị email trong trường văn bản txtEmail_NH
                        txtEmail_NH.setText(emailBuilder.toString());
                    }
                }
            }
        });

        cboNameCD_HV.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy vị trí của mục đã chọn
                int selectedIndex = cboNameCD_HV.getSelectedIndex();
                if (selectedIndex != -1) { // Đảm bảo một mục đã được chọn
                    // Lấy tên của mục đã chọn
                    String selectedName = (String) cboNameCD_HV.getSelectedItem();
                    // Tách mã chuyên đề từ tên chuyên đề
                    String maCD = selectedName.split(" - ")[0];
                    // Tạo câu truy vấn để lấy thông tin chi tiết của chuyên đề dựa trên mã
                    String query = "SELECT * FROM HOC_VIEN A INNER JOIN NGUOI_HOC B ON A.MA_NH = B.MA_NH INNER JOIN NHAN_VIEN C ON C.MA_NV = B.MA_NV INNER JOIN KHOA_HOC D ON D.MA_NV = C.MA_NV INNER JOIN CHUYEN_DE E ON E.MA_CD = D.MA_CD WHERE E.MA_CD = ?";
                    try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
                        pst.setString(1, maCD);
                        ResultSet rs = pst.executeQuery();
                        // Xóa dữ liệu cũ trong tbl
                        DefaultTableModel model = (DefaultTableModel) tblHV.getModel();
                        model.setRowCount(0);
                        // Điền dữ liệu mới vào tbl
                        while (rs.next()) {
                            String[] rowData = {rs.getString("MA_HV"), rs.getString("MA_NH"), rs.getString("TEN_NH").toString(), rs.getString("DIEM")};
                            model.addRow(rowData);
                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu: " + ex.getMessage());
                    }
                }
            }
        });

        cboKH_TK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy vị trí của mục đã chọn
                int selectedIndex = cboKH_TK.getSelectedIndex();
                if (selectedIndex != -1) { // Đảm bảo một mục đã được chọn
                    // Lấy tên của mục đã chọn
                    String selectedName = (String) cboKH_TK.getSelectedItem();
                    // Tách mã chuyên đề từ tên chuyên đề
                    String maCD = selectedName.split(" - ")[0];
                    // Tạo câu truy vấn để lấy thông tin chi tiết của chuyên đề dựa trên mã
                    String query = "SELECT *,  CASE"
                            + "           WHEN DIEM >= 9 THEN N'Xuất sắc'"
                            + "           WHEN DIEM >= 8.5 THEN N'Giỏi'"
                            + "           WHEN DIEM >= 6.5 THEN N'Khá'"
                            + "           WHEN DIEM >= 5 THEN N'Trung bình'"
                            + "           ELSE N'Yếu'"
                            + "       END AS HOC_LUC FROM HOC_VIEN A INNER JOIN NGUOI_HOC B ON A.MA_NH = B.MA_NH INNER JOIN NHAN_VIEN C ON C.MA_NV = B.MA_NV INNER JOIN KHOA_HOC D ON D.MA_NV = C.MA_NV INNER JOIN CHUYEN_DE E ON E.MA_CD = D.MA_CD WHERE E.MA_CD = ?";
                    try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
                        pst.setString(1, maCD);
                        ResultSet rs = pst.executeQuery();
                        // Xóa dữ liệu cũ trong tbl
                        DefaultTableModel model = (DefaultTableModel) tblMark_TK.getModel();
                        model.setRowCount(0);
                        // Điền dữ liệu mới vào tbl
                        while (rs.next()) {
                            String[] rowData = {rs.getString("MA_NH"), rs.getString("TEN_NH"), rs.getString("DIEM").toString(), rs.getString("HOC_LUC")};
                            model.addRow(rowData);
                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu: " + ex.getMessage());
                    }
                }
            }
        });

        // Khai báo sự kiện sửa đổi cho bảng
        tblHV.getModel().addTableModelListener(new TableModelListener() {
            public void tableChanged(TableModelEvent e) {
                // Xác định chỉ mục hàng và cột bị sửa đổi
                int row = e.getFirstRow();
                int column = e.getColumn();
                // Kiểm tra xem sự kiện có phải là sự kiện cập nhật dữ liệu không
                if (column == 3 && row != -1) { // Giả sử cột thứ tư chứa điểm
                    // Lấy mã học viên từ hàng đã sửa đổi
                    String maHV = tblHV.getValueAt(row, 0).toString(); // Giả sử cột đầu tiên là mã học viên
                    // Lấy điểm mới từ ô vừa sửa đổi
                    float newDiem = Float.parseFloat(tblHV.getValueAt(row, column).toString());
                    // Thực hiện cập nhật vào cơ sở dữ liệu
                    update_HV(maHV, newDiem);
                }
            }
        });

        cboYear_Revenue.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy vị trí của mục đã chọn
                int selectedIndex = cboYear_Revenue.getSelectedIndex();
                if (selectedIndex != -1) { // Đảm bảo một mục đã được chọn
                    // Lấy tên của mục đã chọn
                    String selectedName = (String) cboYear_Revenue.getSelectedItem();
                    // Tách mã chuyên đề từ tên chuyên đề
                    String maCD = selectedName.split(" - ")[0];
                    // Tạo câu truy vấn để lấy thông tin chi tiết của chuyên đề dựa trên mã
                    String query = "SELECT E.TEN_CD, COUNT(D.MA_KH) AS SL_KH, COUNT(A.MA_HV) AS SL_HV, MAX(E.HOC_PHI) AS DT_C, MIN(E.HOC_PHI) AS DT_T, AVG(E.HOC_PHI) AS DT_TB FROM HOC_VIEN A INNER JOIN NGUOI_HOC B ON A.MA_NH = B.MA_NH INNER JOIN NHAN_VIEN C ON C.MA_NV = B.MA_NV INNER JOIN KHOA_HOC D ON D.MA_NV = C.MA_NV INNER JOIN CHUYEN_DE E ON E.MA_CD = D.MA_CD WHERE YEAR(NGAY_KG) = ? GROUP BY TEN_CD";
                    try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
                        pst.setString(1, maCD);
                        ResultSet rs = pst.executeQuery();
                        // Xóa dữ liệu cũ trong tbl
                        DefaultTableModel model = (DefaultTableModel) tblRevenue_TK.getModel();
                        model.setRowCount(0);
                        // Điền dữ liệu mới vào tbl
                        while (rs.next()) {
                            String[] rowData = {rs.getString("TEN_CD"), rs.getString("SL_KH"), rs.getString("SL_HV").toString(), rs.getString("DT_C"), rs.getString("DT_T"), rs.getString("DT_TB")};
                            model.addRow(rowData);
                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu: " + ex.getMessage());
                    }
                }
            }
        });
    }
    //Lấy mã nhân viên đăng nhập thành công
      public void setEmployeeID(String employeeID) {
        txtID_NV.setText(employeeID);
    }

    private void loadTable_NGUOI_HOC_TK() {
        DefaultTableModel model = (DefaultTableModel) tblStudent_TK.getModel();
        model.setRowCount(0); // Clear all rows in the table before filling it with new data
        String query = "SELECT YEAR(NGAY_KG) AS NAM, COUNT(*) AS SL, MIN(NGAY_DK) AS NGAY_SOM_NHAT, MAX(NGAY_DK) AS NGAY_TRE_NHAT "
                + "FROM HOC_VIEN A "
                + "INNER JOIN NGUOI_HOC B ON A.MA_NH = B.MA_NH "
                + "INNER JOIN NHAN_VIEN C ON C.MA_NV = B.MA_NV "
                + "INNER JOIN KHOA_HOC D ON D.MA_NV = C.MA_NV "
                + "INNER JOIN CHUYEN_DE E ON E.MA_CD = D.MA_CD "
                + "WHERE E.MA_CD = ? "
                + "GROUP BY YEAR(NGAY_KG)";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, "CD01"); // Assuming you want to filter by 'CD01'
            try ( ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    String nam = rs.getString("NAM");
                    String soNH = rs.getString("SL");
                    String dkSom = rs.getString("NGAY_SOM_NHAT");
                    String dkMuon = rs.getString("NGAY_TRE_NHAT");

                    // Add a new row to the table with the course information
                    model.addRow(new Object[]{nam, soNH, dkSom, dkMuon});
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi hiển thị người học thống kê: " + ex.getMessage());
        }
    }

    private void loadTable_CHUYENDE_TK() {
        DefaultTableModel model = (DefaultTableModel) tblCD_TK.getModel();
        model.setRowCount(0); // Clear all rows in the table before filling it with new data
        String query = "SELECT C.TEN_CD, COUNT(MA_HV) AS SL_HV, MIN(DIEM) AS DIEM_THAP, MAX(DIEM) AS DIEM_CAO, AVG(DIEM) AS DIEM_TB FROM HOC_VIEN A INNER JOIN KHOA_HOC B ON A.MA_KH = B.MA_KH INNER JOIN CHUYEN_DE C ON C.MA_CD = B.MA_CD GROUP BY TEN_CD";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
            try ( ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    String tenCD = rs.getString("TEN_CD");
                    String soHV = rs.getString("SL_HV");
                    String diemThap = rs.getString("DIEM_THAP");
                    String diemCao = rs.getString("DIEM_CAO");
                    String diemTB = rs.getString("DIEM_TB");

                    // Add a new row to the table with the course information
                    model.addRow(new Object[]{tenCD, soHV, diemThap, diemCao, diemTB});
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi hiển thị chuyên đề thống kê: " + ex.getMessage());
        }
    }

// Phương thức để lấy ngày hiện tại dưới dạng chuỗi
    private String getDate() {
        String currentDate = ""; // Khởi tạo ngày hiện tại

        // Câu truy vấn SQL để lấy ngày hiện tại từ cơ sở dữ liệu
        String query = "SELECT CONVERT(date, GETDATE()) AS date;";

        try (
                // Kết nối đến cơ sở dữ liệu
                 Connection con = DriverManager.getConnection(url); // Chuẩn bị câu truy vấn
                  PreparedStatement pst = con.prepareStatement(query); // Thực thi truy vấn và lấy kết quả
                  ResultSet rs = pst.executeQuery();) {
            // Nếu có kết quả trả về
            if (rs.next()) {
                // Lấy ngày hiện tại từ kết quả truy vấn
                currentDate = rs.getString("date");
            }
        } catch (SQLException ex) {
            // Xử lý ngoại lệ nếu có lỗi trong quá trình truy vấn cơ sở dữ liệu
            ex.printStackTrace();
        }

        // Trả về ngày hiện tại
        return currentDate;
    }

    // Khai báo phương thức getTenNhanVienFromMaNhanVien
    private void clickTable_CHUYEN_DE() {
        tbl_CD.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is not adjusting and a row is selected
                if (!e.getValueIsAdjusting() && tbl_CD.getSelectedRow() != -1) {
                    // Get the selected row index
                    int selectedRow = tbl_CD.getSelectedRow();
                    // Populate input fields with data from the selected row
                    txtID_CD.setText(tbl_CD.getValueAt(selectedRow, 0).toString());
                    txtName_CD.setText(tbl_CD.getValueAt(selectedRow, 1).toString());
                    txtTime_CD.setText(tbl_CD.getValueAt(selectedRow, 3).toString());
                    txtTuition_CD.setText(tbl_CD.getValueAt(selectedRow, 2).toString());
                    txtNote_CD.setText(tbl_CD.getValueAt(selectedRow, 5).toString());
                    String imagePath = tbl_CD.getValueAt(selectedRow, 4).toString();
                    displayImage(imagePath);
                }
            }
        });
    }

    private void displayImage(String imagePath) {
        // Xóa biểu tượng hiện tại trên lblImg_CD để làm mới
        lblImg_CD.setIcon(null);
        lblImg_CD.setText(""); // Xóa văn bản lỗi trước khi đặt biểu tượng mới

        // Kiểm tra nếu đường dẫn hình ảnh không rỗng
        if (!imagePath.isEmpty()) {
            try {
                // Đọc hình ảnh từ đường dẫn tệp
                BufferedImage img = ImageIO.read(new File(imagePath));

                // Tính toán kích thước mới mà vẫn giữ nguyên tỉ lệ
                int imgWidth = img.getWidth();  // Chiều rộng của ảnh
                int imgHeight = img.getHeight(); // Chiều cao của ảnh
                int lblWidth = lblImg_CD.getWidth(); // Chiều rộng của pnlIMG
                int lblHeight = lblImg_CD.getHeight(); // Chiều cao của pnlIMG

                // Tính tỉ lệ thay đổi kích thước dựa trên chiều rộng
                float widthRatio = (float) lblWidth / imgWidth;
                float heightRatio = (float) lblHeight / imgHeight;
                // Chọn tỉ lệ nhỏ hơn để đảm bảo hình ảnh vừa với cả chiều rộng và chiều cao
                float ratio = Math.min(widthRatio, heightRatio);

                // Tính toán kích thước mới của ảnh sau khi thay đổi tỉ lệ
                int newWidth = Math.round(imgWidth * widthRatio);
                int newHeight = Math.round(imgHeight * widthRatio);

                // Thay đổi kích thước ảnh để vừa với nhãn lblImg_CD mà vẫn giữ nguyên tỉ lệ
                Image scaledImage = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);

                // Đặt ảnh đã thay đổi kích thước vào lblImg_CD
                lblImg_CD.setIcon(new ImageIcon(scaledImage));
            } catch (IOException e) {
                e.printStackTrace();
                // Xử lý trường hợp không thể đọc được hình ảnh
                // lblImg_CD.setText("Error: Image not found");
            }
        }
    }

    private void clickTable_NGUOI_HOC() {
        tblLeaner.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is not adjusting and a row is selected
                if (!e.getValueIsAdjusting() && tblLeaner.getSelectedRow() != -1) {
                    // Get the selected row index
                    int selectedRow = tblLeaner.getSelectedRow();
                    // Populate input fields with data from the selected row
                    txtID_NH.setText(tblLeaner.getValueAt(selectedRow, 0).toString());
                    txtName_NH.setText(tblLeaner.getValueAt(selectedRow, 1).toString());
                    String gender = tblLeaner.getValueAt(selectedRow, 2).toString();
                    // Set radio button based on gender
                    if (gender.equals("Nam")) {
                        rdoMale_NH.setSelected(true);
                    } else if (gender.equals("Nữ")) {
                        rdoFemale_NH.setSelected(true);
                    }
                    txtBrithday_NH.setText(tblLeaner.getValueAt(selectedRow, 3).toString());
                    txtPhone_NH.setText(tblLeaner.getValueAt(selectedRow, 4).toString());
                    txtEmail_NH.setText(tblLeaner.getValueAt(selectedRow, 5).toString());
                }
            }
        });
    }

    private int calculateMenuWidth() {
        return pnlMiniMenu.getPreferredSize().width;
    }

    private void turnOff() {
        UIManager.put("OptionPane.yesButtonText", "Chắc chắn");
        UIManager.put("OptionPane.noButtonText", "Chưa chắc chắn");
        int choice = JOptionPane.showConfirmDialog(this, "Bạn chắc chắn muốn thoát?", "Xác nhận", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0); // Exit the application
        }
    }

    private void openMenubar() {
        int width = calculateMenuWidth(); // Calculate width here
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 54; i < width; i++) {
                    pnlMiniMenu.setSize(i, height);
                    pnlMiniMenu.repaint(); // Repaint the panel to update the display
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException ex) {
                    }
                }
            }
        }).start();
    }

    private void closeMenubar() {
        int width = calculateMenuWidth(); // Calculate width here
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = width; i > 55; i--) {
                    pnlMiniMenu.setSize(i, height);
                    pnlMiniMenu.repaint(); // Repaint the panel to update the display
                    try {
                        Thread.sleep(2);
                    } catch (InterruptedException ex) {
                    }
                }
            }
        }).start();
    }

    private void moveHomePanel() {
        // Lấy thông tin về kích thước và vị trí của pnlHome
        int pnlHomeX = pnlEdition.getX();
        int pnlHomeWidth = pnlEdition.getWidth();
        // Tính toán kích thước mới của pnlHome dựa trên kích thước mới của pnlMiniMenu
        int newPnlHomeWidth = getWidth() - pnlMiniMenu.getWidth();
        // Tính toán vị trí mới của pnlHome
        int newPnlHomeX = pnlHomeX + pnlMiniMenu.getWidth(); // hoặc newPnlHomeX = pnlMiniMenu.getWidth();
        // Di chuyển pnlHome đến vị trí mới
        pnlEdition.setBounds(newPnlHomeX, pnlEdition.getY(), newPnlHomeWidth, pnlEdition.getHeight());
    }

    private void showTextNextToIcon() {
        lblMenu.setText("Menu"); // Hiển thị chữ "Menu" kế bên icon
        lblHome.setText("Trang chủ");
        lblThematic.setText("Quản lý chuyên đề");
        lblCouse.setText("Quản lý khoá học");
        lblStudent.setText("Quản lý người học");
        lblStaff.setText("Quản lý nhân viên");
        lblLeaner.setText("Quản lý học viên");
        lblStatistical.setText("Thống kê");
        lblExit.setText("Đăng xuất");
    }

    private void disShowText() {
        lblHome.setText("");
        lblMenu.setText("");
        lblThematic.setText("");
        lblCouse.setText("");
        lblStudent.setText("");
        lblStaff.setText("");
        lblLeaner.setText("");
        lblStatistical.setText("");
        lblExit.setText("");
    }

    private void loadTable_KH() {
        DefaultTableModel model = (DefaultTableModel) tblKH.getModel();
        model.setRowCount(0); // Clear all rows in the table before filling it with new data
        String query = "SELECT MA_KH, THOI_LUONG, HOC_PHI, NGAY_KG, TEN_NV, NGAY_TAO FROM KHOA_HOC A INNER JOIN NHAN_VIEN B ON A.MA_NV = B.MA_NV";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                String idKH = rs.getString("MA_KH");
                String hocPhi = rs.getString("HOC_PHI");
                String thoiLuong = rs.getString("THOI_LUONG");
                String ngayKG = rs.getString("NGAY_KG");
                String ngayTao = rs.getString("NGAY_TAO");
                String taoBoi = rs.getNString("TEN_NV");
                // Add a new row to the table with the course information
                model.addRow(new Object[]{idKH, thoiLuong, hocPhi, ngayKG, taoBoi, ngayTao});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi hiển thị thông tin: " + ex.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        qUAN_LY_NHA_TRO1 = new me.pc07981.quan_ly.QUAN_LY();
        btnG_RENDER = new javax.swing.ButtonGroup();
        jPanel35 = new javax.swing.JPanel();
        btnG_VT = new javax.swing.ButtonGroup();
        pnlDisplay = new javax.swing.JPanel();
        pnlMiniMenu = new javax.swing.JPanel();
        lblMenu = new javax.swing.JLabel();
        lblHome = new javax.swing.JLabel();
        lblThematic = new javax.swing.JLabel();
        lblCouse = new javax.swing.JLabel();
        lblStudent = new javax.swing.JLabel();
        lblStaff = new javax.swing.JLabel();
        lblLeaner = new javax.swing.JLabel();
        lblExit = new javax.swing.JLabel();
        lblStatistical = new javax.swing.JLabel();
        pnlEdition = new javax.swing.JPanel();
        pnlThematic = new javax.swing.JPanel();
        lblTurnOff = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        pnlIMG = new javax.swing.JPanel();
        lblImg_CD = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        txtID_CD = new javax.swing.JTextField();
        lblErrorID_CD = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        txtName_CD = new javax.swing.JTextField();
        lblErrorName_CD = new javax.swing.JLabel();
        jPanel43 = new javax.swing.JPanel();
        txtTime_CD = new javax.swing.JTextField();
        lblErrorTime_CD = new javax.swing.JLabel();
        jPanel44 = new javax.swing.JPanel();
        txtTuition_CD = new javax.swing.JTextField();
        lblErrorTuition_CD = new javax.swing.JLabel();
        jPanel45 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtNote_CD = new javax.swing.JTextArea();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_CD = new javax.swing.JTable();
        jPanel12 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        btnAdd_CD = new javax.swing.JButton();
        btnUpdate_CD = new javax.swing.JButton();
        btn_Delete_CD = new javax.swing.JButton();
        btnReset_CD = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        pnlCourse = new javax.swing.JPanel();
        lblTurnOff1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        cboKH = new javax.swing.JComboBox<>();
        jPanel34 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        txtID_KH = new javax.swing.JTextField();
        lblErrorID_KH = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        txtUser_KH = new javax.swing.JTextField();
        lblErrorUser_KH = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        txtDate_KH = new javax.swing.JTextField();
        lblErrorDate_KH = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        txtOpening_KH = new javax.swing.JTextField();
        lblErrorOpening_KH = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        txtTuition_KH = new javax.swing.JTextField();
        lblErrorTuiltion_KH = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        txtTime_KH = new javax.swing.JTextField();
        lblErrorTime_KH = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtNote_KH = new javax.swing.JTextArea();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblKH = new javax.swing.JTable();
        jPanel36 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        btnDelete_KH = new javax.swing.JButton();
        btnReset_KH = new javax.swing.JButton();
        btnUpdate_KH = new javax.swing.JButton();
        btnAdd_KH = new javax.swing.JButton();
        jPanel37 = new javax.swing.JPanel();
        pnlStatic = new javax.swing.JPanel();
        lblTurnOff2 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel78 = new javax.swing.JPanel();
        jPanel79 = new javax.swing.JPanel();
        jPanel83 = new javax.swing.JPanel();
        cboKH_TK = new javax.swing.JComboBox<>();
        jPanel84 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        tblMark_TK = new javax.swing.JTable();
        jPanel80 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tblStudent_TK = new javax.swing.JTable();
        jPanel81 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        tblCD_TK = new javax.swing.JTable();
        jPanel82 = new javax.swing.JPanel();
        jPanel85 = new javax.swing.JPanel();
        cboYear_Revenue = new javax.swing.JComboBox<>();
        jPanel87 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        tblRevenue_TK = new javax.swing.JTable();
        pnlLearner = new javax.swing.JPanel();
        lblTurnOff3 = new javax.swing.JLabel();
        jPanel27 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        txtID_NH = new javax.swing.JTextField();
        lblErrorLeaner_NH = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        txtName_NH = new javax.swing.JTextField();
        lblErrorName_NH = new javax.swing.JLabel();
        jPanel47 = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        rdoMale_NH = new javax.swing.JRadioButton();
        rdoFemale_NH = new javax.swing.JRadioButton();
        jPanel51 = new javax.swing.JPanel();
        txtBrithday_NH = new javax.swing.JTextField();
        lblErrorBrithday_NH = new javax.swing.JLabel();
        jPanel48 = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        txtPhone_NH = new javax.swing.JTextField();
        lblErrorPhone_NH = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        txtEmail_NH = new javax.swing.JTextField();
        lblErrorEmail_NH = new javax.swing.JLabel();
        jPanel49 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtNote_NH = new javax.swing.JTextArea();
        jPanel41 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLeaner = new javax.swing.JTable();
        jPanel39 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        btnDelete_NH = new javax.swing.JButton();
        btnReset_NH = new javax.swing.JButton();
        btnUpdate_NH = new javax.swing.JButton();
        btnAdd_NH = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jPanel86 = new javax.swing.JPanel();
        txtID_NV = new javax.swing.JTextField();
        jPanel88 = new javax.swing.JPanel();
        pnlHome = new javax.swing.JPanel();
        lblTurnOff4 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        pnlStaff = new javax.swing.JPanel();
        lblTurnOff5 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel31 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel55 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        txtIDStaff_NV = new javax.swing.JTextField();
        lblErrorIDStaff_NV = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        txtName_NV = new javax.swing.JTextField();
        lblErrorName_NV = new javax.swing.JLabel();
        jPanel58 = new javax.swing.JPanel();
        txtPassword_NV = new javax.swing.JTextField();
        lblErrorPass_NV = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        txtConfirmPass_NV = new javax.swing.JTextField();
        lblErrorConfirm_NV = new javax.swing.JLabel();
        jPanel60 = new javax.swing.JPanel();
        rdoManager_NV = new javax.swing.JRadioButton();
        rdoStaff_NV = new javax.swing.JRadioButton();
        jPanel63 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tblStaff = new javax.swing.JTable();
        jPanel64 = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        btnDelete_NV = new javax.swing.JButton();
        btnReset_NV = new javax.swing.JButton();
        btnUpdate_NV = new javax.swing.JButton();
        btnAdd_NV = new javax.swing.JButton();
        jPanel66 = new javax.swing.JPanel();
        pnlStudents = new javax.swing.JPanel();
        lblTurnOff6 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jPanel61 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        cboNameCD_HV = new javax.swing.JComboBox<>();
        jPanel68 = new javax.swing.JPanel();
        cboNameKH_HV = new javax.swing.JComboBox<>();
        jPanel69 = new javax.swing.JPanel();
        jPanel70 = new javax.swing.JPanel();
        jPanel72 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblHV = new javax.swing.JTable();
        jPanel73 = new javax.swing.JPanel();
        btnDelete_HV = new javax.swing.JButton();
        btnUpdateMark_HV = new javax.swing.JButton();
        jPanel71 = new javax.swing.JPanel();
        jPanel74 = new javax.swing.JPanel();
        lblFindHV = new javax.swing.JLabel();
        txtFind_HV = new javax.swing.JTextField();
        jPanel75 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        tblStudent_HV = new javax.swing.JTable();
        jPanel76 = new javax.swing.JPanel();
        jPanel77 = new javax.swing.JPanel();
        btnAdd_HV = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        pnlMiniMenu.setBackground(new java.awt.Color(51, 255, 255));

        lblMenu.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblMenu.setForeground(new java.awt.Color(255, 255, 255));
        lblMenu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/menu.png"))); // NOI18N
        lblMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMenuMouseClicked(evt);
            }
        });

        lblHome.setBackground(new java.awt.Color(0, 0, 153));
        lblHome.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblHome.setForeground(new java.awt.Color(255, 255, 255));
        lblHome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/home-icon-silhouette.png"))); // NOI18N
        lblHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblHomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblHomeMouseExited(evt);
            }
        });

        lblThematic.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblThematic.setForeground(new java.awt.Color(255, 255, 255));
        lblThematic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblThematic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Thematic_32px.png"))); // NOI18N
        lblThematic.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblThematicMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblThematicMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblThematicMouseExited(evt);
            }
        });

        lblCouse.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblCouse.setForeground(new java.awt.Color(255, 255, 255));
        lblCouse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCouse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/course.png"))); // NOI18N
        lblCouse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCouseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblCouseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblCouseMouseExited(evt);
            }
        });

        lblStudent.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblStudent.setForeground(new java.awt.Color(255, 255, 255));
        lblStudent.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStudent.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/leaner_32px.png"))); // NOI18N
        lblStudent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblStudentMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblStudentMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblStudentMouseExited(evt);
            }
        });

        lblStaff.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblStaff.setForeground(new java.awt.Color(255, 255, 255));
        lblStaff.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStaff.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/staff_32px.png"))); // NOI18N
        lblStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblStaffMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblStaffMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblStaffMouseExited(evt);
            }
        });

        lblLeaner.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblLeaner.setForeground(new java.awt.Color(255, 255, 255));
        lblLeaner.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLeaner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/student.png"))); // NOI18N
        lblLeaner.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblLeanerMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblLeanerMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblLeanerMouseExited(evt);
            }
        });

        lblExit.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblExit.setForeground(new java.awt.Color(255, 255, 255));
        lblExit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logout.png"))); // NOI18N
        lblExit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblExitMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblExitMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblExitMouseExited(evt);
            }
        });

        lblStatistical.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        lblStatistical.setForeground(new java.awt.Color(255, 255, 255));
        lblStatistical.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStatistical.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Statistical_32px.png"))); // NOI18N
        lblStatistical.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblStatisticalMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblStatisticalMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblStatisticalMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlMiniMenuLayout = new javax.swing.GroupLayout(pnlMiniMenu);
        pnlMiniMenu.setLayout(pnlMiniMenuLayout);
        pnlMiniMenuLayout.setHorizontalGroup(
            pnlMiniMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMiniMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlMiniMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblMenu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblThematic, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                    .addComponent(lblCouse, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblStudent, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblStaff, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblStatistical, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblExit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addComponent(lblLeaner, javax.swing.GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
        );
        pnlMiniMenuLayout.setVerticalGroup(
            pnlMiniMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMiniMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(lblHome)
                .addGap(18, 18, 18)
                .addComponent(lblThematic, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblCouse)
                .addGap(18, 18, 18)
                .addComponent(lblStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblLeaner)
                .addGap(18, 18, 18)
                .addComponent(lblStaff)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblStatistical)
                .addGap(18, 18, 18)
                .addComponent(lblExit)
                .addContainerGap())
        );

        pnlEdition.setLayout(new java.awt.CardLayout());

        lblTurnOff.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOffMouseClicked(evt);
            }
        });

        jPanel1.setLayout(new java.awt.CardLayout());

        jLabel20.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 255, 255));
        jLabel20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel20.setText("QUẢN LÝ CHUYÊN ĐỀ");
        jPanel1.add(jLabel20, "card2");

        jPanel8.setLayout(new java.awt.GridLayout(1, 3));

        pnlIMG.setBorder(javax.swing.BorderFactory.createTitledBorder("Ảnh"));
        pnlIMG.setLayout(new java.awt.BorderLayout());

        lblImg_CD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblImg_CD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblImg_CDMouseClicked(evt);
            }
        });
        pnlIMG.add(lblImg_CD, java.awt.BorderLayout.CENTER);

        jPanel8.add(pnlIMG);

        jPanel10.setLayout(new java.awt.GridLayout(5, 0));

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder("Mã chuyên đề"));
        jPanel13.setLayout(new java.awt.GridLayout(2, 0));
        jPanel13.add(txtID_CD);

        lblErrorID_CD.setForeground(new java.awt.Color(204, 0, 0));
        jPanel13.add(lblErrorID_CD);

        jPanel10.add(jPanel13);

        jPanel26.setBorder(javax.swing.BorderFactory.createTitledBorder("Tên chuyên đề"));
        jPanel26.setLayout(new java.awt.GridLayout(2, 0));
        jPanel26.add(txtName_CD);

        lblErrorName_CD.setForeground(new java.awt.Color(204, 0, 0));
        jPanel26.add(lblErrorName_CD);

        jPanel10.add(jPanel26);

        jPanel43.setBorder(javax.swing.BorderFactory.createTitledBorder("Thời lượng"));
        jPanel43.setLayout(new java.awt.GridLayout(2, 0));
        jPanel43.add(txtTime_CD);

        lblErrorTime_CD.setForeground(new java.awt.Color(204, 0, 0));
        jPanel43.add(lblErrorTime_CD);

        jPanel10.add(jPanel43);

        jPanel44.setBorder(javax.swing.BorderFactory.createTitledBorder("Học phí"));
        jPanel44.setLayout(new java.awt.GridLayout(2, 0));
        jPanel44.add(txtTuition_CD);

        lblErrorTuition_CD.setForeground(new java.awt.Color(204, 0, 0));
        jPanel44.add(lblErrorTuition_CD);

        jPanel10.add(jPanel44);

        jPanel45.setBorder(javax.swing.BorderFactory.createTitledBorder("Mô tả"));
        jPanel45.setLayout(new java.awt.BorderLayout());

        txtNote_CD.setColumns(20);
        txtNote_CD.setRows(5);
        jScrollPane2.setViewportView(txtNote_CD);

        jPanel45.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel10.add(jPanel45);

        jPanel8.add(jPanel10);

        tbl_CD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã chuyên đề", "Tên chuyên đề", "Học phí", "Thời lượng ", "Hình", "Mô tả"
            }
        ));
        jScrollPane3.setViewportView(tbl_CD);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 901, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel8.add(jPanel11);

        jPanel12.setLayout(new java.awt.GridLayout(1, 3));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 77, Short.MAX_VALUE)
        );

        jPanel12.add(jPanel2);

        jPanel4.setLayout(new java.awt.GridLayout(2, 2));

        btnAdd_CD.setText("Thêm");
        btnAdd_CD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd_CDActionPerformed(evt);
            }
        });
        jPanel4.add(btnAdd_CD);

        btnUpdate_CD.setText("Sửa");
        btnUpdate_CD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate_CDActionPerformed(evt);
            }
        });
        jPanel4.add(btnUpdate_CD);

        btn_Delete_CD.setText("Xoá");
        btn_Delete_CD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Delete_CDActionPerformed(evt);
            }
        });
        jPanel4.add(btn_Delete_CD);

        btnReset_CD.setText("Làm mới");
        btnReset_CD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReset_CDActionPerformed(evt);
            }
        });
        jPanel4.add(btnReset_CD);

        jPanel12.add(jPanel4);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 77, Short.MAX_VALUE)
        );

        jPanel12.add(jPanel5);

        javax.swing.GroupLayout pnlThematicLayout = new javax.swing.GroupLayout(pnlThematic);
        pnlThematic.setLayout(pnlThematicLayout);
        pnlThematicLayout.setHorizontalGroup(
            pnlThematicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThematicLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlThematicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThematicLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblTurnOff, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(6, 6, 6))
        );
        pnlThematicLayout.setVerticalGroup(
            pnlThematicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThematicLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlThematicLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlEdition.add(pnlThematic, "card2");

        pnlCourse.setToolTipText("");

        lblTurnOff1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff1MouseClicked(evt);
            }
        });

        jPanel3.setLayout(new java.awt.CardLayout());

        jLabel21.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 255, 255));
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("QUẢN LÝ KHOÁ HỌC");
        jPanel3.add(jLabel21, "card2");

        jPanel7.setLayout(new java.awt.BorderLayout());

        cboKH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel7.add(cboKH, java.awt.BorderLayout.CENTER);

        jPanel34.setLayout(new java.awt.GridLayout(1, 2));

        jPanel14.setLayout(new java.awt.GridLayout(7, 1));

        jPanel16.setBorder(javax.swing.BorderFactory.createTitledBorder("Mã khoá học"));
        jPanel16.setLayout(new java.awt.GridLayout(2, 0));

        txtID_KH.setToolTipText("");
        jPanel16.add(txtID_KH);

        lblErrorID_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel16.add(lblErrorID_KH);

        jPanel14.add(jPanel16);

        jPanel17.setBorder(javax.swing.BorderFactory.createTitledBorder("Người tạo"));
        jPanel17.setLayout(new java.awt.GridLayout(2, 0));

        txtUser_KH.setToolTipText("");
        jPanel17.add(txtUser_KH);

        lblErrorUser_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel17.add(lblErrorUser_KH);

        jPanel14.add(jPanel17);

        jPanel18.setBorder(javax.swing.BorderFactory.createTitledBorder("Ngày tạo"));
        jPanel18.setLayout(new java.awt.GridLayout(2, 0));

        txtDate_KH.setToolTipText("");
        jPanel18.add(txtDate_KH);

        lblErrorDate_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel18.add(lblErrorDate_KH);

        jPanel14.add(jPanel18);

        jPanel19.setBorder(javax.swing.BorderFactory.createTitledBorder("Khai giảng"));
        jPanel19.setLayout(new java.awt.GridLayout(2, 0));

        txtOpening_KH.setToolTipText("");
        jPanel19.add(txtOpening_KH);

        lblErrorOpening_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel19.add(lblErrorOpening_KH);

        jPanel14.add(jPanel19);

        jPanel20.setBorder(javax.swing.BorderFactory.createTitledBorder("Học phí"));
        jPanel20.setLayout(new java.awt.GridLayout(2, 0));

        txtTuition_KH.setToolTipText("");
        jPanel20.add(txtTuition_KH);

        lblErrorTuiltion_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel20.add(lblErrorTuiltion_KH);

        jPanel14.add(jPanel20);

        jPanel21.setBorder(javax.swing.BorderFactory.createTitledBorder("Thời lượng"));
        jPanel21.setLayout(new java.awt.GridLayout(2, 0));

        txtTime_KH.setToolTipText("");
        jPanel21.add(txtTime_KH);

        lblErrorTime_KH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel21.add(lblErrorTime_KH);

        jPanel14.add(jPanel21);

        jPanel22.setBorder(javax.swing.BorderFactory.createTitledBorder("Mô tả"));
        jPanel22.setLayout(new java.awt.BorderLayout());

        txtNote_KH.setColumns(20);
        txtNote_KH.setRows(5);
        jScrollPane4.setViewportView(txtNote_KH);

        jPanel22.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel22);

        jPanel34.add(jPanel14);

        jPanel15.setLayout(new java.awt.BorderLayout());

        tblKH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã khoá học", "Thời lượng", "Học phí", "Khai giảng", "Tạo bởi", "Ngày tạo"
            }
        ));
        jScrollPane5.setViewportView(tblKH);
        if (tblKH.getColumnModel().getColumnCount() > 0) {
            tblKH.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel15.add(jScrollPane5, java.awt.BorderLayout.CENTER);

        jPanel34.add(jPanel15);

        jPanel36.setLayout(new java.awt.GridLayout(1, 3));

        jPanel23.setLayout(new java.awt.GridLayout(1, 0));

        btnDelete_KH.setText("Xoá");
        btnDelete_KH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete_KHActionPerformed(evt);
            }
        });
        jPanel23.add(btnDelete_KH);

        btnReset_KH.setText("Làm mới");
        btnReset_KH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReset_KHActionPerformed(evt);
            }
        });
        jPanel23.add(btnReset_KH);

        btnUpdate_KH.setText("Sửa");
        btnUpdate_KH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate_KHActionPerformed(evt);
            }
        });
        jPanel23.add(btnUpdate_KH);

        btnAdd_KH.setText("Thêm");
        btnAdd_KH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd_KHActionPerformed(evt);
            }
        });
        jPanel23.add(btnAdd_KH);

        jPanel36.add(jPanel23);

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 516, Short.MAX_VALUE)
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel36.add(jPanel37);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel34, javax.swing.GroupLayout.DEFAULT_SIZE, 912, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel36, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlCourseLayout = new javax.swing.GroupLayout(pnlCourse);
        pnlCourse.setLayout(pnlCourseLayout);
        pnlCourseLayout.setHorizontalGroup(
            pnlCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCourseLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlCourseLayout.setVerticalGroup(
            pnlCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCourseLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlCourseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlCourse, "card2");

        lblTurnOff2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff2MouseClicked(evt);
            }
        });

        jPanel25.setLayout(new java.awt.CardLayout());

        jLabel22.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 255, 255));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("THỐNG KÊ");
        jPanel25.add(jLabel22, "card2");

        jPanel78.setLayout(new java.awt.GridLayout(2, 2));

        jPanel79.setBorder(javax.swing.BorderFactory.createTitledBorder("Bảng điểm"));

        jPanel83.setBorder(javax.swing.BorderFactory.createTitledBorder("Khoá học"));
        jPanel83.setLayout(new java.awt.BorderLayout());

        cboKH_TK.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel83.add(cboKH_TK, java.awt.BorderLayout.CENTER);

        jPanel84.setLayout(new java.awt.BorderLayout());

        tblMark_TK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã người học", "Họ và tên", "Điểm", "Xếp loại"
            }
        ));
        jScrollPane10.setViewportView(tblMark_TK);

        jPanel84.add(jScrollPane10, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout jPanel79Layout = new javax.swing.GroupLayout(jPanel79);
        jPanel79.setLayout(jPanel79Layout);
        jPanel79Layout.setHorizontalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel83, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel84, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel79Layout.setVerticalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel79Layout.createSequentialGroup()
                .addComponent(jPanel83, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel84, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel78.add(jPanel79);

        jPanel80.setBorder(javax.swing.BorderFactory.createTitledBorder("Bảng người học"));
        jPanel80.setLayout(new java.awt.BorderLayout());

        tblStudent_TK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Năm", "Số người học", "Đăng ký sớm nhất", "Đăng ký muộn nhất"
            }
        ));
        jScrollPane11.setViewportView(tblStudent_TK);

        jPanel80.add(jScrollPane11, java.awt.BorderLayout.CENTER);

        jPanel78.add(jPanel80);

        jPanel81.setBorder(javax.swing.BorderFactory.createTitledBorder("Bảng chuyên đề"));
        jPanel81.setLayout(new java.awt.BorderLayout());

        tblCD_TK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tên chuyên đề", "Số lượng học viên", "Điểm thấp nhất", "Điểm cao nhất", "Điểm trung bình"
            }
        ));
        jScrollPane12.setViewportView(tblCD_TK);

        jPanel81.add(jScrollPane12, java.awt.BorderLayout.CENTER);

        jPanel78.add(jPanel81);

        jPanel82.setBorder(javax.swing.BorderFactory.createTitledBorder("Doanh thu"));

        jPanel85.setBorder(javax.swing.BorderFactory.createTitledBorder("Năm"));
        jPanel85.setLayout(new java.awt.BorderLayout());

        cboYear_Revenue.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel85.add(cboYear_Revenue, java.awt.BorderLayout.CENTER);

        jPanel87.setLayout(new java.awt.BorderLayout());

        tblRevenue_TK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tên chuyên đề", "Số khoá học", "Số học viên", "Doanh thu thấp", "Doanh thu cao", "Doanh thu trung bình"
            }
        ));
        jScrollPane13.setViewportView(tblRevenue_TK);

        jPanel87.add(jScrollPane13, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout jPanel82Layout = new javax.swing.GroupLayout(jPanel82);
        jPanel82.setLayout(jPanel82Layout);
        jPanel82Layout.setHorizontalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel85, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel87, javax.swing.GroupLayout.DEFAULT_SIZE, 506, Short.MAX_VALUE)
        );
        jPanel82Layout.setVerticalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addComponent(jPanel85, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel87, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel78.add(jPanel82);

        javax.swing.GroupLayout pnlStaticLayout = new javax.swing.GroupLayout(pnlStatic);
        pnlStatic.setLayout(pnlStaticLayout);
        pnlStaticLayout.setHorizontalGroup(
            pnlStaticLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaticLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel78, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlStaticLayout.setVerticalGroup(
            pnlStaticLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaticLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlStaticLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel78, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlStatic, "card2");

        lblTurnOff3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff3MouseClicked(evt);
            }
        });

        jPanel27.setLayout(new java.awt.CardLayout());

        jLabel23.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 255, 255));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("QUẢN LÝ NGƯỜI HỌC");
        jPanel27.add(jLabel23, "card2");

        jPanel38.setLayout(new java.awt.GridLayout(1, 0));

        jPanel40.setLayout(new java.awt.GridLayout(5, 1));

        jPanel42.setBorder(javax.swing.BorderFactory.createTitledBorder("Mã người học"));
        jPanel42.setLayout(new java.awt.GridLayout(2, 0));
        jPanel42.add(txtID_NH);

        lblErrorLeaner_NH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel42.add(lblErrorLeaner_NH);

        jPanel40.add(jPanel42);

        jPanel46.setBorder(javax.swing.BorderFactory.createTitledBorder("Họ và tên"));
        jPanel46.setLayout(new java.awt.GridLayout(2, 0));
        jPanel46.add(txtName_NH);

        lblErrorName_NH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel46.add(lblErrorName_NH);

        jPanel40.add(jPanel46);

        jPanel47.setLayout(new java.awt.GridLayout(1, 0));

        jPanel50.setBorder(javax.swing.BorderFactory.createTitledBorder("Giới tính"));
        jPanel50.setLayout(new java.awt.GridLayout(1, 0));

        btnG_RENDER.add(rdoMale_NH);
        rdoMale_NH.setText("Nam");
        jPanel50.add(rdoMale_NH);

        btnG_RENDER.add(rdoFemale_NH);
        rdoFemale_NH.setText("Nữ");
        jPanel50.add(rdoFemale_NH);

        jPanel47.add(jPanel50);

        jPanel51.setBorder(javax.swing.BorderFactory.createTitledBorder("Ngày sinh"));
        jPanel51.setLayout(new java.awt.GridLayout(2, 0));
        jPanel51.add(txtBrithday_NH);

        lblErrorBrithday_NH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel51.add(lblErrorBrithday_NH);

        jPanel47.add(jPanel51);

        jPanel40.add(jPanel47);

        jPanel48.setLayout(new java.awt.GridLayout(1, 0));

        jPanel52.setBorder(javax.swing.BorderFactory.createTitledBorder("Điện thoại"));
        jPanel52.setLayout(new java.awt.GridLayout(2, 0));
        jPanel52.add(txtPhone_NH);

        lblErrorPhone_NH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel52.add(lblErrorPhone_NH);

        jPanel48.add(jPanel52);

        jPanel53.setBorder(javax.swing.BorderFactory.createTitledBorder("Email"));
        jPanel53.setLayout(new java.awt.GridLayout(2, 0));
        jPanel53.add(txtEmail_NH);

        lblErrorEmail_NH.setForeground(new java.awt.Color(204, 0, 0));
        jPanel53.add(lblErrorEmail_NH);

        jPanel48.add(jPanel53);

        jPanel40.add(jPanel48);

        jPanel49.setBorder(javax.swing.BorderFactory.createTitledBorder("Ghi chú"));
        jPanel49.setLayout(new java.awt.BorderLayout());

        txtNote_NH.setColumns(20);
        txtNote_NH.setRows(5);
        jScrollPane6.setViewportView(txtNote_NH);

        jPanel49.add(jScrollPane6, java.awt.BorderLayout.CENTER);

        jPanel40.add(jPanel49);

        jPanel38.add(jPanel40);

        jPanel41.setLayout(new java.awt.BorderLayout());

        tblLeaner.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã người học", "Họ và tên", "Giới tính", "Ngày sinh", "Điện thoại", "Email", "Mã nhân viên", "Ngày nhập học"
            }
        ));
        jScrollPane1.setViewportView(tblLeaner);

        jPanel41.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel38.add(jPanel41);

        jPanel39.setLayout(new java.awt.GridLayout(1, 0));

        jPanel28.setLayout(new java.awt.GridLayout(1, 0));

        btnDelete_NH.setText("Xoá");
        btnDelete_NH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete_NHActionPerformed(evt);
            }
        });
        jPanel28.add(btnDelete_NH);

        btnReset_NH.setText("Làm mới");
        btnReset_NH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReset_NHActionPerformed(evt);
            }
        });
        jPanel28.add(btnReset_NH);

        btnUpdate_NH.setText("Sửa");
        btnUpdate_NH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate_NHActionPerformed(evt);
            }
        });
        jPanel28.add(btnUpdate_NH);

        btnAdd_NH.setText("Thêm");
        btnAdd_NH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd_NHActionPerformed(evt);
            }
        });
        jPanel28.add(btnAdd_NH);

        jPanel39.add(jPanel28);

        jPanel29.setLayout(new java.awt.GridLayout(1, 0));

        jPanel86.setLayout(new java.awt.BorderLayout());

        txtID_NV.setEditable(false);
        txtID_NV.setText("NV01");
        jPanel86.add(txtID_NV, java.awt.BorderLayout.CENTER);

        jPanel29.add(jPanel86);

        javax.swing.GroupLayout jPanel88Layout = new javax.swing.GroupLayout(jPanel88);
        jPanel88.setLayout(jPanel88Layout);
        jPanel88Layout.setHorizontalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 258, Short.MAX_VALUE)
        );
        jPanel88Layout.setVerticalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 445, Short.MAX_VALUE)
        );

        jPanel29.add(jPanel88);

        jPanel39.add(jPanel29);

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlLearnerLayout = new javax.swing.GroupLayout(pnlLearner);
        pnlLearner.setLayout(pnlLearnerLayout);
        pnlLearnerLayout.setHorizontalGroup(
            pnlLearnerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLearnerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlLearnerLayout.setVerticalGroup(
            pnlLearnerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlLearnerLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlLearnerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlLearner, "card2");

        lblTurnOff4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff4MouseClicked(evt);
            }
        });

        jPanel33.setLayout(new java.awt.CardLayout());

        jLabel24.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 255, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("TRANG CHỦ");
        jPanel33.add(jLabel24, "card2");

        javax.swing.GroupLayout pnlHomeLayout = new javax.swing.GroupLayout(pnlHome);
        pnlHome.setLayout(pnlHomeLayout);
        pnlHomeLayout.setHorizontalGroup(
            pnlHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel33, javax.swing.GroupLayout.DEFAULT_SIZE, 965, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff4, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlHomeLayout.setVerticalGroup(
            pnlHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHomeLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(1008, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlHome, "card2");

        pnlStaff.setForeground(new java.awt.Color(204, 0, 0));
        pnlStaff.setToolTipText("");

        lblTurnOff5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff5MouseClicked(evt);
            }
        });

        jPanel30.setLayout(new java.awt.CardLayout());

        jLabel25.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 255, 255));
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("QUẢN LÝ NHÂN VIÊN");
        jPanel30.add(jLabel25, "card2");

        jPanel54.setLayout(new java.awt.GridLayout(1, 2));

        jPanel55.setLayout(new java.awt.GridLayout(5, 1));

        jPanel56.setBorder(javax.swing.BorderFactory.createTitledBorder("Mã nhân viên"));
        jPanel56.setLayout(new java.awt.GridLayout(2, 0));
        jPanel56.add(txtIDStaff_NV);

        lblErrorIDStaff_NV.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorIDStaff_NV.setToolTipText("");
        jPanel56.add(lblErrorIDStaff_NV);

        jPanel55.add(jPanel56);

        jPanel57.setBorder(javax.swing.BorderFactory.createTitledBorder("Họ và tên"));
        jPanel57.setLayout(new java.awt.GridLayout(2, 0));
        jPanel57.add(txtName_NV);

        lblErrorName_NV.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorName_NV.setToolTipText("");
        jPanel57.add(lblErrorName_NV);

        jPanel55.add(jPanel57);

        jPanel58.setBorder(javax.swing.BorderFactory.createTitledBorder("Mật khẩu"));
        jPanel58.setLayout(new java.awt.GridLayout(2, 0));
        jPanel58.add(txtPassword_NV);

        lblErrorPass_NV.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorPass_NV.setToolTipText("");
        jPanel58.add(lblErrorPass_NV);

        jPanel55.add(jPanel58);

        jPanel59.setBorder(javax.swing.BorderFactory.createTitledBorder("Xác nhận mật khẩu"));
        jPanel59.setLayout(new java.awt.GridLayout(2, 0));
        jPanel59.add(txtConfirmPass_NV);

        lblErrorConfirm_NV.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorConfirm_NV.setToolTipText("");
        jPanel59.add(lblErrorConfirm_NV);

        jPanel55.add(jPanel59);

        jPanel60.setBorder(javax.swing.BorderFactory.createTitledBorder("Vai trò"));
        jPanel60.setLayout(new java.awt.GridLayout(2, 0));

        btnG_VT.add(rdoManager_NV);
        rdoManager_NV.setText("Trưởng phòng");
        jPanel60.add(rdoManager_NV);

        btnG_VT.add(rdoStaff_NV);
        rdoStaff_NV.setText("Nhân viên");
        jPanel60.add(rdoStaff_NV);

        jPanel55.add(jPanel60);

        jPanel54.add(jPanel55);

        jPanel63.setLayout(new java.awt.BorderLayout());

        tblStaff.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã nhân viên", "Họ và tên", "Mật khẩu", "Vai trò"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(tblStaff);

        jPanel63.add(jScrollPane8, java.awt.BorderLayout.CENTER);

        jPanel54.add(jPanel63);

        jPanel64.setLayout(new java.awt.GridLayout(1, 3));

        jPanel65.setLayout(new java.awt.GridLayout(1, 0));

        btnDelete_NV.setText("Xoá");
        btnDelete_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete_NVActionPerformed(evt);
            }
        });
        jPanel65.add(btnDelete_NV);

        btnReset_NV.setText("Làm mới");
        btnReset_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReset_NVActionPerformed(evt);
            }
        });
        jPanel65.add(btnReset_NV);

        btnUpdate_NV.setText("Sửa");
        btnUpdate_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdate_NVActionPerformed(evt);
            }
        });
        jPanel65.add(btnUpdate_NV);

        btnAdd_NV.setText("Thêm");
        btnAdd_NV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd_NVActionPerformed(evt);
            }
        });
        jPanel65.add(btnAdd_NV);

        jPanel64.add(jPanel65);

        javax.swing.GroupLayout jPanel66Layout = new javax.swing.GroupLayout(jPanel66);
        jPanel66.setLayout(jPanel66Layout);
        jPanel66Layout.setHorizontalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 516, Short.MAX_VALUE)
        );
        jPanel66Layout.setVerticalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );

        jPanel64.add(jPanel66);

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel54, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addComponent(jPanel64, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jPanel54, javax.swing.GroupLayout.DEFAULT_SIZE, 934, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel64, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlStaffLayout = new javax.swing.GroupLayout(pnlStaff);
        pnlStaff.setLayout(pnlStaffLayout);
        pnlStaffLayout.setHorizontalGroup(
            pnlStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaffLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlStaffLayout.setVerticalGroup(
            pnlStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStaffLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlStaffLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlStaff, "card2");

        lblTurnOff6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTurnOff6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/turnOff-32px.png"))); // NOI18N
        lblTurnOff6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTurnOff6MouseClicked(evt);
            }
        });

        jPanel32.setLayout(new java.awt.CardLayout());

        jLabel29.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 255, 255));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("QUẢN LÝ HỌC VIÊN");
        jPanel32.add(jLabel29, "card2");

        jPanel62.setLayout(new java.awt.GridLayout(1, 0));

        jPanel67.setBorder(javax.swing.BorderFactory.createTitledBorder("Chuyên đề"));
        jPanel67.setLayout(new java.awt.BorderLayout());

        cboNameCD_HV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel67.add(cboNameCD_HV, java.awt.BorderLayout.CENTER);

        jPanel62.add(jPanel67);

        jPanel68.setBorder(javax.swing.BorderFactory.createTitledBorder("Khoá học"));
        jPanel68.setLayout(new java.awt.BorderLayout());

        cboNameKH_HV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel68.add(cboNameKH_HV, java.awt.BorderLayout.CENTER);

        jPanel62.add(jPanel68);

        jPanel69.setLayout(new java.awt.GridLayout(1, 0));

        jPanel72.setLayout(new java.awt.BorderLayout());

        tblHV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã học viên", "Mã người học", "Họ và tên", "Điểm"
            }
        ));
        jScrollPane7.setViewportView(tblHV);

        jPanel72.add(jScrollPane7, java.awt.BorderLayout.CENTER);

        jPanel73.setLayout(new java.awt.GridLayout(1, 0));

        btnDelete_HV.setText("Xoá khỏi khoá học");
        btnDelete_HV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete_HVActionPerformed(evt);
            }
        });
        jPanel73.add(btnDelete_HV);

        btnUpdateMark_HV.setText("Cập nhật điểm");
        btnUpdateMark_HV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateMark_HVActionPerformed(evt);
            }
        });
        jPanel73.add(btnUpdateMark_HV);

        javax.swing.GroupLayout jPanel70Layout = new javax.swing.GroupLayout(jPanel70);
        jPanel70.setLayout(jPanel70Layout);
        jPanel70Layout.setHorizontalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel70Layout.createSequentialGroup()
                .addComponent(jPanel73, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel70Layout.setVerticalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel70Layout.createSequentialGroup()
                .addComponent(jPanel72, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel73, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel69.add(jPanel70);

        jPanel74.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm kiếm"));
        jPanel74.setLayout(new java.awt.BorderLayout());

        lblFindHV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/search.png"))); // NOI18N
        lblFindHV.setText("Tìm kiếm");
        lblFindHV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblFindHVMouseClicked(evt);
            }
        });
        jPanel74.add(lblFindHV, java.awt.BorderLayout.LINE_END);
        jPanel74.add(txtFind_HV, java.awt.BorderLayout.CENTER);

        jPanel75.setLayout(new java.awt.BorderLayout());

        tblStudent_HV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã người học", "Họ và tên", "Giới tính", "Ngày sinh", "Điện thoại", "Email"
            }
        ));
        jScrollPane9.setViewportView(tblStudent_HV);

        jPanel75.add(jScrollPane9, java.awt.BorderLayout.CENTER);

        jPanel76.setLayout(new java.awt.GridLayout(1, 0));

        javax.swing.GroupLayout jPanel77Layout = new javax.swing.GroupLayout(jPanel77);
        jPanel77.setLayout(jPanel77Layout);
        jPanel77Layout.setHorizontalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 256, Short.MAX_VALUE)
        );
        jPanel77Layout.setVerticalGroup(
            jPanel77Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
        );

        jPanel76.add(jPanel77);

        btnAdd_HV.setText("Thêm vào khoá học");
        btnAdd_HV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdd_HVActionPerformed(evt);
            }
        });
        jPanel76.add(btnAdd_HV);

        javax.swing.GroupLayout jPanel71Layout = new javax.swing.GroupLayout(jPanel71);
        jPanel71.setLayout(jPanel71Layout);
        jPanel71Layout.setHorizontalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel74, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel75, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel76, javax.swing.GroupLayout.DEFAULT_SIZE, 513, Short.MAX_VALUE)
        );
        jPanel71Layout.setVerticalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel71Layout.createSequentialGroup()
                .addComponent(jPanel74, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel75, javax.swing.GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel76, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel69.add(jPanel71);

        javax.swing.GroupLayout jPanel61Layout = new javax.swing.GroupLayout(jPanel61);
        jPanel61.setLayout(jPanel61Layout);
        jPanel61Layout.setHorizontalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel62, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel69, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel61Layout.setVerticalGroup(
            jPanel61Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel61Layout.createSequentialGroup()
                .addComponent(jPanel62, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel69, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlStudentsLayout = new javax.swing.GroupLayout(pnlStudents);
        pnlStudents.setLayout(pnlStudentsLayout);
        pnlStudentsLayout.setHorizontalGroup(
            pnlStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStudentsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTurnOff6, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6))
            .addComponent(jPanel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnlStudentsLayout.setVerticalGroup(
            pnlStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlStudentsLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(pnlStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTurnOff6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel61, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlEdition.add(pnlStudents, "card2");

        javax.swing.GroupLayout pnlDisplayLayout = new javax.swing.GroupLayout(pnlDisplay);
        pnlDisplay.setLayout(pnlDisplayLayout);
        pnlDisplayLayout.setHorizontalGroup(
            pnlDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDisplayLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(pnlMiniMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlEdition, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDisplayLayout.setVerticalGroup(
            pnlDisplayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlEdition, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlMiniMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private boolean isMenuOpen = false; // Biến flag để theo dõi trạng thái của thanh menu

    private void lblMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMenuMouseClicked
        if (isMenuOpen) {
            closeMenubar();
            disShowText();
        } else {
            openMenubar();
            showTextNextToIcon();
        }
        isMenuOpen = !isMenuOpen; // Đảo ngược giá trị của biến flag sau mỗi lần nhấp vào;
    }//GEN-LAST:event_lblMenuMouseClicked

    private void lblHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHomeMouseClicked
        pnlCourse.setVisible(false);
        pnlThematic.setVisible(false);
        pnlStatic.setVisible(false);
        pnlLearner.setVisible(false);
        pnlStaff.setVisible(false);
        pnlStudents.setVisible(false);
        pnlHome.setVisible(true);
    }//GEN-LAST:event_lblHomeMouseClicked

    private void lblHomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHomeMouseEntered
        lblHome.setBorder(border);
    }//GEN-LAST:event_lblHomeMouseEntered

    private void lblHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHomeMouseExited
        // TODO add your handling code here:
        lblHome.setBorder(null);
    }//GEN-LAST:event_lblHomeMouseExited

    private void lblCouseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCouseMouseEntered
        lblCouse.setBorder(border);
    }//GEN-LAST:event_lblCouseMouseEntered

    private void lblCouseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCouseMouseExited
        lblCouse.setBorder(null);
    }//GEN-LAST:event_lblCouseMouseExited

    private void lblStudentMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStudentMouseEntered
        // TODO add your handling code here:
        lblStudent.setBorder(border);
    }//GEN-LAST:event_lblStudentMouseEntered

    private void lblStudentMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStudentMouseExited
        lblStudent.setBorder(null);
    }//GEN-LAST:event_lblStudentMouseExited

    private void lblStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStaffMouseEntered
        // TODO add your handling code here:
        lblStaff.setBorder(border);
    }//GEN-LAST:event_lblStaffMouseEntered

    private void lblStaffMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStaffMouseExited
        lblStaff.setBorder(null);
    }//GEN-LAST:event_lblStaffMouseExited

    private void lblLeanerMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLeanerMouseEntered
        lblLeaner.setBorder(border);
    }//GEN-LAST:event_lblLeanerMouseEntered

    private void lblLeanerMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLeanerMouseExited
        // TODO add your handling code here:
        lblLeaner.setBorder(null);
    }//GEN-LAST:event_lblLeanerMouseExited

    private void lblStatisticalMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStatisticalMouseEntered
        lblStatistical.setBorder(border);
    }//GEN-LAST:event_lblStatisticalMouseEntered

    private void lblStatisticalMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStatisticalMouseExited
        lblStatistical.setBorder(null);
    }//GEN-LAST:event_lblStatisticalMouseExited

    private void lblExitMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitMouseExited
        lblExit.setBorder(null);
    }//GEN-LAST:event_lblExitMouseExited

    private void lblExitMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitMouseEntered
        lblExit.setBorder(border);
    }//GEN-LAST:event_lblExitMouseEntered

    private void lblTurnOff1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff1MouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOff1MouseClicked

    private void lblCouseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCouseMouseClicked
        pnlStatic.setVisible(false);
        pnlThematic.setVisible(false);
        pnlStaff.setVisible(false);
        pnlStudents.setVisible(false);
        pnlCourse.setVisible(true);
        pnlLearner.setVisible(false);
        pnlHome.setVisible(false);
    }//GEN-LAST:event_lblCouseMouseClicked

    private void lblExitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblExitMouseClicked
        // Hiển thị hộp thoại xác nhận
        UIManager.put("OptionPane.yesButtonText", "Chắc chắn");
        UIManager.put("OptionPane.noButtonText", "Chưa chắc chắn");
        int option = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        // Kiểm tra xem người dùng đã nhấn Yes hay No
        if (option == JOptionPane.YES_OPTION) {
            // Đóng form hiện tại (form admin)
            JOptionPane.showMessageDialog(this, "Đã thoát chương trình");
            this.dispose();

            // Mở màn hình đăng nhập
            formLog demo = new formLog();
            demo.setVisible(true);
        }
    }//GEN-LAST:event_lblExitMouseClicked

    private void lblTurnOff2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff2MouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOff2MouseClicked

    private void lblStatisticalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStatisticalMouseClicked
        loadTable_CHUYENDE_TK();
        loadTable_NGUOI_HOC_TK();

        pnlThematic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlStaff.setVisible(false);
        pnlLearner.setVisible(false);
        pnlHome.setVisible(false);
        pnlStatic.setVisible(true);
        pnlStudents.setVisible(false);
    }//GEN-LAST:event_lblStatisticalMouseClicked

    private void lblTurnOff3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff3MouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOff3MouseClicked

    private void lblStudentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStudentMouseClicked
        // TODO add your handling code here:
        pnlLearner.setVisible(true);
        pnlThematic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlStaff.setVisible(false);
        pnlHome.setVisible(false);
        pnlStudents.setVisible(false);
        pnlStatic.setVisible(false);
    }//GEN-LAST:event_lblStudentMouseClicked

    private void lblTurnOff4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff4MouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOff4MouseClicked

    private void lblTurnOff5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff5MouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOff5MouseClicked

    private void lblStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblStaffMouseClicked
        // TODO add your handling code here:
        pnlLearner.setVisible(false);
        pnlThematic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlHome.setVisible(false);
        pnlStatic.setVisible(false);
        pnlStudents.setVisible(false);
        pnlStaff.setVisible(true);

    }//GEN-LAST:event_lblStaffMouseClicked

    private void lblTurnOff6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOff6MouseClicked
        turnOff();    }//GEN-LAST:event_lblTurnOff6MouseClicked

    private void lblLeanerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblLeanerMouseClicked
        // TODO add your handling code here:
        pnlLearner.setVisible(false);
        pnlThematic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlHome.setVisible(false);
        pnlStaff.setVisible(false);
        pnlStatic.setVisible(false);
        pnlStudents.setVisible(true);
    }//GEN-LAST:event_lblLeanerMouseClicked

    private void btnReset_KHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReset_KHActionPerformed
        txtDate_KH.setText("");
        txtID_KH.setText("");
        txtNote_KH.setText("");
        txtTime_KH.setText("");
        txtUser_KH.setText("");
        txtOpening_KH.setText("");
        txtTuition_KH.setText("");
        lblErrorUser_KH.setText("");
        lblErrorID_KH.setText("");
        lblErrorDate_KH.setText("");
        lblErrorOpening_KH.setText("");
        lblErrorTime_KH.setText("");
        lblErrorTuiltion_KH.setText("");

    }//GEN-LAST:event_btnReset_KHActionPerformed

    private void btnReset_NHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReset_NHActionPerformed
        txtBrithday_NH.setText("");
        txtID_NH.setText("");
        txtEmail_NH.setText("");
        txtName_NH.setText("");
        txtNote_KH.setText("");
        txtPhone_NH.setText("");
        lblErrorBrithday_NH.setText("");
        lblErrorEmail_NH.setText("");
        lblErrorLeaner_NH.setText("");
        lblErrorName_NH.setText("");
        lblErrorPhone_NH.setText("");
        rdoMale_NH.setSelected(true);
    }//GEN-LAST:event_btnReset_NHActionPerformed

    private void btnReset_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReset_NVActionPerformed
        txtConfirmPass_NV.setText("");
        txtIDStaff_NV.setText("");
        txtName_NV.setText("");
        txtPassword_NV.setText("");
        rdoStaff_NV.setSelected(true);
        lblErrorConfirm_NV.setText("");
        lblErrorIDStaff_NV.setText("");
        lblErrorName_NV.setText("");
        lblErrorPass_NV.setText("");
    }//GEN-LAST:event_btnReset_NVActionPerformed

    private void loadTable_CD() {
        DefaultTableModel model = (DefaultTableModel) tbl_CD.getModel();
        model.setRowCount(0); // Xóa hết các dòng trong bảng trước khi điền dữ liệu mới

        String query = "SELECT * FROM  CHUYEN_DE";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                String ID_CD = rs.getString("MA_CD");
                String name = rs.getNString("TEN_CD");
                String tuition = rs.getString("HOC_PHI");
                String time = rs.getString("THOI_LUONG");
                String img = rs.getString("HINH");
                String note = rs.getString("MO_TA");

                // Thêm một hàng mới vào bảng với thông tin của sinh viên
                model.addRow(new Object[]{ID_CD, name, tuition, time, img, note});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi hiển thị thông tin: " + ex.getMessage());
        }
    }

    private boolean checkInfor_CD() {
        boolean allFieldsFilled = true; // Khởi tạo biến boolean và gán giá trị mặc định là true

        // Kiểm tra từng trường nhập liệu
        if (txtID_CD.getText().isBlank()) {
            lblErrorID_CD.setText("Mã chuyên đề không được để trống. Gợi ý: Bạn có thể nhấp enter để tạo mã ngẫu nhiên");
            allFieldsFilled = false;
        } else if (!txtID_CD.getText().matches("^CD\\d+$")) {
            lblErrorID_CD.setText("Mã chuyên đề phải bắt đầu bằng 'CD' và tiếp theo là các chữ số.");
            allFieldsFilled = false;
        } else {
            lblErrorID_CD.setText("");
        }

        if (txtName_CD.getText().isBlank()) {
            lblErrorName_CD.setText("Tên không được để trống.");
            allFieldsFilled = false; // Nếu trường tên trống, đặt biến allFieldsFilled thành false
        } else if (txtName_CD.getText().matches(".*\\d.*")) {
            lblErrorName_CD.setText("Tên không được chứa số.");
            allFieldsFilled = false; // Nếu tên chứa số, đặt biến allFieldsFilled thành false
        } else {
            lblErrorName_CD.setText("");
        }

        // Kiểm tra trường học phí
        String tuition = txtTuition_CD.getText();
        if (tuition.isBlank()) {
            lblErrorTuition_CD.setText("Học phí không được để trống.");
            allFieldsFilled = false; // Nếu trường học phí trống, đặt biến allFieldsFilled thành false
        } else if (!tuition.matches("\\d+")) {
            lblErrorTuition_CD.setText("Học phí phải là số.");
            allFieldsFilled = false; // Nếu học phí không phải số, đặt biến allFieldsFilled thành false
        } else {
            lblErrorTuition_CD.setText("");
        }

        // Kiểm tra trường thời gian
        String time = txtTime_CD.getText();
        if (time.isBlank()) {
            lblErrorTime_CD.setText("Thời lượng không được để trống.");
            allFieldsFilled = false; // Nếu trường thời gian trống, đặt biến allFieldsFilled thành false
        } else if (!time.matches("\\d+")) {
            lblErrorTime_CD.setText("Thời lượng phải là số.");
            allFieldsFilled = false; // Nếu thời gian không phải số, đặt biến allFieldsFilled thành false
        } else {
            lblErrorTime_CD.setText("");
        }

        // Trả về giá trị của biến allFieldsFilled
        return allFieldsFilled;
    }

    private String incrementID(String currentID) {
        String prefix = currentID.substring(0, 2); // Lấy phần tiền tố, ví dụ: "CD"
        int number = Integer.parseInt(currentID.substring(2)); // Lấy phần số, ví dụ: 09

        // Tăng số lên một đơn vị và định dạng lại với độ dài cố định là 2
        String newNumber = String.format("%02d", number + 1);

        // Kết hợp phần tiền tố và phần số mới
        return prefix + newNumber;
    }

    private void loadComboBoxData_KHOA_HOC() {
        //String query = "SELECT A.MA_CD, A.TEN_CD, NGAY_TAO FROM CHUYEN_DE A INNER JOIN KHOA_HOC B ON A.MA_CD = B.MA_CD";
        String query = "SELECT * FROM CHUYEN_DE ";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {

            // Xóa các mục hiện có trong JComboBox
            cboKH.removeAllItems();

            // Điền JComboBox với dữ liệu được truy xuất
            while (rs.next()) {
                String maCD = rs.getString("MA_CD");
                String tenCD = rs.getString("TEN_CD");
                //Date ngayTao = rs.getDate("NGAY_TAO");
                // Kết hợp mã chuyên đề, tên chuyên đề và ngày tạo thành một chuỗi
                // String tenCDNgayTao = maCD + " - " + tenCD + " - " + ngayTao.toString(); // Cần định dạng lại ngày tạo nếu cần
                String tenCDNgayTao = maCD + " - " + tenCD; // Cần định dạng lại ngày tạo nếu cần
                cboKH.addItem(tenCDNgayTao);
            }

            // Đảm bảo một mục được chọn để hiển thị ngay từ đầu
            if (cboKH.getItemCount() > 0) {
                cboKH.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    private void initComboBoxListener() {
        // Thêm ActionListener cho JComboBox cboKH
        cboKH.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                // Kiểm tra xem một mục có được chọn hay không
                if (cboKH.getSelectedItem() != null) {
                    // Lấy tên chuyên đề được chọn
                    String selectedCD = cboKH.getSelectedItem().toString();
                    // Gọi phương thức loadCourseDetails để nạp chi tiết khóa học tương ứng
                    loadCourseDetails(selectedCD);
                }
            }
        });
    }

    private void loadCourseDetails(String tenCD) {
        // Câu truy vấn SQL để lấy chi tiết khóa học dựa trên tên chuyên đề
        String sql = "SELECT TEN_CD, TEN_NV, NGAY_TAO, NGAY_KG, C.HOC_PHI, C.THOI_LUONG "
                + "FROM KHOA_HOC A "
                + "INNER JOIN NHAN_VIEN B ON A.MA_NV = B.MA_NV "
                + "INNER JOIN CHUYEN_DE C ON C.MA_CD = A.MA_CD "
                + "WHERE C.TEN_CD = ?";

        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(sql)) {

            // Thiết lập giá trị cho tham số truy vấn
            pst.setString(1, tenCD);

            // Thực hiện truy vấn và lấy kết quả
            try ( ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    // Điền thông tin từ kết quả truy vấn vào các JTextField tương ứng
                    txtID_KH.setText(rs.getString("TEN_CD"));
                    txtUser_KH.setText(rs.getString("TEN_NV"));
                    txtDate_KH.setText(rs.getString("NGAY_TAO"));
                    txtTuition_KH.setText(rs.getString("HOC_PHI"));
                    txtTime_KH.setText(rs.getString("THOI_LUONG"));
                }
            }
        } catch (SQLException ex) {
            // Hiển thị thông báo lỗi nếu có sự cố khi nạp dữ liệu
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    // Khai báo phương thức getTenNhanVienFromMaNhanVien
    private boolean isTenNguoiTaoExists(String tenNguoiTao) {
        // Biến kiểm tra xem tên người tạo có tồn tại không
        boolean exists = false;

        // Câu truy vấn SQL để kiểm tra xem tên người tạo có tồn tại trong cơ sở dữ liệu hay không
        String query = "SELECT TEN_NV FROM KHOA_HOC A INNER JOIN NHAN_VIEN B ON A.MA_NV = B.MA_NV WHERE TEN_NV = ?";

        try (
                // Kết nối đến cơ sở dữ liệu
                 Connection con = DriverManager.getConnection(url); // Chuẩn bị câu truy vấn
                  PreparedStatement pst = con.prepareStatement(query);) {
            // Đặt giá trị cho tham số trong câu truy vấn
            pst.setString(1, tenNguoiTao);

            // Thực thi truy vấn
            try ( ResultSet rs = pst.executeQuery()) {
                // Nếu có kết quả trả về
                if (rs.next()) {
                    // Nếu tên người tạo tồn tại trong cơ sở dữ liệu, gán biến exists thành true
                    exists = true;
                }
            }
        } catch (SQLException ex) {
            // Xử lý ngoại lệ nếu có lỗi trong quá trình truy vấn cơ sở dữ liệu
            ex.printStackTrace();
        }

        // Trả về giá trị của biến exists (true nếu tên người tạo tồn tại, ngược lại trả về false)
        return exists;
    }

    private boolean isValidID_KHOA_HOC(String id) {
        // Kiểm tra xem mã có đúng định dạng NHxxx hay không
        return id.matches("^KH\\d+$");
    }

    private String getTenNhanVienFromMaNhanVien(String maNV) {
        String tenNV = ""; // Khởi tạo tên nhân viên

        // Câu truy vấn SQL để lấy tên nhân viên từ mã nhân viên
        String query = "SELECT TEN_NV FROM NHAN_VIEN WHERE MA_NV = ?";

        try (
                // Kết nối đến cơ sở dữ liệu
                 Connection con = DriverManager.getConnection(url); // Chuẩn bị câu truy vấn
                  PreparedStatement pst = con.prepareStatement(query);) {
            // Đặt giá trị cho tham số trong câu truy vấn
            pst.setString(1, maNV);

            // Thực thi truy vấn
            try ( ResultSet rs = pst.executeQuery()) {
                // Nếu có kết quả trả về
                if (rs.next()) {
                    // Lấy tên nhân viên từ kết quả truy vấn
                    tenNV = rs.getString("TEN_NV");
                } else {
                    // Nếu không có kết quả trả về, gán tên nhân viên thành null
                    tenNV = null;
                }
            }
        } catch (SQLException ex) {
            // Xử lý ngoại lệ nếu có lỗi trong quá trình truy vấn cơ sở dữ liệu
            ex.printStackTrace();
        }

        // Trả về tên nhân viên
        return tenNV;
    }

    private boolean doesEmployeeNameExist(String tenNV) {
        boolean exists = false;
        // Câu truy vấn SQL để kiểm tra tên nhân viên
        String query = "SELECT COUNT(*) FROM NHAN_VIEN WHERE TEN_NV = ?";
        try (
                // Kết nối đến cơ sở dữ liệu
                 Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);) {
            // Đặt giá trị cho tham số trong câu truy vấn
            pst.setString(1, tenNV);

            // Thực thi truy vấn
            try ( ResultSet rs = pst.executeQuery()) {
                // Nếu có kết quả trả về
                if (rs.next()) {
                    exists = rs.getInt(1) > 0;
                }
            }
        } catch (SQLException ex) {
            // Xử lý ngoại lệ nếu có lỗi trong quá trình truy vấn cơ sở dữ liệu
            ex.printStackTrace();
        }
        return exists;
    }

    private boolean doesEmployeeCodeExist(String maNV) {
        boolean exists = false;
        // Câu truy vấn SQL để kiểm tra mã nhân viên
        String query = "SELECT COUNT(*) FROM NHAN_VIEN WHERE MA_NV = ?";
        try (
                // Kết nối đến cơ sở dữ liệu
                 Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);) {
            // Đặt giá trị cho tham số trong câu truy vấn
            pst.setString(1, maNV);

            // Thực thi truy vấn
            try ( ResultSet rs = pst.executeQuery()) {
                // Nếu có kết quả trả về
                if (rs.next()) {
                    exists = rs.getInt(1) > 0;
                }
            }
        } catch (SQLException ex) {
            // Xử lý ngoại lệ nếu có lỗi trong quá trình truy vấn cơ sở dữ liệu
            ex.printStackTrace();
        }
        return exists;
    }

    private boolean checkInfor_KH() {
        boolean isValid = true;
        // Kiểm tra mã khóa học
        if (txtID_KH.getText().isEmpty()) {
            lblErrorID_KH.setText("Mã khoá học không được bỏ trống. Gợi ý: Bạn có thể nhấp enter để tạo mã ngẫu nhiên");
            isValid = false;
        } else if (!isValidID_KHOA_HOC(txtID_KH.getText().trim())) {
            lblErrorID_KH.setText("Mã khoá học phải bắt đầu chữ 'KH' và kế tiếp nó là số ");
            isValid = false;
        } else {
            lblErrorID_KH.setText("");
        }
        // Kiểm tra thời lượng khóa học
        String thoiLuong = txtTime_KH.getText().trim();
        if (thoiLuong.isEmpty()) {
            lblErrorTime_KH.setText("Thời lượng không được bỏ trống");
            isValid = false;
        } else if (!thoiLuong.matches("\\d+")) {
            lblErrorTime_KH.setText("Thời lượng phải là số");
            isValid = false;
        } else {
            lblErrorTime_KH.setText("");
        }
        // Kiểm tra học phí khóa học
        String hocPhi = txtTuition_KH.getText().trim();
        if (hocPhi.isEmpty()) {
            lblErrorTuiltion_KH.setText("Học phí không được bỏ trống");
            isValid = false;
        } else if (!hocPhi.matches("\\d+")) {
            lblErrorTuiltion_KH.setText("Học phí phải là số");
            isValid = false;
        } else {
            lblErrorTuiltion_KH.setText("");
        }
        // Kiểm tra tên người tạo
        String tenNguoiTao = txtUser_KH.getText().trim();
        if (tenNguoiTao.isEmpty()) {
            lblErrorUser_KH.setText("Tên người tạo không được bỏ trống");
            isValid = false;
        } else {
            if (tenNguoiTao.matches("nv\\d+")) {
                // Kiểm tra mã nhân viên
                if (!doesEmployeeCodeExist(tenNguoiTao)) {
                    lblErrorUser_KH.setText("Mã nhân viên không tồn tại trong cơ sở dữ liệu. Gợi ý: bạn có thể nhập mã nhân viên và enter.");
                    isValid = false;
                } else if (doesEmployeeCodeExist(tenNguoiTao)) {
                    lblErrorUser_KH.setText("Bạn hãy nhấp enter để ra tên người tạo");
                    isValid = false;
                } else {
                    lblErrorUser_KH.setText("");
                }
            } else {
                if (tenNguoiTao.matches(".*\\d.*")) {
                    lblErrorUser_KH.setText("Tên không được chứa số hoặc không tồn tại");
                    isValid = false;
                } // Kiểm tra tên nhân viên
                else if (!doesEmployeeNameExist(tenNguoiTao)) {
                    lblErrorUser_KH.setText("Tên nhân viên không tồn tại trong cơ sở dữ liệu. Gợi ý: bạn có thể nhập mã nhân viên và enter.");
                    isValid = false;
                } else {
                    lblErrorUser_KH.setText("");
                }
            }
        }
        // Kiểm tra ngày tạo
        String ngayTao = txtDate_KH.getText().trim();
        if (ngayTao.isEmpty()) {
            lblErrorDate_KH.setText("Ngày tạo không được bỏ trống. Gợi ý: Bạn có thể nhấn Enter để lấy ngày hiện tại!!");
            isValid = false;
        } else if (!ngayTao.matches("\\d{4}-\\d{2}-\\d{2}")) {
            lblErrorDate_KH.setText("Định dạng ngày phải là yyyy-MM-dd");
            isValid = false;
        } else {
            try {
                LocalDate ngayTaoDate = LocalDate.parse(ngayTao, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                LocalDate ngayHienTai = LocalDate.now();

                // Kiểm tra xem ngày tạo có lớn hơn ngày hiện tại không
                if (ngayTaoDate.isAfter(ngayHienTai)) {
                    lblErrorDate_KH.setText("Ngày tạo không thể sau ngày hiện tại");
                    isValid = false;
                } else {
                    lblErrorDate_KH.setText("");
                }
            } catch (DateTimeParseException e) {
                lblErrorDate_KH.setText("Ngày tạo không hợp lệ");
                isValid = false;
            }
        }
        // Kiểm tra ngày khai giảng
        String openingDate = txtOpening_KH.getText().trim();
        if (openingDate.isEmpty()) {
            lblErrorOpening_KH.setText("Ngày khai giảng không được bỏ trống");
            isValid = false;
        } else if (!openingDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
            lblErrorOpening_KH.setText("Định dạng ngày phải là yyyy-MM-dd");
            isValid = false;
        } else {
            try {
                LocalDate ngayKhaiGiang = LocalDate.parse(openingDate, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                LocalDate ngayHienTai = LocalDate.now();

                // Kiểm tra xem ngày khai giảng có lớn hơn ngày hiện tại không
                if (ngayKhaiGiang.isBefore(ngayHienTai)) {
                    lblErrorOpening_KH.setText("Ngày khai giảng phải là ngày trong tương lai");
                    isValid = false;
                } else {
                    lblErrorOpening_KH.setText("");
                }
            } catch (DateTimeParseException e) {
                lblErrorOpening_KH.setText("Ngày khai giảng không hợp lệ");
                isValid = false;
            }
        }

        return isValid;
    }

    private void setComboBoxItemByMaKH(String maKH) {
        String query = "SELECT MA_CD FROM KHOA_HOC WHERE MA_KH = ?";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, maKH);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String maCD = rs.getString("MA_CD");
                for (int i = 0; i < cboKH.getItemCount(); i++) {
                    if (cboKH.getItemAt(i).toString().startsWith(maCD)) {
                        cboKH.setSelectedIndex(i);
                        break;
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi truy vấn CSDL: " + ex.getMessage());
        }
    }

    private void clickTable_KHOA_HOC() {
        tblKH.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is not adjusting and a row is selected
                if (!e.getValueIsAdjusting() && tblKH.getSelectedRow() != -1) {
                    // Get the selected row index
                    int selectedRow = tblKH.getSelectedRow();
                    // Populate input fields with data from the selected row
                    txtID_KH.setText(tblKH.getValueAt(selectedRow, 0).toString());
                    txtTime_KH.setText(tblKH.getValueAt(selectedRow, 1).toString());
                    txtTuition_KH.setText(tblKH.getValueAt(selectedRow, 2).toString());
                    txtOpening_KH.setText(tblKH.getValueAt(selectedRow, 3).toString());
                    txtUser_KH.setText(tblKH.getValueAt(selectedRow, 4).toString());
                    txtDate_KH.setText(tblKH.getValueAt(selectedRow, 5).toString());

                    // Lấy giá trị từ cột đầu tiên của bảng
                    String firstColumnValue = tblKH.getValueAt(selectedRow, 0).toString();

                    // Set ComboBox item based on the value from the first column
                    setComboBoxItemByMaKH(firstColumnValue);
                }
            }
        });
    }

    private String getMaChuyenDe(String tenChuyenDe, String ngayTao) {
        String maChuyenDe = null;
        String query = "SELECT MA_CD FROM CHUYEN_DE A INNER JOIN KHOA_HOC B ON A.MA_CD = B.MA_CD WHERE TEN_CD LIKE ? OR NGAY_TAO LIKE ?";

        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, tenChuyenDe);
            pst.setDate(2, java.sql.Date.valueOf(ngayTao));

            try ( ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    maChuyenDe = rs.getString("MA_CD");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi lấy mã chuyên đề: " + ex.getMessage());
        }
        return maChuyenDe;
    }

    private String getMaNhanVienFromTenNhanVien(String tenNhanVien) {
        String maNhanVien = null;
        String query = "SELECT MA_NV FROM NHAN_VIEN WHERE TEN_NV = ?";

        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, tenNhanVien);

            try ( ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    maNhanVien = rs.getString("MA_NV");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi lấy mã nhân viên: " + ex.getMessage());
        }
        return maNhanVien;
    }

    private void btnAdd_KHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd_KHActionPerformed
        if (checkInfor_KH()) {
            String maKH = txtID_KH.getText().trim();
            String nguoiTao = txtUser_KH.getText().trim();
            String maNhanVien = getMaNhanVienFromTenNhanVien(nguoiTao);
            String khaiGiang = txtOpening_KH.getText().trim();
            String hocPhi = txtTuition_KH.getText().trim();
            String ngayTao = txtDate_KH.getText().trim();
            String thoiLuong = txtTime_KH.getText().trim();
            String tenCDNgayTao = cboKH.getSelectedItem().toString();
            String maChuyenDe = tenCDNgayTao.split(" - ")[0];

            // Lấy mã chuyên đề từ cơ sở dữ liệu
            String insertQuery = "INSERT INTO KHOA_HOC (MA_KH, MA_NV, MA_CD, NGAY_TAO, NGAY_KG, HOC_PHI, THOI_LUONG, GHI_CHU) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(insertQuery)) {
                pst.setString(1, maKH);  // Đặt giá trị cho tham số thứ nhất
                pst.setString(2, maNhanVien);
                pst.setString(3, maChuyenDe);
                pst.setDate(4, java.sql.Date.valueOf(ngayTao));
                pst.setDate(5, java.sql.Date.valueOf(khaiGiang));
                pst.setString(6, hocPhi);
                pst.setString(7, thoiLuong);
                pst.setString(8, ""); // Giả sử GHI_CHU là tùy chọn và có thể để trống

                int affectedRows = pst.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Thêm khoá học thành công!");
                    loadTable_KH(); // Làm mới dữ liệu bảng
                    loadComboBoxData_HOC_VIEN_KH();
                    String newID = incrementID(maKH);
                    txtID_KH.setText(newID);
                    txtDate_KH.setText("");
                    txtNote_KH.setText("");
                    txtOpening_KH.setText("");
                    txtTime_KH.setText("");
                    txtUser_KH.setText("");
                    txtTuition_KH.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm khoá học thất bại.");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi thêm khoá học: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng kiểm tra lại các lỗi đã được báo.");
        }
    }//GEN-LAST:event_btnAdd_KHActionPerformed

    private boolean deleteCourse(String maKH) {
        String sql = "DELETE FROM KHOA_HOC WHERE MA_KH = ?";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, maKH);
            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi khi xóa khóa học: " + ex.getMessage());
            return false;
        }
    }
    private void btnDelete_KHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete_KHActionPerformed
        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblKH.getSelectedRow();
        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maKH = tblKH.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã khóa học
            // Hiển thị hỏi người dùng xác nhận việc xóa
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn xóa khóa học này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện xóa từ cơ sở dữ liệu
                if (deleteCourse(maKH)) {
                    // Xóa thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblKH.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Đã xóa khóa học thành công!");
                    loadComboBoxData_HOC_VIEN_KH();
                    loadComboBoxData_KHOA_HOC();
                } else {
                    // Xóa thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể xóa khóa học. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn một khóa học để xóa.");
        }
    }//GEN-LAST:event_btnDelete_KHActionPerformed

    private boolean isValidLearnerID(String id) {
        // Kiểm tra xem mã có đúng định dạng NHxxx hay không
        return id.matches("^NH\\d+$");
    }

    private void loadTable_NGUOI_HOC() {
        DefaultTableModel model = (DefaultTableModel) tblLeaner.getModel();
        model.setRowCount(0); // Clear the existing rows in the table model
        String query = "SELECT * FROM NGUOI_HOC A INNER JOIN NHAN_VIEN B ON A.MA_NV = B.MA_NV ";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                String maNH = rs.getString("MA_NH");
                String maNV = rs.getString("MA_NV");
                String tenNH = rs.getString("TEN_NH");
                Date ngaySinh = rs.getDate("NGAY_SINH");
                String gioiTinh = rs.getString("GIOI_TINH");
                String dienThoai = rs.getString("DIEN_THOAI");
                String email = rs.getString("EMAIL");
                Date ngayDK = rs.getDate("NGAY_DK");
                // Add a new row to the table model with the retrieved values
                model.addRow(new Object[]{maNH, tenNH, gioiTinh, ngaySinh, dienThoai, email, maNV, ngayDK});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    private boolean checkInfor_NH() {
        boolean isValid = true;

        // Kiểm tra trống mã người học
        if (txtID_NH.getText().isEmpty()) {
            lblErrorLeaner_NH.setText("Mã người học không được bỏ trống. Gợi ý: Bạn có thể nhấp enter để tạo mã ngẫu nhiên");
            isValid = false;
        } else if (!isValidLearnerID(txtID_NH.getText().trim())) {
            lblErrorLeaner_NH.setText("Mã người học phải bắt đầu 'NH' và kế tiếp là chữ số");
            isValid = false;
        } else {
            lblErrorLeaner_NH.setText("");
        }

        // Kiểm tra trống tên người học
        if (txtName_NH.getText().isEmpty()) {
            lblErrorName_NH.setText("Tên người học không được bỏ trống");
            isValid = false;
        } else if (txtName_NH.getText().matches(".*\\d.*")) {
            lblErrorName_NH.setText("Tên không được chứa số");
            isValid = false;
        } else {
            lblErrorName_NH.setText("");
        }

        // Kiểm tra trống ngày sinh và định dạng ngày
        if (txtBrithday_NH.getText().isEmpty()) {
            lblErrorBrithday_NH.setText("Ngày sinh không được bỏ trống");
            isValid = false;
        } else if (!txtBrithday_NH.getText().matches("\\d{4}-\\d{2}-\\d{2}")) {
            lblErrorBrithday_NH.setText("Ngày sinh phải là yyyy-mm-dd");
            isValid = false;
        } else {
            // Kiểm tra nếu không phải là định dạng ngày
            String[] parts = txtBrithday_NH.getText().split("-");
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            int day = Integer.parseInt(parts[2]);
            if (year < 1900 || year > 9999 || month < 1 || month > 12 || day < 1 || day > 31) {
                lblErrorBrithday_NH.setText("Ngày sinh không hợp lệ");
                isValid = false;
            } else {
                lblErrorBrithday_NH.setText("");
            }
        }

        // Kiểm tra trống số điện thoại và định dạng số điện thoại
        if (txtPhone_NH.getText().isEmpty()) {
            lblErrorPhone_NH.setText("Số điện thoại không được bỏ trống");
            isValid = false;
        } else if (!txtPhone_NH.getText().matches("\\d+")) {
            lblErrorPhone_NH.setText("Số điện thoại phải là số");
            isValid = false;
        } else if (!txtPhone_NH.getText().matches("\\d{10}")) {
            lblErrorPhone_NH.setText("Số điện thoại phải có 10 số");
            isValid = false;
        } else {
            lblErrorPhone_NH.setText("");
        }

        // Kiểm tra trống email và định dạng email
        if (txtEmail_NH.getText().isEmpty()) {
            lblErrorEmail_NH.setText("Email không được bỏ trống.Gợi ý:Nhấp enter để tạo email tự động");
            isValid = false;
        } else if (!txtEmail_NH.getText().matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            lblErrorEmail_NH.setText("Email không đúng định dạng");
            isValid = false;
        } else {
            lblErrorEmail_NH.setText("");
        }
        return isValid;
    }
    private void btnAdd_NHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd_NHActionPerformed
        if (checkInfor_NH()) {
            String maNH = txtID_NH.getText().trim();
            String tenNH = txtName_NH.getText().trim();
            String gioiTinh = rdoMale_NH.isSelected() ? "Nam" : "Nữ";
            String ngaySinhStr = txtBrithday_NH.getText().trim();
            String dienThoai = txtPhone_NH.getText().trim();
            String email = txtEmail_NH.getText().trim();
            String maNV = txtID_NV.getText().trim(); // Giả sử currentMaNV là ID của nhân viên đang đăng nhập

            // Chuyển đổi từ String sang java.sql.Date cho ngaySinh
            java.sql.Date ngaySinh = java.sql.Date.valueOf(ngaySinhStr);

            // Lấy ngày hiện tại dưới dạng java.sql.Date
            java.sql.Date ngayDK = new java.sql.Date(System.currentTimeMillis());

            String insertQuery = "INSERT INTO NGUOI_HOC (MA_NH, TEN_NH, GIOI_TINH, NGAY_SINH, DIEN_THOAI, EMAIL, MA_NV, NGAY_DK) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(insertQuery)) {
                pst.setString(1, maNH);
                pst.setString(2, tenNH);
                pst.setString(3, gioiTinh);
                pst.setDate(4, ngaySinh);
                pst.setString(5, dienThoai);
                pst.setString(6, email);
                pst.setString(7, maNV);
                pst.setDate(8, ngayDK);

                int affectedRows = pst.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Thêm người học thành công!");
                    loadTable_NGUOI_HOC(); // Làm mới dữ liệu bảng
                    String currentID = txtID_NH.getText();
                    // Tạo mã mới bằng cách tăng số lên một đơn vị
                    String newID = incrementID(currentID);
                    // Gán mã mới cho trường txtID_CD
                    txtID_NH.setText(newID);
                    txtBrithday_NH.setText("");
                    txtEmail_NH.setText("");
                    txtName_NH.setText("");
                    txtNote_NH.setText("");
                    txtPhone_NH.setText("");
                    rdoMale_NH.setSelected(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm người học thất bại.");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi thêm người học: " + ex.getMessage());
            }

    }    }//GEN-LAST:event_btnAdd_NHActionPerformed

    private boolean deleteCourse_NH(String maNH) {
        String deleteQuery = "DELETE FROM NGUOI_HOC WHERE MA_NH = ?"; // Giả sử MA_NH là mã người học
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(deleteQuery)) {
            pst.setString(1, maNH);

            int affectedRows = pst.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi khi xóa người học: " + ex.getMessage());
            return false;
        }
    }

    private void btnDelete_NHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete_NHActionPerformed
        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblLeaner.getSelectedRow();

        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maNH = tblLeaner.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã người học

            // Hiển thị hỏi người dùng xác nhận việc xóa
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn xóa người học này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện xóa từ cơ sở dữ liệu
                if (deleteCourse_NH(maNH)) {
                    // Xóa thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblLeaner.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Đã xóa người học thành công!");
                } else {
                    // Xóa thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể xóa người học. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn một người học để xóa.");
        }
    }//GEN-LAST:event_btnDelete_NHActionPerformed

    private void btnUpdate_NHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate_NHActionPerformed
        // Kiểm tra xem tất cả các trường nhập liệu có đều không trống và không có lỗi
        if (checkInfor_NH()) {
            try {
                Connection con = DriverManager.getConnection(url);
                String sql = "UPDATE NGUOI_HOC SET TEN_NH = ?, GIOI_TINH = ?, NGAY_SINH = ?, DIEN_THOAI = ?,  EMAIL = ?,GHI_CHU = ? WHERE MA_NH = ?";
                PreparedStatement statementUpdateCD = con.prepareStatement(sql);

                statementUpdateCD.setString(1, txtName_NH.getText());
                String gioiTinh = "";
                if (rdoMale_NH.isSelected()) {
                    gioiTinh = rdoMale_NH.getText();
                } else {
                    gioiTinh = rdoFemale_NH.getText();
                }
                statementUpdateCD.setString(2, gioiTinh);
                statementUpdateCD.setString(3, txtBrithday_NH.getText());

                // Lưu đường dẫn ảnh vào cơ sở dữ liệu
                statementUpdateCD.setString(4, txtPhone_NH.getText());
                statementUpdateCD.setString(5, txtEmail_NH.getText());
                statementUpdateCD.setString(6, txtNote_NH.getText());
                statementUpdateCD.setString(7, txtID_NH.getText());

                // Thực hiện truy vấn SQL cập nhật và kiểm tra kết quả
                int rowsUpdated = statementUpdateCD.executeUpdate();
                if (rowsUpdated > 0) {
                    // Thông báo cập nhật thành công
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin người học thành công.");
                    // Cập nhật lại bảng hiển thị chuyên đề
                    loadTable_NGUOI_HOC();
                } else {
                    // Thông báo cập nhật thất bại nếu không có hàng nào được cập nhật
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin người học thất bại.");
                }
                con.close();
            } catch (SQLException e) {
                // Hiển thị thông báo lỗi nếu có lỗi xảy ra khi thực hiện truy vấn cập nhật
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật người học: " + e.getMessage());
            }
        } else {
            // Hiển thị thông báo lỗi nếu các trường nhập liệu chưa hợp lệ
            JOptionPane.showMessageDialog(this, "Vui lòng điền đúng thông tin vào các trường.");
        }
    }//GEN-LAST:event_btnUpdate_NHActionPerformed

    // Phương thức này thiết lập một listener cho sự kiện lựa chọn hàng trên bảng nhân viên
    private void clickTable_NHAN_VIEN() {
        tblStaff.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Kiểm tra nếu sự lựa chọn không đang được điều chỉnh và một hàng đã được chọn
                if (!e.getValueIsAdjusting() && tblStaff.getSelectedRow() != -1) {
                    // Lấy chỉ mục của hàng được chọn
                    int selectedRow = tblStaff.getSelectedRow();
                    // Điền dữ liệu vào các trường nhập liệu từ hàng được chọn
                    txtIDStaff_NV.setText(tblStaff.getValueAt(selectedRow, 0).toString());
                    txtName_NV.setText(tblStaff.getValueAt(selectedRow, 1).toString());
                    txtPassword_NV.setText(tblStaff.getValueAt(selectedRow, 2).toString());
                    String vaiTro = tblStaff.getValueAt(selectedRow, 3).toString();
                    // Thiết lập radio button dựa trên vai trò
                    if (vaiTro.equals("Trưởng phòng")) {
                        rdoManager_NV.setSelected(true);
                    } else if (vaiTro.equals("Nhân viên")) {
                        rdoStaff_NV.setSelected(true);
                    }
                    // Điền mật khẩu xác nhận giống như mật khẩu
                    txtConfirmPass_NV.setText(txtPassword_NV.getText());
                }
            }
        });
    }

// Phương thức này dùng để tải dữ liệu từ cơ sở dữ liệu vào bảng nhân viên
    private void loadTable_NHAN_VIEN() {
        // Lấy mô hình bảng và xóa các hàng hiện tại
        DefaultTableModel model = (DefaultTableModel) tblStaff.getModel();
        model.setRowCount(0); // Xóa các hàng hiện tại trong mô hình bảng

        String query = "SELECT * FROM NHAN_VIEN";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {
            // Duyệt qua kết quả truy vấn và thêm các hàng mới vào mô hình bảng
            while (rs.next()) {
                String maNV = rs.getString("MA_NV");
                String tenNV = rs.getString("TEN_NV");
                String matKhau = rs.getString("MAT_KHAU");
                String vaiTro = rs.getString("VAI_TRO");
                // Thêm một hàng mới vào mô hình bảng với các giá trị lấy được
                model.addRow(new Object[]{maNV, tenNV, matKhau, vaiTro});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tải dữ liệu: " + ex.getMessage());
        }
    }

    private boolean isValidID_Staff(String id) {
        // Kiểm tra xem mã có đúng định dạng NHxxx hay không
        return id.matches("^NV\\d+$");
    }

    private boolean checkInfor_NV() {
        boolean isValid = true;

        // Kiểm tra mật khẩu xác nhận
        if (txtConfirmPass_NV.getText().equals("")) {
            lblErrorConfirm_NV.setText("Nhập lại mật khẩu không được bỏ trống");
            isValid = false;
        } else if (!txtConfirmPass_NV.getText().equals(txtPassword_NV.getText())) {
            lblErrorConfirm_NV.setText("Bạn đã nhập lại mật khẩu sai. Vui lòng nhập lại");
            isValid = false;
        } else {
            lblErrorConfirm_NV.setText("");
        }

        // Kiểm tra mật khẩu chính
        String password = txtPassword_NV.getText();
        if (password.equals("")) {
            lblErrorPass_NV.setText("Mật khẩu không được bỏ trống");
            isValid = false;
        } else {
            StringBuilder errorMessage = new StringBuilder("Mật khẩu bạn không đủ mạnh! ");
            boolean validPassword = true;

            if (!password.matches(".*[A-Z].*") && !password.matches(".*[a-z].*")
                    && !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*") && !password.matches(".*[0-9].*")) {
                errorMessage.append("Mật khẩu phải có ký tự in hoa, ký tự đặt biệt va ký tự số");
                validPassword = false;
            } else {

                if (!password.matches(".*[A-Z].*")) {
                    errorMessage.append("Bạn hãy thêm ít nhất một chữ in hoa. ");
                    validPassword = false;
                }
                if (!password.matches(".*[a-z].*")) {
                    errorMessage.append("Bạn hãy thêm ít nhất một chữ thường. ");
                    validPassword = false;
                }
                if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
                    errorMessage.append("Bạn hãy thêm ít nhất một ký tự đặc biệt. ");
                    validPassword = false;
                }
                if (!password.matches(".*[0-9].*")) {
                    errorMessage.append("Bạn hãy thêm ít nhất một chữ số. ");
                    validPassword = false;
                }
            }

            if (!validPassword) {
                lblErrorPass_NV.setText(errorMessage.toString());
                isValid = false;
            } else {
                lblErrorPass_NV.setText("");
            }
        }

        // Kiểm tra mã nhân viên
        String idStaff = txtIDStaff_NV.getText().trim();
        if (idStaff.equals("")) {
            lblErrorIDStaff_NV.setText("Mã nhân viên không được bỏ trống. Gợi ý: Bạn có thể nhấp enter để tạo mã ngẫu nhiên");
            isValid = false;
        } else if (!isValidID_Staff(idStaff)) {
            lblErrorIDStaff_NV.setText("Mã nhân viên phải bắt đầu 'NV' kế tiếp là số");
            isValid = false;
        } else {
            lblErrorIDStaff_NV.setText("");
        }

        // Kiểm tra tên nhân viên
        String name = txtName_NV.getText().trim();
        if (name.isEmpty()) {
            lblErrorName_NV.setText("Tên nhân viên không được bỏ trống");
            isValid = false;
        } else if (name.matches(".*\\d.*")) {
            lblErrorName_NV.setText("Tên không được chứa số");
            isValid = false;
        } else {
            lblErrorName_NV.setText("");
        }

        return isValid;
    }
// Giả sử hàm này được định nghĩa ở đâu đó để kiểm tra định dạng mã nhân viên


    private void btnAdd_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd_NVActionPerformed

        if (checkInfor_NV()) {
            String maNV = txtIDStaff_NV.getText().trim();
            String tenNV = txtName_NV.getText().trim();
            String matKhau = txtPassword_NV.getText().trim();
            String vaiTro = rdoManager_NV.isSelected() ? rdoManager_NV.getText() : rdoStaff_NV.getText();

            String insertQuery = "INSERT INTO NHAN_VIEN (MA_NV, TEN_NV, MAT_KHAU, VAI_TRO) VALUES (?, ?, ?, ?)";

            try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(insertQuery)) {
                pst.setString(1, maNV);
                pst.setString(2, tenNV);
                pst.setString(3, matKhau);
                pst.setString(4, vaiTro);

                int affectedRows = pst.executeUpdate();
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(this, "Thêm nhân viên thành công!");
                    loadTable_NHAN_VIEN(); // Làm mới dữ liệu bảng
                    String currentID = txtIDStaff_NV.getText();
                    // Tạo mã mới bằng cách tăng số lên một đơn vị
                    String newID = incrementID(currentID);
                    // Gán mã mới cho trường txtID_CD
                    txtIDStaff_NV.setText(newID);
                    txtConfirmPass_NV.setText("");
                    txtPassword_NV.setText("");
                    txtName_NV.setText("");

                    rdoStaff_NV.setSelected(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm người học thất bại.");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi thêm người học: " + ex.getMessage());
            }
        }
    }//GEN-LAST:event_btnAdd_NVActionPerformed

    private void btnUpdate_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate_NVActionPerformed

        if (checkInfor_NV()) {
            try {
                Connection con = DriverManager.getConnection(url);
                String sql = "UPDATE NHAN_VIEN SET TEN_NV = ?, MAT_KHAU = ?, VAI_TRO = ? WHERE MA_NV = ?";
                PreparedStatement statementUpdateCD = con.prepareStatement(sql);

                statementUpdateCD.setString(1, txtName_NV.getText());

                statementUpdateCD.setString(2, txtPassword_NV.getText());
                String vaiTro = rdoManager_NV.isSelected() ? rdoManager_NV.getText() : rdoStaff_NV.getText();

                statementUpdateCD.setString(3, vaiTro);
                statementUpdateCD.setString(4, txtIDStaff_NV.getText());

                // Thực hiện truy vấn SQL cập nhật và kiểm tra kết quả
                int rowsUpdated = statementUpdateCD.executeUpdate();
                if (rowsUpdated > 0) {
                    // Thông báo cập nhật thành công
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin nhân viên thành công.");
                    // Cập nhật lại bảng hiển thị chuyên đề
                    loadTable_NHAN_VIEN();
                } else {
                    // Thông báo cập nhật thất bại nếu không có hàng nào được cập nhật
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin nhân viên thất bại.");
                }
                con.close();
            } catch (SQLException e) {
                // Hiển thị thông báo lỗi nếu có lỗi xảy ra khi thực hiện truy vấn cập nhật
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật nhân viên: " + e.getMessage());
            }
        } else {
            // Hiển thị thông báo lỗi nếu các trường nhập liệu chưa hợp lệ
            JOptionPane.showMessageDialog(this, "Vui lòng điền đúng thông tin vào các trường.");
        }
    }//GEN-LAST:event_btnUpdate_NVActionPerformed

    private boolean deleteCourse_NV(String maNV) {
        String deleteQuery = "DELETE FROM NHAN_VIEN WHERE MA_NV = ?"; // Giả sử MA_NH là mã người học
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(deleteQuery)) {
            pst.setString(1, maNV);

            int affectedRows = pst.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi khi xóa nhân viên: " + ex.getMessage());
            return false;
        }
    }

    private void btnDelete_NVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete_NVActionPerformed

        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblStaff.getSelectedRow();

        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maNV = tblStaff.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã người học

            // Hiển thị hỏi người dùng xác nhận việc xóa
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn xóa nhân viên này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện xóa từ cơ sở dữ liệu
                if (deleteCourse_NV(maNV)) {
                    // Xóa thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblStaff.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Đã xóa nhân viên thành công!");
                } else {
                    // Xóa thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể xóa nhân viên. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn một nhân viên để xóa.");
        }
    }//GEN-LAST:event_btnDelete_NVActionPerformed

    private void btnUpdate_KHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate_KHActionPerformed
        if (checkInfor_KH()) {
            String maKH = txtID_KH.getText().trim();
            String nguoiTao = txtUser_KH.getText().trim();
            String maNhanVien = getMaNhanVienFromTenNhanVien(nguoiTao);
            String khaiGiang = txtOpening_KH.getText().trim();
            String hocPhi = txtTuition_KH.getText().trim();
            String ngayTao = txtDate_KH.getText().trim();
            String thoiLuong = txtTime_KH.getText().trim();
            String tenCDNgayTao = cboKH.getSelectedItem().toString();
            String maChuyenDe = tenCDNgayTao.split(" - ")[0];

            // Kiểm tra xem mã khóa học có tồn tại trong cơ sở dữ liệu hay không
            String selectQuery = "SELECT COUNT(*) FROM KHOA_HOC WHERE MA_KH = ?";
            String updateQuery = "UPDATE KHOA_HOC SET MA_NV = ?, MA_CD = ?, NGAY_TAO = ?, NGAY_KG = ?, HOC_PHI = ?, THOI_LUONG = ?, GHI_CHU = ? WHERE MA_KH = ?";

            try ( Connection con = DriverManager.getConnection(url);  PreparedStatement selectPst = con.prepareStatement(selectQuery);  PreparedStatement updatePst = con.prepareStatement(updateQuery)) {

                // Kiểm tra xem mã khóa học có tồn tại hay không
                selectPst.setString(1, maKH);
                ResultSet rs = selectPst.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    // Mã khóa học tồn tại, thực hiện cập nhật
                    updatePst.setString(1, maNhanVien);
                    updatePst.setString(2, maChuyenDe);
                    updatePst.setDate(3, java.sql.Date.valueOf(ngayTao));
                    updatePst.setDate(4, java.sql.Date.valueOf(khaiGiang));
                    updatePst.setString(5, hocPhi);
                    updatePst.setString(6, thoiLuong);
                    updatePst.setString(7, ""); // Giả sử GHI_CHU là tùy chọn và có thể để trống
                    updatePst.setString(8, maKH);

                    int affectedRows = updatePst.executeUpdate();
                    if (affectedRows > 0) {
                        JOptionPane.showMessageDialog(this, "Cập nhật khóa học thành công!");
                        loadTable_KH(); // Làm mới dữ liệu bảng
                        loadComboBoxData_KHOA_HOC();

                        String newID = incrementID(maKH);
                        txtID_KH.setText(newID);
                        txtDate_KH.setText("");
                        txtNote_KH.setText("");
                        txtOpening_KH.setText("");
                        txtTime_KH.setText("");
                        txtUser_KH.setText("");
                    } else {
                        JOptionPane.showMessageDialog(this, "Cập nhật khóa học thất bại.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Mã khóa học không tồn tại.");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật khóa học: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng kiểm tra lại các lỗi đã được báo.");
        }
    }//GEN-LAST:event_btnUpdate_KHActionPerformed

    private void loadComboBoxData_nameCD_HV() {
        String query = "SELECT * FROM CHUYEN_DE ";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {

            // Xóa các mục hiện có trong JComboBox
            cboNameCD_HV.removeAllItems();

            // Điền JComboBox với dữ liệu được truy xuất
            while (rs.next()) {
                String maCD = rs.getString("MA_CD");
                String tenCD = rs.getString("TEN_CD");
                String tenCDNgayTao = maCD + " - " + tenCD; // Cần định dạng lại ngày tạo nếu cần
                cboNameCD_HV.addItem(tenCDNgayTao);
            }

            // Đảm bảo một mục được chọn để hiển thị ngay từ đầu
            if (cboNameCD_HV.getItemCount() > 0) {
                cboNameCD_HV.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    private void loadTable_NGUOIHOC_HV() {
        DefaultTableModel model = (DefaultTableModel) tblStudent_HV.getModel();
        model.setRowCount(0); // Clear the existing rows in the table model

        String query = "SELECT * FROM NGUOI_HOC";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                String maNH = rs.getString("MA_NH");
                String tenNH = rs.getString("TEN_NH");
                String gioiTinh = rs.getString("GIOI_TINH");
                String ngaySinh = rs.getString("NGAY_SINH");
                String dienThoai = rs.getString("DIEN_THOAI");
                String email = rs.getString("EMAIL");

                // Add a new row to the table model with the retrieved values
                model.addRow(new Object[]{maNH, tenNH, gioiTinh, ngaySinh, dienThoai, email});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tải dữ liệu: " + ex.getMessage());
        }
    }

// Phương thức này dùng để xóa một học viên khỏi cơ sở dữ liệu dựa trên mã học viên
    private boolean deleteCourse_HV(String maHV) {
        // Câu truy vấn xóa học viên khỏi bảng HOC_VIEN dựa trên mã học viên
        String deleteQuery = "DELETE FROM HOC_VIEN WHERE MA_HV = ?";

        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(deleteQuery)) {
            // Thiết lập giá trị cho tham số câu truy vấn
            pst.setString(1, maHV);

            // Thực hiện câu truy vấn xóa và trả về số hàng bị ảnh hưởng
            int affectedRows = pst.executeUpdate();

            // Kiểm tra nếu có hàng nào bị ảnh hưởng (được xóa) hay không
            return affectedRows > 0;
        } catch (SQLException ex) {
            // Hiển thị thông báo lỗi nếu có lỗi xảy ra trong quá trình xóa học viên
            JOptionPane.showMessageDialog(null, "Lỗi khi xóa học viên: " + ex.getMessage());
            return false;
        }
    }

    private void btnDelete_HVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete_HVActionPerformed

        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblHV.getSelectedRow();

        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maHV = tblHV.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã người học

            // Hiển thị hỏi người dùng xác nhận việc xóa
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn xóa học viên này khỏi khoá học?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện xóa từ cơ sở dữ liệu
                if (deleteCourse_HV(maHV)) {
                    // Xóa thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblHV.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Đã xóa học viên này thành công!");

                } else {
                    // Xóa thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể xóa học viên này. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn học viên để xóa.");
        }
    }//GEN-LAST:event_btnDelete_HVActionPerformed

// Phương thức này dùng để cập nhật điểm của một học viên trong cơ sở dữ liệu dựa trên mã học viên
    private boolean update_HV(String maHV, float diem) {
        // Câu truy vấn cập nhật điểm học viên trong bảng HOC_VIEN dựa trên mã học viên
        String updateQuery = "UPDATE HOC_VIEN SET DIEM = ? WHERE MA_HV = ?";

        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(updateQuery)) {
            // Thiết lập giá trị cho tham số câu truy vấn
            pst.setFloat(1, diem);
            pst.setString(2, maHV);

            // Thực hiện câu truy vấn cập nhật và trả về số hàng bị ảnh hưởng
            int affectedRows = pst.executeUpdate();

            // Kiểm tra nếu có hàng nào bị ảnh hưởng (được cập nhật) hay không
            return affectedRows > 0;
        } catch (SQLException ex) {
            // Hiển thị thông báo lỗi nếu có lỗi xảy ra trong quá trình cập nhật điểm học viên
            JOptionPane.showMessageDialog(null, "Lỗi khi cập nhật điểm học viên: " + ex.getMessage());
            return false;
        }
    }

    private void btnUpdateMark_HVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateMark_HVActionPerformed

        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblHV.getSelectedRow();

        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maHV = tblHV.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã học viên
            float diem = Float.parseFloat(tblHV.getValueAt(selectedRow, 3).toString()); // Giả sử cột thứ tư là điểm

            // Hiển thị hỏi người dùng xác nhận việc cập nhật điểm
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn cập nhật điểm học viên này?", "Xác nhận cập nhật", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện cập nhật trong cơ sở dữ liệu
                if (update_HV(maHV, diem)) {
                    // Cập nhật thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblHV.getModel();
                    JOptionPane.showMessageDialog(null, "Đã cập nhật điểm học viên này thành công!");

                } else {
                    // Cập nhật thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể cập nhật điểm học viên này. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn học viên để cập nhật.");
        }

    }//GEN-LAST:event_btnUpdateMark_HVActionPerformed

    private void loadComboBoxData_HOC_VIEN_KH() {
        String query = "SELECT * FROM KHOA_HOC A INNER JOIN CHUYEN_DE B ON A.MA_CD = B.MA_CD";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {

            // Xóa các mục hiện có trong combo box
            cboNameKH_HV.removeAllItems();

            // Điền combo box với dữ liệu được truy xuất từ cơ sở dữ liệu
            while (rs.next()) {
                String maCD = rs.getString("MA_CD");
                String ngayTao = rs.getString("NGAY_TAO");
                String tenCDNgayTao = maCD + " - " + ngayTao;
                cboNameKH_HV.addItem(tenCDNgayTao);
            }

            // Đảm bảo một mục mặc định được chọn để hiển thị ban đầu
            if (cboNameKH_HV.getItemCount() > 0) {
                cboNameKH_HV.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    private void loadComboBoxData_KHOAHOC_THONGKE() {
        String query = "SELECT * FROM KHOA_HOC A INNER JOIN CHUYEN_DE B ON A.MA_CD = B.MA_CD";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {

            // Xóa các mục hiện có trong combo box
            cboKH_TK.removeAllItems();

            // Điền combo box với dữ liệu được truy xuất từ cơ sở dữ liệu
            while (rs.next()) {
                String maCD = rs.getString("MA_CD");
                String ngayTao = rs.getString("NGAY_TAO");
                String tenCDNgayTao = maCD + " - " + ngayTao;
                cboKH_TK.addItem(tenCDNgayTao);
            }

            // Đảm bảo một mục mặc định được chọn để hiển thị ban đầu
            if (cboKH_TK.getItemCount() > 0) {
                cboKH_TK.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    private void loadComboBoxData_DOANHTHU_THONGKE() {
        String query = "SELECT YEAR(NGAY_KG) AS NAM,E.TEN_CD, COUNT(D.MA_KH) AS SL_KH, COUNT(A.MA_HV) AS SL_HV, MAX(E.HOC_PHI) AS DT_C, MIN(E.HOC_PHI) AS DT_T, AVG(E.HOC_PHI) AS DT_TB FROM HOC_VIEN A INNER JOIN NGUOI_HOC B ON A.MA_NH = B.MA_NH INNER JOIN NHAN_VIEN C ON C.MA_NV = B.MA_NV INNER JOIN KHOA_HOC D ON D.MA_NV = C.MA_NV INNER JOIN CHUYEN_DE E ON E.MA_CD = D.MA_CD GROUP BY TEN_CD, NGAY_KG";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(query);  ResultSet rs = pst.executeQuery()) {

            // Xóa các mục hiện có trong combo box
            cboYear_Revenue.removeAllItems();

            // Điền combo box với dữ liệu được truy xuất từ cơ sở dữ liệu
            while (rs.next()) {
                String nam = rs.getString("NAM");
                cboYear_Revenue.addItem(nam);
            }

            // Đảm bảo một mục mặc định được chọn để hiển thị ban đầu
            if (cboYear_Revenue.getItemCount() > 0) {
                cboYear_Revenue.setSelectedIndex(0);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi khi nạp dữ liệu: " + ex.getMessage());
        }
    }

    private boolean add_NH_ON_HV(String maNH, String maKH) {
        String insertQuery = "INSERT INTO HOC_VIEN (MA_HV, MA_KH, MA_NH, DIEM) VALUES (?, ?, ?, ?)";
        try ( Connection con = DriverManager.getConnection(url);  PreparedStatement pst = con.prepareStatement(insertQuery)) {

            // Tạo mã học viên ngẫu nhiên với 4 chữ số
            Random random = new Random();
            String maHV = "HV" + (1000 + random.nextInt(9000));

            // Tạo mã học viên ngẫu nhiên
            pst.setString(1, maHV);
            pst.setString(2, maKH);
            pst.setString(3, maNH);
            pst.setFloat(4, 0.0f); // Điểm ban đầu là 0

            int affectedRows = pst.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi khi thêm người học: " + ex.getMessage());
            return false;
        }
    }
    private void btnAdd_HVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd_HVActionPerformed
        // Lấy chỉ số hàng đã chọn từ bảng
        int selectedRow = tblStudent_HV.getSelectedRow();

        // Kiểm tra xem có hàng nào được chọn không
        if (selectedRow != -1) {
            // Lấy thông tin từ hàng đã chọn
            String maNH = tblStudent_HV.getValueAt(selectedRow, 0).toString(); // Giả sử cột đầu tiên là mã người học

            // Lấy mã chuyên đề từ JComboBox
            String selectedCD = cboNameCD_HV.getSelectedItem().toString();
            String maCD = selectedCD.split(" - ")[0]; // Giả sử định dạng là "MA_CD - TEN_CD"

            // Hiển thị hộp thoại hỏi người dùng xác nhận việc thêm
            int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc muốn thêm người học này?", "Xác nhận thêm", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Thực hiện thêm vào cơ sở dữ liệu
                if (add_NH_ON_HV(maNH, maCD)) {
                    // Thêm thành công: cập nhật giao diện người dùng
                    DefaultTableModel model = (DefaultTableModel) tblStudent_HV.getModel();
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Đã thêm người học thành công!");
                    loadTable_NGUOIHOC_HV();
                } else {
                    // Thêm thất bại: thông báo lỗi
                    JOptionPane.showMessageDialog(null, "Không thể thêm người học. Vui lòng thử lại.");
                }
            }
        } else {
            // Nếu không có hàng nào được chọn, hiển thị thông báo cho người dùng
            JOptionPane.showMessageDialog(null, "Vui lòng chọn một người học để thêm.");
        }
    }//GEN-LAST:event_btnAdd_HVActionPerformed

    /**
     * Phương thức này được sử dụng để tìm kiếm thông tin người học trong cơ sở
     * dữ liệu dựa trên các tiêu chí sau: - Mã người học bắt đầu bằng "NH" sau
     * đó là một chuỗi số. - Số điện thoại bắt đầu bằng "0" và có đúng 10 chữ
     * số. - Email. - Tên người học (mặc định).
     */
    public void find() {
        // Lấy chuỗi tìm kiếm từ trường văn bản và loại bỏ khoảng trắng đầu và cuối
        String FIND = txtFind_HV.getText().trim();

        // Kết nối đến cơ sở dữ liệu
        try ( Connection con = DriverManager.getConnection(url)) {
            String query = "";
            // Xác định loại tìm kiếm dựa trên chuỗi nhập vào
            if (FIND.startsWith("NH") && FIND.length() > 2 && FIND.substring(2).matches("\\d+")) {
                query = "SELECT * FROM NGUOI_HOC WHERE MA_NH LIKE ?";
                FIND = "%" + FIND + "%";
            } else if (FIND.matches("^0\\d{9}$")) { // Kiểm tra nếu là số điện thoại bắt đầu bằng 0 và có 10 chữ số
                query = "SELECT * FROM NGUOI_HOC WHERE DIEN_THOAI LIKE ?";
                FIND = "%" + FIND + "%";
            } else if (FIND.contains("@")) { // Kiểm tra nếu là email
                query = "SELECT * FROM NGUOI_HOC WHERE EMAIL LIKE ?";
                FIND = "%" + FIND + "%";
            } else { // Mặc định tìm kiếm theo tên
                query = "SELECT * FROM NGUOI_HOC WHERE TEN_NH LIKE ?";
                FIND = "%" + FIND + "%";
            }

            // Thực hiện truy vấn tìm kiếm và cập nhật bảng dữ liệu
            try ( PreparedStatement pst = con.prepareStatement(query)) {
                pst.setString(1, FIND);
                ResultSet rs = pst.executeQuery();

                // Xóa các hàng hiện có trong bảng dữ liệu
                DefaultTableModel model = (DefaultTableModel) tblStudent_HV.getModel();
                model.setRowCount(0);

                // Kiểm tra kết quả của truy vấn
                if (rs.next()) {
                    // Hiển thị dữ liệu tìm thấy trong bảng dữ liệu
                    do {
                        String maNH = rs.getString("MA_NH");
                        String tenNH = rs.getString("TEN_NH");
                        String gioiTinh = rs.getString("GIOI_TINH");
                        String ngaySinh = rs.getString("NGAY_SINH");
                        String dienThoai = rs.getString("DIEN_THOAI");
                        String email = rs.getString("EMAIL");

                        model.addRow(new Object[]{maNH, tenNH, gioiTinh, ngaySinh, dienThoai, email});
                    } while (rs.next());
                } else {
                    // Thông báo khi không tìm thấy dữ liệu
                    model.addRow(new Object[]{"Không tìm thấy dữ liệu"});
                }
            } catch (SQLException ex) {
                // Xử lý lỗi trong quá trình thực hiện truy vấn tìm kiếm
                JOptionPane.showMessageDialog(this, "Lỗi khi tìm kiếm: " + ex.getMessage());
            }
        } catch (SQLException ex) {
            // Xử lý lỗi khi kết nối đến cơ sở dữ liệu
            JOptionPane.showMessageDialog(this, "Lỗi khi kết nối đến cơ sở dữ liệu: " + ex.getMessage());
        }
    }

    private void lblFindHVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblFindHVMouseClicked
        find();
    }//GEN-LAST:event_lblFindHVMouseClicked

    private void lblThematicMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThematicMouseExited
        lblThematic.setBorder(null);
    }//GEN-LAST:event_lblThematicMouseExited

    private void lblThematicMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThematicMouseEntered
        lblThematic.setBorder(border);
    }//GEN-LAST:event_lblThematicMouseEntered

    private void lblThematicMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThematicMouseClicked
        pnlStatic.setVisible(false);
        pnlCourse.setVisible(false);
        pnlThematic.setVisible(true);
        pnlLearner.setVisible(false);
        pnlStudents.setVisible(false);
        pnlStaff.setVisible(false);
        pnlHome.setVisible(false);
    }//GEN-LAST:event_lblThematicMouseClicked

    private void btnReset_CDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReset_CDActionPerformed
        txtID_CD.setText("");
        txtName_CD.setText("");
        txtNote_CD.setText("");
        txtTime_CD.setText("");
        txtTuition_CD.setText("");
        lblErrorID_CD.setText("");
        lblErrorName_CD.setText("");
        lblErrorTime_CD.setText("");
        lblErrorTuition_CD.setText("");
    }//GEN-LAST:event_btnReset_CDActionPerformed

    private void btn_Delete_CDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Delete_CDActionPerformed
        // Lấy mã chuyên đề từ trường nhập liệu
        String ID = txtID_CD.getText();
        // Xác nhận xóa
        int option = JOptionPane.showConfirmDialog(null, "Bạn có chắc chắn muốn xóa chuyên đề này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            try {
                Connection con = DriverManager.getConnection(url);

                // Kiểm tra xem chuyên đề có đang được sử dụng trong bảng KHOA_HOC hoặc HOC_VIEN không
                String checkQuery = "SELECT * FROM KHOA_HOC WHERE MA_CD = ?";
                PreparedStatement checkStatement = con.prepareStatement(checkQuery);
                checkStatement.setString(1, ID);
                ResultSet resultSet = checkStatement.executeQuery();
                if (resultSet.next()) {
                    JOptionPane.showMessageDialog(null, "Không thể xóa chuyên đề đang được sử dụng trong khóa học.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                } else {
                    String sql = "DELETE FROM CHUYEN_DE WHERE MA_CD = ?";
                    PreparedStatement statement = con.prepareStatement(sql);
                    statement.setString(1, ID);

                    int rowsDeleted = statement.executeUpdate();
                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(null, "Xóa chuyên đề thành công.");
                        loadTable_CD();
                        loadComboBoxData_nameCD_HV();
                        loadComboBoxData_HOC_VIEN_KH();
                        loadComboBoxData_KHOA_HOC();
                    } else {
                        JOptionPane.showMessageDialog(null, "Không có chuyên đề nào được xóa.");
                    }
                }
                con.close();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Lỗi khi xóa thông tin chuyên đề: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_btn_Delete_CDActionPerformed

    private void btnUpdate_CDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdate_CDActionPerformed
        // Kiểm tra xem tất cả các trường nhập liệu có đều không trống và không có lỗi

        if (checkInfor_CD()) {
            try {
                Connection con = DriverManager.getConnection(url);
                String sql = "UPDATE CHUYEN_DE SET TEN_CD = ?, THOI_LUONG = ?, HOC_PHI = ?, HINH = ?, MO_TA = ? WHERE MA_CD = ?";
                PreparedStatement statementUpdateCD = con.prepareStatement(sql);

                statementUpdateCD.setString(1, txtName_CD.getText());
                statementUpdateCD.setString(2, txtTime_CD.getText());
                statementUpdateCD.setString(3, txtTuition_CD.getText());

                // Lưu đường dẫn ảnh vào cơ sở dữ liệu
                String imagePath = lblImg_CD.getIcon() != null ? lblImg_CD.getIcon().toString() : "Không có ảnh";
                statementUpdateCD.setString(4, imagePath);

                statementUpdateCD.setString(5, txtNote_CD.getText());
                statementUpdateCD.setString(6, txtID_CD.getText());

                // Thực hiện truy vấn SQL cập nhật và kiểm tra kết quả
                int rowsUpdated = statementUpdateCD.executeUpdate();
                if (rowsUpdated > 0) {
                    // Thông báo cập nhật thành công
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin chuyên đề thành công.");
                    // Cập nhật lại bảng hiển thị chuyên đề
                    loadTable_CD();
                } else {
                    // Thông báo cập nhật thất bại nếu không có hàng nào được cập nhật
                    JOptionPane.showMessageDialog(this, "Cập nhật thông tin chuyên đề thất bại.");
                }
                con.close();
            } catch (SQLException e) {
                // Hiển thị thông báo lỗi nếu có lỗi xảy ra khi thực hiện truy vấn cập nhật
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật chuyên đề: " + e.getMessage());
            }
        } else {
            // Hiển thị thông báo lỗi nếu các trường nhập liệu chưa hợp lệ
            JOptionPane.showMessageDialog(this, "Vui lòng điền đúng thông tin vào các trường.");
        }
    }//GEN-LAST:event_btnUpdate_CDActionPerformed

    private void btnAdd_CDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdd_CDActionPerformed
        // Kiểm tra xem tất cả các trường nhập liệu có đều không trống
        if (checkInfor_CD()) {
            try {
                Connection con = DriverManager.getConnection(url);
                String sql = "INSERT INTO CHUYEN_DE (MA_CD, TEN_CD, THOI_LUONG, HOC_PHI, HINH, MO_TA) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement statementInsertCD = con.prepareStatement(sql);
                statementInsertCD.setString(1, txtID_CD.getText());
                statementInsertCD.setString(2, txtName_CD.getText());
                statementInsertCD.setString(3, txtTime_CD.getText());
                statementInsertCD.setString(4, txtTuition_CD.getText());
                // Lưu đường dẫn ảnh vào cơ sở dữ liệu
                String imagePath = lblImg_CD.getIcon() != null ? lblImg_CD.getIcon().toString() : "Không có ảnh";
                statementInsertCD.setString(5, imagePath);

                statementInsertCD.setString(6, txtNote_CD.getText());

                // Thực thi truy vấn SQL thêm chuyên đề và kiểm tra kết quả
                int rowsInserted = statementInsertCD.executeUpdate();
                if (rowsInserted > 0) {
                    // Thông báo thêm chuyên đề thành công
                    JOptionPane.showMessageDialog(this, "Thêm thông tin chuyên đề thành công.");
                    // Cập nhật bảng hiển thị chuyên đề
                    loadTable_CD();
                    // Lấy mã hiện tại từ trường txtID_CD
                    String currentID = txtID_CD.getText();
                    // Tạo mã mới bằng cách tăng số lên một đơn vị
                    String newID = incrementID(currentID);
                    // Gán mã mới cho trường txtID_CD
                    txtID_CD.setText(newID);
                    txtName_CD.setText("");
                    txtTime_CD.setText("");
                    txtTuition_CD.setText("");
                    txtNote_CD.setText("");
                    // Đặt lblImg_CD về null để xóa hình ảnh hiện tại
                    lblImg_CD.setIcon(null);
                } else {
                    // Thông báo thêm chuyên đề thất bại
                    JOptionPane.showMessageDialog(this, "Thêm thông tin chuyên đề thất bại.");
                }
                // Đóng kết nối đến cơ sở dữ liệu
                con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi khi thêm chuyên đề: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnAdd_CDActionPerformed

    private void lblImg_CDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblImg_CDMouseClicked
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
        // Allow only image files
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File file) {
                return file.getName().toLowerCase().endsWith(".jpg")
                        || file.getName().toLowerCase().endsWith(".jpeg")
                        || file.getName().toLowerCase().endsWith(".png")
                        || file.isDirectory();
            }

            public String getDescription() {
                return "Image files (*.jpg, *.jpeg, *.png)";
            }
        });
        // Show the file chooser dialog
        int result = fileChooser.showOpenDialog(AdminForm.this);

        // If a file was chosen, load it into the label
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try {
                BufferedImage img = ImageIO.read(selectedFile);
                // Get the dimensions of the label
                int labelWidth = lblImg_CD.getWidth();
                int labelHeight = lblImg_CD.getHeight();
                // Calculate the new dimensions while maintaining the aspect ratio
                int newWidth = img.getWidth();
                int newHeight = img.getHeight();
                if (newWidth > labelWidth) {
                    newHeight = (newHeight * labelWidth) / newWidth;
                    newWidth = labelWidth;
                }
                if (newHeight > labelHeight) {
                    newWidth = (newWidth * labelHeight) / newHeight;
                    newHeight = labelHeight;
                }
                // Scale the image to the new dimensions
                Image scaledImg = img.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
                // Set the scaled image as the icon for the label
                lblImg_CD.setIcon(new ImageIcon(scaledImg));
            } catch (IOException e) {
                e.printStackTrace();
                // Handle the error here
            }
        }
    }//GEN-LAST:event_lblImg_CDMouseClicked

    private void lblTurnOffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTurnOffMouseClicked
        turnOff();
    }//GEN-LAST:event_lblTurnOffMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd_CD;
    private javax.swing.JButton btnAdd_HV;
    private javax.swing.JButton btnAdd_KH;
    private javax.swing.JButton btnAdd_NH;
    private javax.swing.JButton btnAdd_NV;
    private javax.swing.JButton btnDelete_HV;
    private javax.swing.JButton btnDelete_KH;
    private javax.swing.JButton btnDelete_NH;
    private javax.swing.JButton btnDelete_NV;
    private javax.swing.ButtonGroup btnG_RENDER;
    private javax.swing.ButtonGroup btnG_VT;
    private javax.swing.JButton btnReset_CD;
    private javax.swing.JButton btnReset_KH;
    private javax.swing.JButton btnReset_NH;
    private javax.swing.JButton btnReset_NV;
    private javax.swing.JButton btnUpdateMark_HV;
    private javax.swing.JButton btnUpdate_CD;
    private javax.swing.JButton btnUpdate_KH;
    private javax.swing.JButton btnUpdate_NH;
    private javax.swing.JButton btnUpdate_NV;
    private javax.swing.JButton btn_Delete_CD;
    private javax.swing.JComboBox<String> cboKH;
    private javax.swing.JComboBox<String> cboKH_TK;
    private javax.swing.JComboBox<String> cboNameCD_HV;
    private javax.swing.JComboBox<String> cboNameKH_HV;
    private javax.swing.JComboBox<String> cboYear_Revenue;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel lblCouse;
    private javax.swing.JLabel lblErrorBrithday_NH;
    private javax.swing.JLabel lblErrorConfirm_NV;
    private javax.swing.JLabel lblErrorDate_KH;
    private javax.swing.JLabel lblErrorEmail_NH;
    private javax.swing.JLabel lblErrorIDStaff_NV;
    private javax.swing.JLabel lblErrorID_CD;
    private javax.swing.JLabel lblErrorID_KH;
    private javax.swing.JLabel lblErrorLeaner_NH;
    private javax.swing.JLabel lblErrorName_CD;
    private javax.swing.JLabel lblErrorName_NH;
    private javax.swing.JLabel lblErrorName_NV;
    private javax.swing.JLabel lblErrorOpening_KH;
    private javax.swing.JLabel lblErrorPass_NV;
    private javax.swing.JLabel lblErrorPhone_NH;
    private javax.swing.JLabel lblErrorTime_CD;
    private javax.swing.JLabel lblErrorTime_KH;
    private javax.swing.JLabel lblErrorTuiltion_KH;
    private javax.swing.JLabel lblErrorTuition_CD;
    private javax.swing.JLabel lblErrorUser_KH;
    private javax.swing.JLabel lblExit;
    private javax.swing.JLabel lblFindHV;
    private javax.swing.JLabel lblHome;
    private javax.swing.JLabel lblImg_CD;
    private javax.swing.JLabel lblLeaner;
    private javax.swing.JLabel lblMenu;
    private javax.swing.JLabel lblStaff;
    private javax.swing.JLabel lblStatistical;
    private javax.swing.JLabel lblStudent;
    private javax.swing.JLabel lblThematic;
    private javax.swing.JLabel lblTurnOff;
    private javax.swing.JLabel lblTurnOff1;
    private javax.swing.JLabel lblTurnOff2;
    private javax.swing.JLabel lblTurnOff3;
    private javax.swing.JLabel lblTurnOff4;
    private javax.swing.JLabel lblTurnOff5;
    private javax.swing.JLabel lblTurnOff6;
    private javax.swing.JPanel pnlCourse;
    private javax.swing.JPanel pnlDisplay;
    private javax.swing.JPanel pnlEdition;
    private javax.swing.JPanel pnlHome;
    private javax.swing.JPanel pnlIMG;
    private javax.swing.JPanel pnlLearner;
    private javax.swing.JPanel pnlMiniMenu;
    private javax.swing.JPanel pnlStaff;
    private javax.swing.JPanel pnlStatic;
    private javax.swing.JPanel pnlStudents;
    private javax.swing.JPanel pnlThematic;
    private me.pc07981.quan_ly.QUAN_LY qUAN_LY_NHA_TRO1;
    private javax.swing.JRadioButton rdoFemale_NH;
    private javax.swing.JRadioButton rdoMale_NH;
    private javax.swing.JRadioButton rdoManager_NV;
    private javax.swing.JRadioButton rdoStaff_NV;
    private javax.swing.JTable tblCD_TK;
    private javax.swing.JTable tblHV;
    private javax.swing.JTable tblKH;
    private javax.swing.JTable tblLeaner;
    private javax.swing.JTable tblMark_TK;
    private javax.swing.JTable tblRevenue_TK;
    private javax.swing.JTable tblStaff;
    private javax.swing.JTable tblStudent_HV;
    private javax.swing.JTable tblStudent_TK;
    private javax.swing.JTable tbl_CD;
    private javax.swing.JTextField txtBrithday_NH;
    private javax.swing.JTextField txtConfirmPass_NV;
    private javax.swing.JTextField txtDate_KH;
    private javax.swing.JTextField txtEmail_NH;
    private javax.swing.JTextField txtFind_HV;
    private javax.swing.JTextField txtIDStaff_NV;
    private javax.swing.JTextField txtID_CD;
    private javax.swing.JTextField txtID_KH;
    private javax.swing.JTextField txtID_NH;
    private javax.swing.JTextField txtID_NV;
    private javax.swing.JTextField txtName_CD;
    private javax.swing.JTextField txtName_NH;
    private javax.swing.JTextField txtName_NV;
    private javax.swing.JTextArea txtNote_CD;
    private javax.swing.JTextArea txtNote_KH;
    private javax.swing.JTextArea txtNote_NH;
    private javax.swing.JTextField txtOpening_KH;
    private javax.swing.JTextField txtPassword_NV;
    private javax.swing.JTextField txtPhone_NH;
    private javax.swing.JTextField txtTime_CD;
    private javax.swing.JTextField txtTime_KH;
    private javax.swing.JTextField txtTuition_CD;
    private javax.swing.JTextField txtTuition_KH;
    private javax.swing.JTextField txtUser_KH;
    // End of variables declaration//GEN-END:variables
}
