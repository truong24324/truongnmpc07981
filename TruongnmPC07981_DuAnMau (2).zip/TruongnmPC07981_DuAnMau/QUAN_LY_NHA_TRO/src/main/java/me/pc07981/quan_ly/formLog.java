package me.pc07981.quan_ly;

import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.Timer;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * Ngày 23/04 1 tiếng Ngày 24/04 2 tiếng Ngày 25/04 5 tiếng còn bug + 1 tiếng đã
 * fix bug + 6 tiếng
 *
 */
public class formLog extends javax.swing.JFrame {

    String url = "jdbc:sqlserver://localhost:1433;database=QUAN_LY_HOC_VIEN;integratedSecurity=false;user=sa;password=123;encrypt=true;trustServerCertificate=true;";
    String logIn1 = "Nếu bạn đã có tài khoản";
    String logIn2 = "Thì đừng ngần ngại đăng nhập ngay bây giờ";
    String logUp1 = "Chuyện nhỏ bạn à";
    String logUp2 = "Hãy đă cùng mình thay đổi mật khẩu bạn nhé ^_^";

    private double width;
    private double height;
    private double width1;
    private boolean panelOnLeft = true;

    public formLog() {
        initComponents();
        setLocationRelativeTo(null);
        pnlLayout.setVisible(true);
        width = pnlLayout.getWidth();
        height = pnlLayout.getHeight();
        width1 = (double) width / 2;
        pnlLayout.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                jPanel1ComponentResized(evt);
            }
        });
        //jPasswordField1.setBackground(new java.awt.Color(0,0,0,0));
        Open();
        txtUserName.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInforLogIn();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInforLogIn();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInforLogIn();
            }
        });

        txtPassword.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkInforLogIn();
            }

            public void removeUpdate(DocumentEvent e) {
                checkInforLogIn();
            }

            public void insertUpdate(DocumentEvent e) {
                checkInforLogIn();
            }
        });
        txtConfirmPS.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void removeUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void insertUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }
        });
        txtPS_Old.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void removeUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void insertUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }
        });
        txtPS_new.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void removeUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void insertUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }
        });
        txtUser_PS.getDocument().addDocumentListener(new DocumentListener() {
            public void changedUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void removeUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }

            public void insertUpdate(DocumentEvent e) {
                checkUpdatePassword();
            }
        });
        txtPassword.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                txtPassword.setEchoChar((char) 0); // Show the password
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                txtPassword.setEchoChar('*'); // Hide the password
            }
        });
        txtPS_Old.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                txtPS_Old.setEchoChar((char) 0); // Show the password
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                txtPS_Old.setEchoChar('*'); // Hide the password
            }
        });
        txtPS_new.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                txtPS_new.setEchoChar((char) 0); // Show the password
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                txtPS_new.setEchoChar('*'); // Hide the password
            }
        });
        txtConfirmPS.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                txtConfirmPS.setEchoChar((char) 0); // Show the password
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                txtConfirmPS.setEchoChar('*'); // Hide the password
            }
        });
    }

    private void openAdminForm(String employeeID) {
        AdminForm adminForm = new AdminForm();
        adminForm.setEmployeeID(employeeID);
        adminForm.setVisible(true);
    }

    private void openStaffForm(String employeeID) {
        StaffForm staffForm = new StaffForm();
        staffForm.setEmployeeID(employeeID);
        staffForm.setVisible(true);
    }

    private boolean checkInforLogIn() {
        boolean isValid = true; // Biến cờ để kiểm tra hợp lệ

        // Kiểm tra tên đăng nhập
        if (txtUserName.getText().trim().equals("")) {
            lblerrorUserName.setText("Tên đăng nhập không được bỏ trống");
            isValid = false;
        } else if (!isUsernameExist(txtUserName.getText().trim())) {
            lblerrorUserName.setText("Tên đăng nhập không tồn tại. Lưu ý: tên đăng nhập là mã nhân viên của bạn");
            isValid = false;
        } else {
            lblerrorUserName.setText(""); // Xóa thông báo lỗi nếu hợp lệ
        }

        // Kiểm tra mật khẩu
        String password = txtPassword.getText();
        if (password.trim().equals("")) {
            lblErrorPassword.setText("Mật khẩu không được bỏ trống");
            isValid = false;
        } else {

            lblErrorPassword.setText(""); // Xóa thông báo lỗi nếu hợp lệ
        }

        // Kiểm tra tên đăng nhập trong cơ sở dữ liệu
        return true;
    }

    private boolean isUsernameExist(String username) {
        boolean exists = false;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            try ( Connection con = DriverManager.getConnection(url)) {
                String sql = "SELECT COUNT(*) FROM NHAN_VIEN WHERE MA_NV = ?";
                try ( PreparedStatement statement = con.prepareStatement(sql)) {
                    statement.setString(1, username);
                    try ( ResultSet rs = statement.executeQuery()) {
                        if (rs.next()) {
                            int count = rs.getInt(1);
                            exists = (count > 0);
                        }
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi thực hiện truy vấn: " + e.getMessage());
        }

        return exists;
    }

    private void checkAccount() {
        String username = txtUserName.getText();
        String password = txtPassword.getText();

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            try ( Connection con = DriverManager.getConnection(url)) {
                String sql = "SELECT * FROM NHAN_VIEN WHERE MA_NV = ? AND MAT_KHAU = ?";
                try ( PreparedStatement statement = con.prepareStatement(sql)) {
                    statement.setString(1, username);
                    statement.setString(2, password);
                    try ( ResultSet rs = statement.executeQuery()) {
                        if (rs.next()) {
                            String vaiTro = rs.getString("VAI_TRO");
                            String maNV = rs.getString("MA_NV"); // Lấy mã nhân viên
                            if ("Trưởng phòng".equals(vaiTro)) {
                                JOptionPane.showMessageDialog(this, "Đăng nhập với tư cách trưởng phòng thành công");
                                openAdminForm(maNV); // Truyền mã nhân viên
                            } else if ("Nhân viên".equals(vaiTro)) {
                                // Xử lý vai trò nhân viên nếu cần
                                JOptionPane.showMessageDialog(this, "Đăng nhập với tư cách nhân viên thành công");
                                openStaffForm(maNV); // Truyền mã nhân viên
                            } else {
                                JOptionPane.showMessageDialog(this, "Tài khoản không có quyền truy cập hoặc không tồn tại. Vui lòng kiểm tra lại.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(this, "Tài khoản không tồn tại hoặc sai mật khẩu. Vui lòng kiểm tra lại.");
                        }
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi thực hiện truy vấn: " + e.getMessage());
        }
    }

    private void jPanel1ComponentResized(java.awt.event.ComponentEvent evt) {
        // Lấy lại kích thước mới của jPanel1 khi nó được thay đổi
        width = pnlLayout.getWidth();
        height = pnlLayout.getHeight();
        // Cập nhật lại kích thước của pnlLog
        width1 = (double) width / 2;
        pnlRight.setSize((int) width1, (int) height);
        pnlLeft.setSize((int) width1, (int) height);

    }

    private void Open() {
        // Vô hiệu hoá nút btnLogUp
        btnNextPage.setEnabled(false);

        // Đặt kích thước của các panel `pnlLog` và `pnlForm` thành kích thước mới
        pnlLeft.setSize((int) width1, (int) height);
        pnlRight.setSize((int) width1, (int) height);

        // Lấy vị trí hiện tại của các panel
        Point logLocation = pnlLeft.getLocation();
        int logX = logLocation.x;
        int logY = logLocation.y;

        Point formLocation = pnlRight.getLocation();
        int formX = formLocation.x;
        int formY = formLocation.y;

        // Tính toán vị trí mới cho các panel dựa trên trạng thái hiện tại
        int logNewX, formNewX;
        if (panelOnLeft) {
            logNewX = logX - pnlLeft.getWidth();
            formNewX = formX + pnlRight.getWidth();
        } else {
            logNewX = logX + pnlLeft.getWidth();
            formNewX = formX - pnlRight.getWidth();
        }

        // Giữ vị trí Y không thay đổi
        int logNewY = logY;
        int formNewY = formY;

        // Tạo ExecutorService để thực hiện animation trên các luồng riêng biệt
        ExecutorService executorLog = Executors.newSingleThreadExecutor();
        ExecutorService executorForm = Executors.newSingleThreadExecutor();

        // Submit nhiệm vụ animation cho mỗi panel
        executorLog.submit(() -> animatePanel(logX, logY, logNewX, logNewY, pnlLeft));
        executorForm.submit(() -> animatePanel(formX, formY, formNewX, formNewY, pnlRight));

        // Đảo ngược trạng thái của biến `panelOnLeft` để chuẩn bị cho lần bấm tiếp theo
        panelOnLeft = !panelOnLeft;

        // Kiểm tra xem đã phóng to full màn hình chưa
        if (!isMaximized) {
            // Nếu chưa, đặt biến cờ là true và bắt đầu một Timer để đợi 2 giây trước khi phóng to
            isMaximized = true;
            Timer timer1 = new Timer(300, (e) -> {
                pnlWelllcome.setVisible(true);
                // Lấy kích thước font ban đầu của JLabel
                Font originalFont = lblWellcome.getFont();
                int originalSize = originalFont.getSize();

                // Thiết lập một giá trị tăng kích thước font mỗi lần Timer được kích hoạt
                int increaseSize = 1;

                // Tạo một Timer mới để thực hiện việc thay đổi kích thước font
                Timer fontTimer = new Timer(50, (event) -> {
                    // Tăng kích thước font lên
                    int newSize = lblWellcome.getFont().getSize() + increaseSize;

                    // Nếu kích thước font mới vượt quá giới hạn, dừng Timer
                    if (newSize > 50) { // Thay 24 bằng kích thước tối đa bạn muốn
                        ((Timer) event.getSource()).stop();
                        return;
                    }

                    // Tạo một font mới với kích thước tăng lên
                    Font newFont = originalFont.deriveFont((float) newSize);
                    // Đặt font mới cho JLabel
                    lblWellcome.setFont(newFont);
                });
                fontTimer.setRepeats(true);
                fontTimer.start();
            });
            timer1.setRepeats(false);
            timer1.start();

            Timer timer2 = new Timer(3000, (e) -> {
                maximizePanels();
                pnlLayout.setVisible(true);
                SwingWorker<Void, Void> worker1 = new SwingWorker<Void, Void>() {
                    @Override
                    protected Void doInBackground() throws Exception {
                        typewriterEffect(logUp1);
                        return null;
                    }
                };
                worker1.execute();

                SwingWorker<Void, Void> worker2 = new SwingWorker<Void, Void>() {
                    @Override
                    protected Void doInBackground() throws Exception {
                        typewriterEffect2(logUp2);
                        return null;
                    }

                    @Override
                    protected void done() {
                        // Kích hoạt lại nút btnLogUp sau khi hoàn thành hiệu ứng gõ máy
                        btnNextPage.setEnabled(true);
                    }
                };
                worker2.execute();
            });
            timer2.setRepeats(false);
            timer2.start();
        }
    }

    public void typewriterEffect(String text) {
        lblContent1.setText("");
        try {
            for (int i = 0; i < text.length(); i++) {
                char ch = text.charAt(i);
                SwingUtilities.invokeLater(() -> {
                    lblContent1.setText(lblContent1.getText() + ch); // Thêm từng chữ cái vào JLabel
                });
                Thread.sleep(100); // Độ trễ giữa các chữ cái (milliseconds)
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void typewriterEffect2(String text) {
        lblContent2.setText("");
        try {
            for (int i = 0; i < text.length(); i++) {
                char ch = text.charAt(i);
                SwingUtilities.invokeLater(() -> {
                    lblContent2.setText(lblContent2.getText() + ch);
                });
                Thread.sleep(100); // Độ trễ giữa các chữ cái (milliseconds)
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        pnlLayout = new javax.swing.JPanel();
        pnlLeft = new javax.swing.JPanel();
        pnlOpenLeft = new javax.swing.JPanel();
        lblOpenLeft = new javax.swing.JLabel();
        pnlLogUp = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblTopForm = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lblContent1 = new javax.swing.JLabel();
        lblContent2 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        btnNextPage = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        pnlRight = new javax.swing.JPanel();
        pnlOpenRight = new javax.swing.JPanel();
        lblopenRight = new javax.swing.JLabel();
        pnlLogin_Form = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel26 = new javax.swing.JPanel();
        txtUserName = new javax.swing.JTextField();
        lblerrorUserName = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        txtPassword = new javax.swing.JPasswordField();
        lblErrorPassword = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        btnLogIn = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        pnlLogUp_Form = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jPanel38 = new javax.swing.JPanel();
        jPanel39 = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        txtUser_PS = new javax.swing.JTextField();
        lblErrorUser_PS = new javax.swing.JLabel();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLayeredPane2 = new javax.swing.JLayeredPane();
        txtPS_Old = new javax.swing.JPasswordField();
        lblErrorPS_Old = new javax.swing.JLabel();
        jPanel47 = new javax.swing.JPanel();
        jPanel51 = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jPanel55 = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        txtPS_new = new javax.swing.JPasswordField();
        lblErrorPS_New = new javax.swing.JLabel();
        jPanel50 = new javax.swing.JPanel();
        jPanel59 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jPanel61 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel63 = new javax.swing.JPanel();
        jPanel64 = new javax.swing.JPanel();
        txtConfirmPS = new javax.swing.JPasswordField();
        jPanel65 = new javax.swing.JPanel();
        lblErrorConfirmPS = new javax.swing.JLabel();
        jPanel52 = new javax.swing.JPanel();
        jPanel49 = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jPanel66 = new javax.swing.JPanel();
        btnUpdatePS = new javax.swing.JButton();
        jPanel53 = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        pnlWelllcome = new javax.swing.JPanel();
        lblWellcome = new javax.swing.JLabel();

        jLabel8.setText("jLabel8");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new java.awt.CardLayout());

        pnlLayout.setBackground(new java.awt.Color(255, 255, 255));
        pnlLayout.setToolTipText("");
        pnlLayout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlLayoutMouseClicked(evt);
            }
        });
        pnlLayout.setLayout(new java.awt.GridLayout(1, 0));

        pnlLeft.setBackground(new java.awt.Color(102, 255, 255));
        pnlLeft.setLayout(new java.awt.CardLayout());

        pnlOpenLeft.setBackground(new java.awt.Color(0, 0, 102));

        lblOpenLeft.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        lblOpenLeft.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/door-handle-left.png"))); // NOI18N
        lblOpenLeft.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblOpenLeftMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlOpenLeftLayout = new javax.swing.GroupLayout(pnlOpenLeft);
        pnlOpenLeft.setLayout(pnlOpenLeftLayout);
        pnlOpenLeftLayout.setHorizontalGroup(
            pnlOpenLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
            .addGroup(pnlOpenLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlOpenLeftLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblOpenLeft, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        pnlOpenLeftLayout.setVerticalGroup(
            pnlOpenLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 695, Short.MAX_VALUE)
            .addGroup(pnlOpenLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnlOpenLeftLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(lblOpenLeft, javax.swing.GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        pnlLeft.add(pnlOpenLeft, "card2");

        pnlLogUp.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlLogUpMouseClicked(evt);
            }
        });
        pnlLogUp.setLayout(new java.awt.GridLayout(5, 0));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 139, Short.MAX_VALUE)
        );

        pnlLogUp.add(jPanel1);

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));
        jPanel2.setLayout(new java.awt.CardLayout());

        lblTopForm.setBackground(new java.awt.Color(0, 0, 255));
        lblTopForm.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        lblTopForm.setForeground(new java.awt.Color(255, 255, 255));
        lblTopForm.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTopForm.setText("BẠN MUỐN ĐỔI MẬT KHẨU?");
        jPanel2.add(lblTopForm, "card2");

        pnlLogUp.add(jPanel2);

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));
        jPanel3.setLayout(new java.awt.GridLayout(2, 0));

        lblContent1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblContent1.setForeground(new java.awt.Color(255, 255, 255));
        lblContent1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(lblContent1);

        lblContent2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        lblContent2.setForeground(new java.awt.Color(255, 255, 255));
        lblContent2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel3.add(lblContent2);

        pnlLogUp.add(jPanel3);

        jPanel4.setLayout(new java.awt.BorderLayout());

        jPanel7.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 39, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel7, java.awt.BorderLayout.LINE_END);

        jPanel8.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 39, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel8, java.awt.BorderLayout.LINE_START);

        jPanel9.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 466, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel4.add(jPanel9, java.awt.BorderLayout.PAGE_START);

        btnNextPage.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnNextPage.setForeground(new java.awt.Color(0, 0, 153));
        btnNextPage.setText("ĐỔI MẬT KHẨU NGAY");
        btnNextPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextPageActionPerformed(evt);
            }
        });
        jPanel4.add(btnNextPage, java.awt.BorderLayout.CENTER);

        pnlLogUp.add(jPanel4);

        jPanel6.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 139, Short.MAX_VALUE)
        );

        pnlLogUp.add(jPanel6);

        pnlLeft.add(pnlLogUp, "card3");

        pnlLayout.add(pnlLeft);

        pnlRight.setBackground(new java.awt.Color(153, 153, 153));
        pnlRight.setLayout(new java.awt.CardLayout());

        pnlOpenRight.setBackground(new java.awt.Color(0, 0, 153));

        lblopenRight.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/door-handle.png"))); // NOI18N
        lblopenRight.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblopenRightMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlOpenRightLayout = new javax.swing.GroupLayout(pnlOpenRight);
        pnlOpenRight.setLayout(pnlOpenRightLayout);
        pnlOpenRightLayout.setHorizontalGroup(
            pnlOpenRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOpenRightLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblopenRight, javax.swing.GroupLayout.DEFAULT_SIZE, 378, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnlOpenRightLayout.setVerticalGroup(
            pnlOpenRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlOpenRightLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblopenRight, javax.swing.GroupLayout.DEFAULT_SIZE, 683, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlRight.add(pnlOpenRight, "card2");

        pnlLogin_Form.setForeground(new java.awt.Color(153, 0, 0));
        pnlLogin_Form.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlLogin_FormMouseClicked(evt);
            }
        });
        pnlLogin_Form.setLayout(new java.awt.GridLayout(10, 0));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 538, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        pnlLogin_Form.add(jPanel5);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 538, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        pnlLogin_Form.add(jPanel10);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 538, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        pnlLogin_Form.add(jPanel11);

        jPanel12.setLayout(new java.awt.CardLayout());

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 153));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("ĐĂNG NHẬP");
        jPanel12.add(jLabel3, "card2");

        pnlLogin_Form.add(jPanel12);

        jPanel13.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel21, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
        jPanel23.setLayout(jPanel23Layout);
        jPanel23Layout.setHorizontalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel23Layout.setVerticalGroup(
            jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel23, java.awt.BorderLayout.LINE_END);

        jPanel24.setLayout(new java.awt.BorderLayout());

        jPanel22.setLayout(new java.awt.BorderLayout());

        jPanel25.setLayout(new java.awt.GridLayout(2, 0));

        jLabel4.setText("Tên đăng nhập:");
        jPanel25.add(jLabel4);

        jPanel22.add(jPanel25, java.awt.BorderLayout.LINE_START);

        jPanel26.setLayout(new java.awt.GridLayout(2, 0));
        jPanel26.add(txtUserName);

        lblerrorUserName.setForeground(new java.awt.Color(204, 0, 0));
        lblerrorUserName.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel26.add(lblerrorUserName);

        jPanel22.add(jPanel26, java.awt.BorderLayout.CENTER);

        jPanel24.add(jPanel22, java.awt.BorderLayout.CENTER);

        jPanel13.add(jPanel24, java.awt.BorderLayout.CENTER);

        pnlLogin_Form.add(jPanel13);

        jPanel14.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel27, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel14.add(jPanel28, java.awt.BorderLayout.LINE_END);

        jPanel29.setLayout(new java.awt.BorderLayout());

        jPanel30.setLayout(new java.awt.GridLayout(2, 0));

        jLabel2.setText("         Mật khẩu:");
        jPanel30.add(jLabel2);

        jPanel29.add(jPanel30, java.awt.BorderLayout.LINE_START);

        jLayeredPane1.setLayout(new java.awt.GridLayout(2, 0));
        jLayeredPane1.add(txtPassword);

        lblErrorPassword.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorPassword.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLayeredPane1.add(lblErrorPassword);

        jPanel29.add(jLayeredPane1, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel29, java.awt.BorderLayout.CENTER);

        pnlLogin_Form.add(jPanel14);

        jPanel16.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel16.add(jPanel19, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        jPanel16.add(jPanel20, java.awt.BorderLayout.LINE_END);

        btnLogIn.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnLogIn.setForeground(new java.awt.Color(0, 0, 153));
        btnLogIn.setText("Đăng nhập");
        btnLogIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogInActionPerformed(evt);
            }
        });
        jPanel16.add(btnLogIn, java.awt.BorderLayout.CENTER);

        pnlLogin_Form.add(jPanel16);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 355, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 44, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pnlLogin_Form.add(jPanel17);

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 538, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 69, Short.MAX_VALUE)
        );

        pnlLogin_Form.add(jPanel18);

        pnlRight.add(pnlLogin_Form, "card3");

        pnlLogUp_Form.setForeground(new java.awt.Color(204, 0, 0));
        pnlLogUp_Form.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlLogUp_FormMouseClicked(evt);
            }
        });
        pnlLogUp_Form.setLayout(new java.awt.GridLayout(12, 0));

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        pnlLogUp_Form.add(jPanel31);

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        pnlLogUp_Form.add(jPanel32);

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        pnlLogUp_Form.add(jPanel33);

        jPanel34.setLayout(new java.awt.CardLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 153));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("ĐỔI MẬT KHẨU");
        jPanel34.add(jLabel5, "card2");

        pnlLogUp_Form.add(jPanel34);

        jPanel35.setBackground(new java.awt.Color(102, 255, 255));
        jPanel35.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel35.add(jPanel36, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel35.add(jPanel37, java.awt.BorderLayout.LINE_END);

        jPanel38.setLayout(new java.awt.BorderLayout());

        jPanel39.setLayout(new java.awt.BorderLayout());

        jPanel40.setLayout(new java.awt.GridLayout(2, 0));

        jLabel6.setText("    Tên đăng nhập:");
        jPanel40.add(jLabel6);

        jPanel39.add(jPanel40, java.awt.BorderLayout.LINE_START);

        jPanel41.setLayout(new java.awt.GridLayout(2, 0));
        jPanel41.add(txtUser_PS);

        lblErrorUser_PS.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorUser_PS.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel41.add(lblErrorUser_PS);

        jPanel39.add(jPanel41, java.awt.BorderLayout.CENTER);

        jPanel38.add(jPanel39, java.awt.BorderLayout.CENTER);

        jPanel35.add(jPanel38, java.awt.BorderLayout.CENTER);

        pnlLogUp_Form.add(jPanel35);

        jPanel42.setBackground(new java.awt.Color(102, 255, 255));
        jPanel42.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel42.add(jPanel43, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel42.add(jPanel44, java.awt.BorderLayout.LINE_END);

        jPanel45.setLayout(new java.awt.BorderLayout());

        jPanel46.setLayout(new java.awt.GridLayout(2, 0));

        jLabel7.setText("         Mật khẩu cũ:");
        jLabel7.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jLabel7FocusGained(evt);
            }
        });
        jPanel46.add(jLabel7);

        jPanel45.add(jPanel46, java.awt.BorderLayout.LINE_START);

        jLayeredPane2.setLayout(new java.awt.GridLayout(2, 0));
        jLayeredPane2.add(txtPS_Old);

        lblErrorPS_Old.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorPS_Old.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLayeredPane2.add(lblErrorPS_Old);

        jPanel45.add(jLayeredPane2, java.awt.BorderLayout.CENTER);

        jPanel42.add(jPanel45, java.awt.BorderLayout.CENTER);

        pnlLogUp_Form.add(jPanel42);

        jPanel47.setBackground(new java.awt.Color(102, 255, 255));
        jPanel47.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel51Layout = new javax.swing.GroupLayout(jPanel51);
        jPanel51.setLayout(jPanel51Layout);
        jPanel51Layout.setHorizontalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel51Layout.setVerticalGroup(
            jPanel51Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel47.add(jPanel51, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel54Layout = new javax.swing.GroupLayout(jPanel54);
        jPanel54.setLayout(jPanel54Layout);
        jPanel54Layout.setHorizontalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel54Layout.setVerticalGroup(
            jPanel54Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel47.add(jPanel54, java.awt.BorderLayout.LINE_END);

        jPanel55.setLayout(new java.awt.BorderLayout());

        jPanel56.setLayout(new java.awt.GridLayout(2, 0));

        jLabel1.setText("      Mật khẩu mới:");
        jPanel56.add(jLabel1);

        jPanel55.add(jPanel56, java.awt.BorderLayout.LINE_START);

        jPanel57.setLayout(new java.awt.GridLayout(2, 0));
        jPanel57.add(txtPS_new);

        lblErrorPS_New.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorPS_New.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel57.add(lblErrorPS_New);

        jPanel55.add(jPanel57, java.awt.BorderLayout.CENTER);

        jPanel47.add(jPanel55, java.awt.BorderLayout.CENTER);

        pnlLogUp_Form.add(jPanel47);

        jPanel50.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel59Layout = new javax.swing.GroupLayout(jPanel59);
        jPanel59.setLayout(jPanel59Layout);
        jPanel59Layout.setHorizontalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel59Layout.setVerticalGroup(
            jPanel59Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel50.add(jPanel59, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel60Layout = new javax.swing.GroupLayout(jPanel60);
        jPanel60.setLayout(jPanel60Layout);
        jPanel60Layout.setHorizontalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel60Layout.setVerticalGroup(
            jPanel60Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel50.add(jPanel60, java.awt.BorderLayout.LINE_END);

        jPanel61.setLayout(new java.awt.BorderLayout());

        jPanel62.setLayout(new java.awt.GridLayout(2, 0));

        jLabel9.setText("Nhập lại mật khẩu:");
        jPanel62.add(jLabel9);

        jPanel61.add(jPanel62, java.awt.BorderLayout.LINE_START);

        jPanel63.setLayout(new java.awt.GridLayout(2, 0));

        jPanel64.setLayout(new java.awt.BorderLayout());
        jPanel64.add(txtConfirmPS, java.awt.BorderLayout.CENTER);

        jPanel63.add(jPanel64);

        jPanel65.setLayout(new java.awt.BorderLayout());

        lblErrorConfirmPS.setForeground(new java.awt.Color(204, 0, 0));
        lblErrorConfirmPS.setToolTipText("");
        lblErrorConfirmPS.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblErrorConfirmPS.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jPanel65.add(lblErrorConfirmPS, java.awt.BorderLayout.CENTER);

        jPanel63.add(jPanel65);

        jPanel61.add(jPanel63, java.awt.BorderLayout.CENTER);

        jPanel50.add(jPanel61, java.awt.BorderLayout.CENTER);

        pnlLogUp_Form.add(jPanel50);

        jPanel52.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout jPanel49Layout = new javax.swing.GroupLayout(jPanel49);
        jPanel49.setLayout(jPanel49Layout);
        jPanel49Layout.setHorizontalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel49Layout.setVerticalGroup(
            jPanel49Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel52.add(jPanel49, java.awt.BorderLayout.LINE_START);

        javax.swing.GroupLayout jPanel58Layout = new javax.swing.GroupLayout(jPanel58);
        jPanel58.setLayout(jPanel58Layout);
        jPanel58Layout.setHorizontalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel58Layout.setVerticalGroup(
            jPanel58Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        jPanel52.add(jPanel58, java.awt.BorderLayout.LINE_END);

        jPanel66.setLayout(new java.awt.BorderLayout());

        btnUpdatePS.setText("Đổi mật khẩu");
        btnUpdatePS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePSActionPerformed(evt);
            }
        });
        jPanel66.add(btnUpdatePS, java.awt.BorderLayout.CENTER);

        jPanel52.add(jPanel66, java.awt.BorderLayout.CENTER);

        pnlLogUp_Form.add(jPanel52);

        javax.swing.GroupLayout jPanel53Layout = new javax.swing.GroupLayout(jPanel53);
        jPanel53.setLayout(jPanel53Layout);
        jPanel53Layout.setHorizontalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel53Layout.setVerticalGroup(
            jPanel53Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        pnlLogUp_Form.add(jPanel53);

        javax.swing.GroupLayout jPanel48Layout = new javax.swing.GroupLayout(jPanel48);
        jPanel48.setLayout(jPanel48Layout);
        jPanel48Layout.setHorizontalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel48Layout.setVerticalGroup(
            jPanel48Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 46, Short.MAX_VALUE)
        );

        pnlLogUp_Form.add(jPanel48);

        pnlRight.add(pnlLogUp_Form, "card3");

        pnlLayout.add(pnlRight);

        getContentPane().add(pnlLayout, "card2");

        pnlWelllcome.setLayout(new java.awt.CardLayout());

        lblWellcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWellcome.setText("WELLCOME!!!");
        pnlWelllcome.add(lblWellcome, "card2");

        getContentPane().add(pnlWelllcome, "card3");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pnlLayoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlLayoutMouseClicked
        // TODO add your handling code here:
        pnlLogUp_Form.setVisible(true);
        pnlLogin_Form.setVisible(true);
    }//GEN-LAST:event_pnlLayoutMouseClicked

    private void lblOpenLeftMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOpenLeftMouseClicked
        Open();
    }//GEN-LAST:event_lblOpenLeftMouseClicked

    private void lblopenRightMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblopenRightMouseClicked
        Open();
    }//GEN-LAST:event_lblopenRightMouseClicked

    private void btnNextPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextPageActionPerformed
        // Vô hiệu hoá nút
        btnNextPage.setEnabled(false);

        // Đặt kích thước của các panel `pnlLog` và `pnlForm` thành kích thước mới
        pnlLeft.setSize((int) width1, (int) height);
        pnlRight.setSize((int) width1, (int) height);

        // Lấy vị trí hiện tại của các panel
        Point logLocation = pnlLeft.getLocation();
        int logX = logLocation.x;
        int logY = logLocation.y;

        Point formLocation = pnlRight.getLocation();
        int formX = formLocation.x;
        int formY = formLocation.y;

        // Tính toán vị trí mới cho các panel dựa trên trạng thái hiện tại
        int logNewX, formNewX;
        if (panelOnLeft) {
            logNewX = logX - pnlLeft.getWidth();
            formNewX = formX + pnlRight.getWidth();
        } else {
            logNewX = logX + pnlLeft.getWidth();
            formNewX = formX - pnlRight.getWidth();
        }

        // Giữ vị trí Y không thay đổi
        int logNewY = logY;
        int formNewY = formY;

        // Thực hiện hiệu ứng typewriter và di chuyển panel đồng thời
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                // Thực hiện hiệu ứng typewriter 
// Di chuyển panel đến vị trí mới
                animatePanel(logX, logY, logNewX, logNewY, pnlLeft);
                animatePanel(formX, formY, formNewX, formNewY, pnlRight);
//                if (btnLogUp.getText().equals("Đăng nhập ngay")) {
//                    typewriterEffect(logIn1);
//                    typewriterEffect2(logIn2);
//                } else {
//                    typewriterEffect(logUp1);
//                    typewriterEffect2(logUp2);
//                }

                return null;
            }

            @Override
            protected void done() {
                // Kích hoạt lại nút sau khi hoàn thành hiệu ứng typewriter và di chuyển panel
                btnNextPage.setEnabled(true);
            }
        };
        worker.execute();

        // Đảo ngược trạng thái của biến `panelOnLeft` để chuẩn bị cho lần bấm tiếp theo
        panelOnLeft = !panelOnLeft;

        // Kiểm tra xem đã phóng to full màn hình chưa
        if (!isMaximized) {
            // Nếu chưa, đặt biến cờ là true và bắt đầu một Timer để đợi 2 giây trước khi phóng to
            isMaximized = true;
            Timer timer = new Timer(2000, (e) -> {
                maximizePanels();
            });
            timer.setRepeats(false);
            timer.start();
        }

        // Đổi chữ và hiển thị panel tương ứng
        if (btnNextPage.getText().equals("ĐỔI MẬT KHẨU NGAY")) {
            lblTopForm.setText("BẠN MUỐN ĐĂNG NHẬP");
            btnNextPage.setText("Đăng nhập ngay");
            pnlLogin_Form.setVisible(false);
            pnlLogUp_Form.setVisible(true);
            lblContent1.setText(logIn1);
            lblContent2.setText(logIn2);
        } else {
            lblTopForm.setText("BẠN MUỐN ĐỔI MẬT KHẨU?");
            btnNextPage.setText("ĐỔI MẬT KHẨU NGAY");
            pnlLogUp_Form.setVisible(false);
            pnlLogin_Form.setVisible(true);
            lblContent1.setText(logUp1);
            lblContent2.setText(logUp2);
        }
    }//GEN-LAST:event_btnNextPageActionPerformed

    private void pnlLogUp_FormMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlLogUp_FormMouseClicked
        // TODO add your handling code here:
        pnlLogUp_Form.setVisible(true);
        pnlLogin_Form.setVisible(false);
    }//GEN-LAST:event_pnlLogUp_FormMouseClicked

    private void pnlLogin_FormMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlLogin_FormMouseClicked
        // TODO add your handling code here:
        pnlLogUp_Form.setVisible(false);
        pnlLogin_Form.setVisible(true);
    }//GEN-LAST:event_pnlLogin_FormMouseClicked

    private void pnlLogUpMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlLogUpMouseClicked

    }//GEN-LAST:event_pnlLogUpMouseClicked

    private void btnLogInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogInActionPerformed
        checkAccount();
    }//GEN-LAST:event_btnLogInActionPerformed

    private void jLabel7FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jLabel7FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel7FocusGained

    private boolean checkUpdatePassword() {
        boolean isValid = true;

        // Check if username is empty
        if (txtUser_PS.getText().equals("")) {
            lblErrorUser_PS.setText("Tên đăng nhập không được bỏ trống");
            isValid = false;
        } else if (!isUsernameExist(txtUser_PS.getText().trim())) {
            lblErrorUser_PS.setText("Tên đăng nhập không tồn tại. Lưu ý: tên đăng nhập là mã nhân viên của bạn");
            isValid = false;
        } else {
            lblErrorUser_PS.setText(""); // Clear error if valid
        }

        // Check if old password is empty
        if (txtPS_Old.getText().equals("")) {
            lblErrorPS_Old.setText("Mật khẩu cũ không được bỏ trống");
            isValid = false;
        } else {
            lblErrorPS_Old.setText(""); // Clear error if valid
        }

        // Check if new password is empty
        if (txtPS_new.getText().equals("")) {
            lblErrorPS_New.setText("Mật khẩu mới không được bỏ trống");
            isValid = false;
        } else {
            String newPassword = txtPS_new.getText();
            StringBuilder errorMessage = new StringBuilder("Mật khẩu bạn không đủ mạnh! ");
            boolean validPassword = true;

            if (!newPassword.matches(".*[A-Z].*")) {
                errorMessage.append("Bạn hãy thêm ít nhất một chữ in hoa. ");
                validPassword = false;
            }
            if (!newPassword.matches(".*[a-z].*")) {
                errorMessage.append("Bạn hãy thêm ít nhất một chữ thường. ");
                validPassword = false;
            }
            if (!newPassword.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
                errorMessage.append("Bạn hãy thêm ít nhất một ký tự đặc biệt. ");
                validPassword = false;
            }
            if (!newPassword.matches(".*[0-9].*")) {
                errorMessage.append("Bạn hãy thêm ít nhất một chữ số. ");
                validPassword = false;
            }

            if (!validPassword) {
                lblErrorPS_New.setText(errorMessage.toString());
                isValid = false;
            } else {
                lblErrorPS_New.setText(""); // Clear error if valid
            }
        }

        // Check if confirm password is empty
        if (txtConfirmPS.getText().equals("")) {
            lblErrorConfirmPS.setText("Xác nhận mật khẩu không được bỏ trống");
            isValid = false;
        } else if (!txtConfirmPS.getText().equals(txtPS_new.getText())) {
            lblErrorConfirmPS.setText("Xác nhận mật khẩu không khớp");
            isValid = false;
        } else {
            lblErrorConfirmPS.setText(""); // Clear error if valid
        }

        return isValid;
    }


    private void btnUpdatePSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdatePSActionPerformed
        if (checkUpdatePassword()) {
            String username = txtUser_PS.getText().trim();
            String oldPassword = txtPS_Old.getText();
            String newPassword = txtPS_new.getText();

            try {
                Connection con = DriverManager.getConnection(url);

                // Step 1: Check if the old password matches the one in the database
                String sqlCheck = "SELECT MAT_KHAU FROM NHAN_VIEN WHERE MA_NV = ?";
                PreparedStatement statementCheck = con.prepareStatement(sqlCheck);
                statementCheck.setString(1, username);
                ResultSet rs = statementCheck.executeQuery();

                if (rs.next()) {
                    String currentPassword = rs.getString("MAT_KHAU");

                    if (currentPassword.equals(oldPassword)) {
                        // Step 2: Update the password
                        String sqlUpdate = "UPDATE NHAN_VIEN SET MAT_KHAU = ? WHERE MA_NV = ?";
                        PreparedStatement statementUpdate = con.prepareStatement(sqlUpdate);
                        statementUpdate.setString(1, newPassword);
                        statementUpdate.setString(2, username);

                        int rowsUpdated = statementUpdate.executeUpdate();
                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(this, "Đổi mật khẩu thành công.");
                            txtUser_PS.setText("");
                            txtPS_Old.setText("");
                            txtPS_new.setText("");
                            txtConfirmPS.setText("");
                        } else {
                            JOptionPane.showMessageDialog(this, "Đổi mật khẩu thất bại.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "Mật khẩu cũ không đúng.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Tên đăng nhập không tồn tại.");
                }

                // Close the ResultSet and PreparedStatement
                rs.close();
                statementCheck.close();
                con.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật mật khẩu: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng điền đúng thông tin vào các trường.");
        }
    }//GEN-LAST:event_btnUpdatePSActionPerformed
// Khai báo một biến boolean để theo dõi trạng thái của việc phóng to
    private boolean isMaximized = false;

    private void maximizePanels() {
        this.setExtendedState(JFrame.MAXIMIZED_BOTH); // Phóng to fullscreen
        lblOpenLeft.setVisible(false);
        lblopenRight.setVisible(false);
        pnlOpenLeft.setVisible(false);
        pnlOpenRight.setVisible(false);
        pnlLogUp.setVisible(true);
        pnlLogin_Form.setVisible(true);
    }

    // Phương thức để tạo hiệu ứng trượt
// Phương thức tạo hiệu ứng trượt của panel từ vị trí hiện tại đến vị trí mới
    private void animatePanel(int startX, int startY, int endX, int endY, javax.swing.JPanel panel) {
        // Số bước để di chuyển từ vị trí hiện tại đến vị trí mới
        int steps = 20;
        // Thời gian giữa các bước di chuyển (đơn vị: mili giây)
        int duration = 10;
        // Tính toán khoảng cách di chuyển trên mỗi bước theo chiều ngang và chiều dọc
        int deltaX = (endX - startX) / steps;
        int deltaY = (endY - startY) / steps;

        try {
            // Vòng lặp để thực hiện di chuyển từng bước cho đến khi đạt vị trí mới
            for (int i = 0; i < steps; i++) {
                // Tính toán vị trí mới của panel dựa trên bước hiện tại
                int newX = startX + i * deltaX;
                int newY = startY + i * deltaY;

                // Di chuyển panel đến vị trí mới
                panel.setLocation(newX, newY);
                // Ngủ một khoảng thời gian trước khi di chuyển đến bước tiếp theo
                Thread.sleep(duration);
            }
            // Đặt vị trí cuối cùng của panel là vị trí mới
            panel.setLocation(endX, endY);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formLog().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLogIn;
    private javax.swing.JButton btnNextPage;
    private javax.swing.JButton btnUpdatePS;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JLayeredPane jLayeredPane2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel lblContent1;
    private javax.swing.JLabel lblContent2;
    private javax.swing.JLabel lblErrorConfirmPS;
    private javax.swing.JLabel lblErrorPS_New;
    private javax.swing.JLabel lblErrorPS_Old;
    private javax.swing.JLabel lblErrorPassword;
    private javax.swing.JLabel lblErrorUser_PS;
    private javax.swing.JLabel lblOpenLeft;
    private javax.swing.JLabel lblTopForm;
    private javax.swing.JLabel lblWellcome;
    private javax.swing.JLabel lblerrorUserName;
    private javax.swing.JLabel lblopenRight;
    private javax.swing.JPanel pnlLayout;
    private javax.swing.JPanel pnlLeft;
    private javax.swing.JPanel pnlLogUp;
    private javax.swing.JPanel pnlLogUp_Form;
    private javax.swing.JPanel pnlLogin_Form;
    private javax.swing.JPanel pnlOpenLeft;
    private javax.swing.JPanel pnlOpenRight;
    private javax.swing.JPanel pnlRight;
    private javax.swing.JPanel pnlWelllcome;
    private javax.swing.JPasswordField txtConfirmPS;
    private javax.swing.JPasswordField txtPS_Old;
    private javax.swing.JPasswordField txtPS_new;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUserName;
    private javax.swing.JTextField txtUser_PS;
    // End of variables declaration//GEN-END:variables
}
