package Multi_Function_Support;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;

public class ColorTextSelector {
    private static final Map<String, Color> colorMap = createColorMap();
    private JTextComponent textComponent;
    private boolean shiftHeld = false;
    private String rememberedText = "";
    private final Map<String, String> textMap = new HashMap<>();

    public ColorTextSelector(JTextComponent textComponent) {
        this.textComponent = textComponent;
        initialize();
    }

    private void initialize() {
        textComponent.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (shiftHeld) {
                        rememberSelectedText();
                        shiftHeld = false; // Reset shift state after Enter key
                    } else {
                        String colorKey = getColorKey();
                        if (colorKey != null) {
                            applyTextColor(colorKey);
                        }
                    }
                    e.consume(); // Ngăn chặn JTextComponent xử lý Enter
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = false;
                }
            }
        });
    }

    private void rememberSelectedText() {
        int start = textComponent.getSelectionStart();
        int end = textComponent.getSelectionEnd();
        if (start != end) {
            try {
                rememberedText = textComponent.getDocument().getText(start, end - start);
                textMap.put("lastSelected", rememberedText); // Lưu văn bản đã chọn vào Map
                System.out.println("Remembered Text: " + rememberedText); // Debugging
            } catch (BadLocationException e) {
                e.printStackTrace();
            }
        }
    }

    private void applyTextColor(String colorKey) {
        Color color = colorMap.get(colorKey);
        int caretPosition = textComponent.getCaretPosition();
        if (color != null && textMap.containsKey("lastSelected")) {
            if (textComponent instanceof JTextPane) {
                // Xử lý đổi màu cho JTextPane như hiện tại
                StyledDocument doc = ((JTextPane) textComponent).getStyledDocument();
                try {
                    String colorText = textMap.get("lastSelected");
                    String fullText = textComponent.getText(0, caretPosition - 3) + colorText + textComponent.getText(caretPosition, textComponent.getDocument().getLength() - caretPosition);
                    textComponent.setText(fullText); // Thay thế đoạn mã màu bằng văn bản đã lưu
                    SimpleAttributeSet attr = new SimpleAttributeSet();
                    StyleConstants.setForeground(attr, color);
                    doc.setCharacterAttributes(caretPosition - 3, colorText.length(), attr, false);
                    textComponent.setCaretPosition(caretPosition - 3 + colorText.length());
                    textMap.remove("lastSelected"); // Xóa văn bản đã lưu sau khi sử dụng
                    System.out.println("Applied Color: " + colorKey); // Debugging
                } catch (BadLocationException e) {
                    e.printStackTrace();
                }
            } else {
                // Xử lý đổi màu cho JTextField và JTextArea
                applyTextColorToTextFieldOrArea(textComponent, colorKey);
            }
        }
    }

    private String getColorKey() {
        try {
            String text = textComponent.getText();
            int caretPosition = textComponent.getCaretPosition();
            int colorStart = Math.max(0, caretPosition - 3);
            String colorKey = text.substring(colorStart, caretPosition).trim().toLowerCase();
            if (colorMap.containsKey(colorKey)) {
                System.out.println("Detected Color Key: " + colorKey); // Debugging
                return colorKey;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void applyTextColorToTextFieldOrArea(JTextComponent textComponent, String colorKey) {
        Color color = colorMap.get(colorKey);
        if (color != null) {
            textComponent.setForeground(color);
            textMap.remove("lastSelected"); // Xóa văn bản đã lưu sau khi sử dụng
            System.out.println("Applied Color: " + colorKey); // Debugging
        }
    }

    public void applyColorTextSelectorToAllComponents(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTextComponent) {
                new ColorTextSelector((JTextComponent) comp);
            } else if (comp instanceof Container) {
                applyColorTextSelectorToAllComponents((Container) comp);
            }
        }
    }

    private static Map<String, Color> createColorMap() {
        Map<String, Color> map = new HashMap<>();
        map.put("red", Color.RED);
        map.put("gre", Color.GREEN);
        map.put("blu", Color.BLUE);
        map.put("yel", Color.YELLOW);
        map.put("ora", Color.ORANGE);
        map.put("pur", Color.MAGENTA);
        map.put("pin", Color.PINK);
        map.put("bro", new Color(139, 69, 19)); // Brown
        map.put("bla", Color.BLACK);
        map.put("whi", Color.WHITE);
        map.put("gra", Color.GRAY);
        map.put("cya", Color.CYAN);
        map.put("mag", Color.MAGENTA);
        map.put("bei", new Color(245, 245, 220)); // Beige
        map.put("mar", new Color(128, 0, 0)); // Maroon
        map.put("nav", new Color(0, 0, 128)); // Navy
        map.put("tea", new Color(0, 128, 128)); // Teal
        map.put("oli", new Color(128, 128, 0)); // Olive
        map.put("ind", new Color(75, 0, 130)); // Indigo
        map.put("vio", new Color(238, 130, 238)); // Violet
        return map;
    }
}
