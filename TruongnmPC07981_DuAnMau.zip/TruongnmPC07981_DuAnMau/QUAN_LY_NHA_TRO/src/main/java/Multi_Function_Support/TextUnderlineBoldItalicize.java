package Multi_Function_Support;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class TextUnderlineBoldItalicize {

    private static boolean shiftHeld = false;
    private static boolean ctrlHeld = false;

    public static void initialize(JTextComponent textComponent) {
        textComponent.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = true;
                }
                if (e.getKeyCode() == KeyEvent.VK_CONTROL) {
                    ctrlHeld = true;
                }
                if (ctrlHeld && shiftHeld) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_U:
                            if (textComponent instanceof JTextPane) {
                                toggleUnderline(textComponent);
                            }
                            break;
                        case KeyEvent.VK_B:
                            if (textComponent instanceof JTextPane) {
                                toggleBold(textComponent);
                            }
                            break;
                        case KeyEvent.VK_I:
                            if (textComponent instanceof JTextPane) {
                                toggleItalic(textComponent);
                            }
                            break;
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
                    shiftHeld = false;
                }
                if (e.getKeyCode() == KeyEvent.VK_CONTROL) {
                    ctrlHeld = false;
                }
            }
        });
    }

    private static void toggleUnderline(JTextComponent textComponent) {
        StyledDocument doc = (StyledDocument) textComponent.getDocument();
        SimpleAttributeSet attr = new SimpleAttributeSet();
        int start = textComponent.getSelectionStart();
        int end = textComponent.getSelectionEnd();
        if (start != end) {
            AttributeSet currentAttributes = doc.getCharacterElement(start).getAttributes();
            boolean isUnderlined = StyleConstants.isUnderline(currentAttributes);
            StyleConstants.setUnderline(attr, !isUnderlined);
            doc.setCharacterAttributes(start, end - start, attr, false);
        }
    }

    private static void toggleBold(JTextComponent textComponent) {
        StyledDocument doc = (StyledDocument) textComponent.getDocument();
        SimpleAttributeSet attr = new SimpleAttributeSet();
        int start = textComponent.getSelectionStart();
        int end = textComponent.getSelectionEnd();
        if (start != end) {
            AttributeSet currentAttributes = doc.getCharacterElement(start).getAttributes();
            boolean isBold = StyleConstants.isBold(currentAttributes);
            StyleConstants.setBold(attr, !isBold);
            doc.setCharacterAttributes(start, end - start, attr, false);
        }
    }

    private static void toggleItalic(JTextComponent textComponent) {
        StyledDocument doc = (StyledDocument) textComponent.getDocument();
        SimpleAttributeSet attr = new SimpleAttributeSet();
        int start = textComponent.getSelectionStart();
        int end = textComponent.getSelectionEnd();
        if (start != end) {
            AttributeSet currentAttributes = doc.getCharacterElement(start).getAttributes();
            boolean isItalic = StyleConstants.isItalic(currentAttributes);
            StyleConstants.setItalic(attr, !isItalic);
            doc.setCharacterAttributes(start, end - start, attr, false);
        }
    }

    public static void main(String[] args) {
        // Create main application frame
        JFrame frame = new JFrame("TextFormatter Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(1, 3)); // Use GridLayout to show components side by side

        // Create a JTextPane
        JTextPane textPane = new JTextPane();
        textPane.setText("Select some text and use Ctrl+Shift+U to underline, Ctrl+Shift+B to bold, Ctrl+Shift+I to italicize.");
        initialize(textPane); // Apply TextFormatter to JTextPane

        // Create a JTextField
        JTextField textField = new JTextField("This is a JTextField. Formatting won't work here.");

        // Create a JTextArea
        JTextArea textArea = new JTextArea("Select some text and use Ctrl+Shift+U to underline, Ctrl+Shift+B to bold, Ctrl+Shift+I to italicize.");
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        // Add components to frame
        frame.getContentPane().add(new JScrollPane(textPane));
        frame.getContentPane().add(new JScrollPane(textField));
        frame.getContentPane().add(new JScrollPane(textArea));

        // Show frame
        frame.setSize(1200, 400); // Adjust size to fit all components
        frame.setVisible(true);
    }
}
