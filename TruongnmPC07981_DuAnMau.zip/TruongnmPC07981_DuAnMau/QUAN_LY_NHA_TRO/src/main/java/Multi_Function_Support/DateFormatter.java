package Multi_Function_Support;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JTextField;
import javax.swing.Timer;
import java.util.regex.Pattern;

public class DateFormatter {

    private Map<String, JTextField> textFieldMap = new HashMap<>();
    private Map<String, Integer> previousLengths = new HashMap<>();
    private Timer formatTimer;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private final Pattern datePattern = Pattern.compile("\\d{8}");

    public DateFormatter(Object formObject) {
        initTextFieldMap(formObject);
        startAutoUpdate();
    }

    private void initTextFieldMap(Object formObject) {
        Field[] fields = formObject.getClass().getDeclaredFields();
        boolean hasDateField = false;
        for (Field field : fields) {
            if (field.getType() == JTextField.class) {
                try {
                    field.setAccessible(true);
                    JTextField textField = (JTextField) field.get(formObject);
                    textFieldMap.put(field.getName(), textField);
                    if (field.getName().contains("Date")) {
                        hasDateField = true;
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        if (!hasDateField) {
            stopAutoUpdate(); // Ngừng Timer nếu không có trường nào chứa "Date"
        }
    }

    private void startAutoUpdate() {
        formatTimer = new Timer(5000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textFieldMap.forEach((name, textField) -> {
                    int currentLength = textField.getText().length();
                    Integer previousLength = previousLengths.get(name);

                    if (previousLength == null || currentLength != previousLength) {
                        previousLengths.put(name, currentLength);
                        if (name.contains("Date")) {
                            formatDateFields();
                        }
                    }
                });
            }
        });
        formatTimer.start();
    }

    public void formatDateFields() {
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Date")) {
                String input = textField.getText().trim();
                String formattedDate = formatDate(input);
                textField.setText(formattedDate);

                // Đặt con trỏ chuột ở vị trí trước ngoặc
                if (formattedDate.startsWith(" (") && formattedDate.endsWith(")")) {
                    textField.setCaretPosition(0); // Đặt con trỏ sau dấu ngoặc mở
                }
            }
        });
    }

    private String formatDate(String input) {
        // Loại bỏ các ký tự không phải số
        input = input.replaceAll("[^\\d]", "");

        try {
            // Tách năm, tháng, ngày từ chuỗi đầu vào
            String year = input.substring(0, 4);
            String month = input.substring(4, 6);
            String day = input.substring(6, 8);

            // Tạo định dạng ngày
            String formattedDate = String.format("%s-%s-%s", year, month, day);

            // Xác thực ngày
            if (isValidDate(formattedDate)) {
                return formattedDate;
            } else {
                return " (Ngày không hợp lệ)"; // Thêm ngoặc cho thông báo lỗi
            }
        } catch (Exception e) {
            return " (Ngày không hợp lệ)"; // Thêm ngoặc cho thông báo lỗi
        }
    }

    private boolean isValidDate(String date) {
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public void stopAutoUpdate() {
        if (formatTimer != null) {
            formatTimer.stop();
        }
    }
}
