package Multi_Function_Support;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

public class TextColorFormatter {

    private JTextComponent textComponent;
    private Set<Integer> keysHeld = new HashSet<>();
    private Map<Integer, Color> colorMap;

    public TextColorFormatter(JTextComponent textComponent) {
        this.textComponent = textComponent;
        initialize();
        initializeColorMap();
    }

    private void initialize() {
        textComponent.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                keysHeld.add(e.getKeyCode());

                if (keysHeld.contains(KeyEvent.VK_CONTROL) && keysHeld.contains(KeyEvent.VK_SHIFT)) {
                    Integer colorKey = keysHeld.stream().filter(colorMap::containsKey).findFirst().orElse(null);
                    if (colorKey != null) {
                        setTextColor(colorMap.get(colorKey));
                        resetKeys();
                    }
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
                keysHeld.remove(e.getKeyCode());
            }
        });
    }

    private void initializeColorMap() {
        colorMap = new HashMap<>();
        colorMap.put(KeyEvent.VK_R, Color.RED);
        colorMap.put(KeyEvent.VK_G, Color.GREEN);
        colorMap.put(KeyEvent.VK_B, Color.BLUE);
        colorMap.put(KeyEvent.VK_Y, Color.YELLOW);
        colorMap.put(KeyEvent.VK_P, Color.PINK);
        colorMap.put(KeyEvent.VK_O, Color.ORANGE);
        colorMap.put(KeyEvent.VK_W, Color.WHITE);
    }

    private void setTextColor(Color color) {
        if (textComponent instanceof StyledDocument) {
            StyledDocument doc = (StyledDocument) textComponent.getDocument();
            SimpleAttributeSet attr = new SimpleAttributeSet();
            int start = textComponent.getSelectionStart();
            int end = textComponent.getSelectionEnd();
            if (start != end) {
                StyleConstants.setForeground(attr, color);
                doc.setCharacterAttributes(start, end - start, attr, false);
            }
        } else {
            System.out.println("Text color formatting not supported for this component.");
        }
    }

    private void resetKeys() {
        keysHeld.clear();
    }

    public static void main(String[] args) {
        // Create main application frame
        JFrame frame = new JFrame("TextColorFormatter Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(1, 3)); // Use GridLayout to show components side by side

        // Create a JTextPane
        JTextPane textPane = new JTextPane();
        textPane.setText("Select some text and use Ctrl+Shift+R to turn red, Ctrl+Shift+G to turn green, Ctrl+Shift+B to turn blue, Ctrl+Shift+Y to turn yellow, Ctrl+Shift+P to turn pink, Ctrl+Shift+O to turn orange, Ctrl+Shift+W to turn white.");
        new TextColorFormatter(textPane); // Apply TextColorFormatter to JTextPane

        // Create a JTextField
        JTextField textField = new JTextField("This is a JTextField. Formatting won't work here.");

        // Create a JTextArea
        JTextArea textArea = new JTextArea("Select some text and use Ctrl+Shift+R to turn red, Ctrl+Shift+G to turn green, Ctrl+Shift+B to turn blue, Ctrl+Shift+Y to turn yellow, Ctrl+Shift+P to turn pink, Ctrl+Shift+O to turn orange, Ctrl+Shift+W to turn white.");
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        // Add components to frame
        frame.getContentPane().add(new JScrollPane(textPane));
        frame.getContentPane().add(new JScrollPane(textField));
        frame.getContentPane().add(new JScrollPane(textArea));

        // Show frame
        frame.setSize(1200, 400); // Adjust size to fit all components
        frame.setVisible(true);
    }
}
