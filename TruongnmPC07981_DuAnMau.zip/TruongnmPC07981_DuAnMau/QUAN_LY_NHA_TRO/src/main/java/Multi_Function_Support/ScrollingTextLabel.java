package Multi_Function_Support;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ScrollingTextLabel extends JLabel {
    private String text;
    private int textWidth;
    private int labelWidth;
    private int xOffset;
    private Timer timer;
    private boolean pause = false;
    private int pauseDuration = 10000; // Pause duration in milliseconds
    private long pauseStartTime;
    
    // Constructor
    public ScrollingTextLabel(String text) {
        super(text);
        this.text = text;
        setOpaque(true);
        setBackground(Color.WHITE);
        setForeground(Color.BLACK);
        setFont(new Font("Arial", Font.BOLD, 20));

        // Set default size for JLabel
        setPreferredSize(new Dimension(300, 50));

        // Initialize xOffset to start text from the beginning
        xOffset = 0;

        // Initialize Timer to update the position of text
        timer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateScrolling();
            }
        });
        timer.start();
    }

    private void updateScrolling() {
        if (text == null || text.isEmpty()) return;

        textWidth = getFontMetrics(getFont()).stringWidth(text);
        labelWidth = getWidth();

        if (!pause) {
            xOffset -= 2; // Scrolling speed

            // If the text has completely scrolled past the label's left edge
            if (xOffset < -textWidth) {
                xOffset = labelWidth; // Reset text to start position off-screen right
                pause = true; // Trigger pause
                pauseStartTime = System.currentTimeMillis(); // Record the start time of the pause
            }
        } else {
            long currentTime = System.currentTimeMillis();
            if (currentTime - pauseStartTime >= pauseDuration) {
                pause = false; // End pause
            }
        }

        repaint(); // Repaint to update the text position
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (text != null && !text.isEmpty()) {
            g.setFont(getFont());
            g.setColor(getForeground());
            g.drawString(text, xOffset, getFontMetrics(getFont()).getAscent());
        }
    }

    // Method to apply scrolling effect to JLabels in the container with specific names
    public static void applyScrollingEffect(Container container) {
        for (Component component : container.getComponents()) {
            if (component instanceof JLabel) {
                JLabel label = (JLabel) component;
                if (label.getName() != null && (label.getName().contains("lbl") || label.getName().contains("Scrolling"))) {
                    String text = label.getText();
                    if (text != null) {
                        ScrollingTextLabel scrollingLabel = new ScrollingTextLabel(text);
                        scrollingLabel.setName(label.getName());
                        container.remove(label);
                        container.add(scrollingLabel);
                    }
                }
            } else if (component instanceof Container) {
                applyScrollingEffect((Container) component); // Recursively check nested containers
            }
        }
    }

    public static void main(String[] args) {
        // Create main frame of the application
        JFrame frame = new JFrame("Scrolling Text Label");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Example labels
        JLabel label1 = new JLabel("This is a static text.");
        label1.setName("Label1");
        JLabel label2 = new JLabel("This is a scrolling text example with pause effect.");
        label2.setName("ScrollingLabel");

        // Add labels to panel
        JPanel panel = new JPanel();
        panel.add(label1);
        panel.add(label2);

        // Apply scrolling effect
        applyScrollingEffect(panel);

        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }
}
