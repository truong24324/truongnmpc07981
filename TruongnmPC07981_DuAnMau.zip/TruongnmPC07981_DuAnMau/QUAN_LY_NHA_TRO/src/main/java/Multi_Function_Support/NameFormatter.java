package Multi_Function_Support;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JTextField;
import javax.swing.Timer;

/**
 * Lớp định dạng tên cho các JTextField trong một đối tượng.
 */
public class NameFormatter {
    private Map<String, JTextField> textFieldMap = new HashMap<>();
    private Map<String, Integer> previousLengths = new HashMap<>();
    private Timer formatTimer;

    public NameFormatter(Object formObject) {
        initTextFieldMap(formObject);
        startAutoUpdate();
        addActionListeners();
    }

    private void addActionListeners() {
        textFieldMap.values().forEach(textField -> textField.addActionListener(e -> formatNameFields()));
    }

    private void initTextFieldMap(Object formObject) {
        Field[] fields = formObject.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.getType() == JTextField.class) {
                try {
                    field.setAccessible(true);
                    JTextField textField = (JTextField) field.get(formObject);
                    if (textField != null) {
                        textFieldMap.put(field.getName(), textField);
                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace(); // Consider logging this error
                }
            }
        }
    }

    private void startAutoUpdate() {
        if (checkForNameFields()) {
            formatTimer = new Timer(5000, e -> {
                textFieldMap.forEach((name, textField) -> {
                    int currentLength = textField.getText().length();
                    Integer previousLength = previousLengths.get(name);

                    if (previousLength == null || currentLength != previousLength) {
                        previousLengths.put(name, currentLength);
                        if (name.contains("Name")) {
                            formatNameFields();
                        }
                    }
                });
            });
            formatTimer.start();
        } else {
            stopAutoUpdate();
        }
    }

    private boolean checkForNameFields() {
        return textFieldMap.keySet().stream().anyMatch(name -> name.contains("Name"));
    }

    private void formatNameFields() {
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Name")) {
                String input = textField.getText().trim();
                String formattedName = formatName(input);
                textField.setText(formattedName);
            }
        });
    }

    private String formatName(String name) {
        return capitalizeWords(removeNonAlphabetic(name));
    }

    private String removeNonAlphabetic(String input) {
        return input.replaceAll("[^\\p{L}\\p{Z}]", "");
    }

    private String capitalizeWords(String input) {
        StringBuilder formattedName = new StringBuilder();
        String[] words = input.split("\\s+");
        for (String word : words) {
            if (!word.isEmpty()) {
                formattedName.append(Character.toUpperCase(word.charAt(0)));
                
                // Chuyển các ký tự còn lại thành chữ thường
                for (int i = 1; i < word.length(); i++) {
                    formattedName.append(Character.toLowerCase(word.charAt(i)));
                }
                
                formattedName.append(" ");
            }
        }
        return formattedName.toString().trim();
    }

    public void stopAutoUpdate() {
        if (formatTimer != null) {
            formatTimer.stop();
        }
    }
}
