/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Multi_Function_Support;

/**
 *
 * @author someo
 */
public interface  PasswordSaveListener {
        void onPasswordGenerated(String hashedPassword);
}
