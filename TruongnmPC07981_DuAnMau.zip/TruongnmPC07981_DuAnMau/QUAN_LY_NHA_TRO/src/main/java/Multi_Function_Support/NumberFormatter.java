package Multi_Function_Support;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.swing.JTextField;
import javax.swing.Timer;

public class NumberFormatter {

    private Map<String, JTextField> textFieldMap = new HashMap<>();
    private Map<String, Integer> previousLengths = new HashMap<>();
    private Timer formatTimer;

    public NumberFormatter(Object formObject) {
        // Khởi tạo danh sách các JTextField từ đối tượng form
        initTextFieldMap(formObject);
        // Bắt đầu quá trình tự động cập nhật định dạng
        startAutoUpdate();
    }

    private void initTextFieldMap(Object formObject) {
        Field[] fields = formObject.getClass().getDeclaredFields();
        for (Field field : fields) {
            if (field.getType() == JTextField.class) {
                try {
                    field.setAccessible(true);
                    JTextField textField = (JTextField) field.get(formObject);
                    // Thêm JTextField vào bản đồ với tên của nó làm khóa
                    textFieldMap.put(field.getName(), textField);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void startAutoUpdate() {
        // Kiểm tra xem có thành phần nào chứa từ "Money", "Number" hay "Phone" không
        if (checkForMoneyFields() || checkForNumberFields() || checkForPhoneFields()) {
            // Khởi tạo Timer để tự động cập nhật định dạng mỗi giây (1000 milliseconds)
            formatTimer = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    textFieldMap.forEach((name, textField) -> {
                        int currentLength = textField.getText().length();
                        Integer previousLength = previousLengths.get(name);

                        // Nếu độ dài văn bản không thay đổi, không cần cập nhật
                        if (previousLength == null || currentLength != previousLength) {
                            previousLengths.put(name, currentLength);
                            if (name.contains("Money_")) {
                                // Cập nhật định dạng số tiền cho các trường có tên chứa "Money_"
                                formatCurrencyFields();
                            } else if (name.contains("Number")) {
                                // Cập nhật định dạng số cho các trường có tên chứa "Number"
                                formatNumberFields();
                            } else if (name.contains("Phone")) {
                                // Cập nhật định dạng số điện thoại cho các trường có tên chứa "Phone"
                                formatPhoneFields();
                            } 
                        }
                    });
                }
            });

            formatTimer.start();
        } else {
            // Dừng Timer nếu không có thành phần nào chứa từ "Money_", "Number", hoặc "Phone"
            stopAutoUpdate();
        }
    }

    private boolean checkForMoneyFields() {
        // Kiểm tra sự tồn tại của các thành phần có tên chứa từ "Money_"
        return textFieldMap.keySet().stream().anyMatch(name -> name.contains("Money_"));
    }

    private boolean checkForNumberFields() {
        // Kiểm tra sự tồn tại của các thành phần có tên chứa từ "Number"
        return textFieldMap.keySet().stream().anyMatch(name -> name.contains("Number"));
    }

    private boolean checkForPhoneFields() {
        // Kiểm tra sự tồn tại của các thành phần có tên chứa từ "Phone"
        return textFieldMap.keySet().stream().anyMatch(name -> name.contains("Phone"));
    }

    private String formatNumber(String input) {
        // Xóa tất cả các ký tự không phải số và khoảng trắng
        input = input.replaceAll("\\D+", ""); // Xóa tất cả các ký tự không phải số

        try {
            // Chuyển đổi đầu vào thành BigDecimal để xử lý số lớn
            BigDecimal amount = new BigDecimal(input);

            // Định dạng số với dấu phân cách hàng nghìn là dấu phẩy
            NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
            DecimalFormat decimalFormat = (DecimalFormat) numberFormat;
            decimalFormat.setGroupingUsed(true);
            decimalFormat.setGroupingSize(3);
            decimalFormat.setMaximumFractionDigits(0); // Không có phần thập phân

            // Định dạng số và không thêm đơn vị
            return decimalFormat.format(amount);
        } catch (NumberFormatException e) {
            // Trả về đầu vào gốc nếu không thể chuyển đổi
            return input;
        }
    }

    private String formatCurrency(String input, String currencyUnit) {
        // Xóa tất cả các ký tự không phải số và khoảng trắng
        input = input.replaceAll("\\D+", ""); // Xóa tất cả các ký tự không phải số

        try {
            // Chuyển đổi đầu vào thành BigDecimal để xử lý số lớn
            BigDecimal amount = new BigDecimal(input);

            // Định dạng số tiền với dấu phân cách hàng nghìn là dấu phẩy
            NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
            DecimalFormat decimalFormat = (DecimalFormat) numberFormat;
            decimalFormat.setGroupingUsed(true);
            decimalFormat.setGroupingSize(3);
            decimalFormat.setMaximumFractionDigits(0); // Không có phần thập phân

            // Định dạng số tiền và thêm đơn vị
            return decimalFormat.format(amount) + " " + currencyUnit;
        } catch (NumberFormatException e) {
            // Trả về đầu vào gốc nếu không thể chuyển đổi
            return input;
        }
    }

    private String formatPhone(String input) {
        // Xóa tất cả các ký tự không phải số và khoảng trắng
        input = input.replaceAll("\\D+", ""); // Xóa tất cả các ký tự không phải số

        // Định dạng số điện thoại theo mẫu 0x xxx xxx xxx (Ví dụ: 098 765 4321)
        if (input.length() > 4) {
            StringBuilder formattedPhone = new StringBuilder(input);
            formattedPhone.insert(4, ' ');
            if (formattedPhone.length() > 8) {
                formattedPhone.insert(8, ' ');
            }
            return formattedPhone.toString();
        }
        return input;
    }

    private void setCursorAfterNumber(JTextField textField) {
        String text = textField.getText();
        int cursorPosition = text.indexOf(' ') == -1 ? text.length() : text.indexOf(' ');
        textField.setCaretPosition(cursorPosition);
    }

    public void formatCurrencyFields() {
        // Định dạng các trường có tên chứa từ "Money_"
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Money_")) {
                String input = textField.getText().trim();
                String currencyUnit = extractCurrencyUnit(name);
                // Thực hiện định dạng
                String formattedAmount = formatCurrency(input, currencyUnit);
                textField.setText(formattedAmount);
                setCursorAfterNumber(textField);
            }
        });
    }

    private String extractCurrencyUnit(String fieldName) {
        // Tách đơn vị tiền tệ từ tên thành phần "Money_..."
        int startIndex = fieldName.indexOf("Money_") + 6;
        if (startIndex >= fieldName.length()) {
            return ""; // Trường hợp không có đơn vị sau "Money_"
        }
        int endIndex = fieldName.indexOf('_', startIndex);
        if (endIndex == -1) {
            endIndex = fieldName.length(); // Không có dấu _, lấy từ startIndex đến hết chuỗi
        }
        return fieldName.substring(startIndex, endIndex).replaceAll("[^a-zA-Z]", "").trim();
    }

    public void formatNumberFields() {
        // Định dạng các trường có tên chứa từ "Number"
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Number")) {
                String input = textField.getText().trim();
                // Thực hiện định dạng
                String formattedAmount = formatNumber(input);
                textField.setText(formattedAmount);
                setCursorAfterNumber(textField);
            }
        });
    }

    public void formatPhoneFields() {
        // Định dạng các trường có tên chứa từ "Phone"
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Phone")) {
                String input = textField.getText().trim();
                // Thực hiện định dạng
                String formattedPhone = formatPhone(input);
                textField.setText(formattedPhone);
                setCursorAfterNumber(textField);
            }
        });
    }

    public void resetCurrencyFields() {
        // Đặt lại định dạng cho các trường có tên chứa từ "Money_"
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Money_")) {
                String input = textField.getText().trim();
                if (isValidCurrency(input)) {
                    String resetAmount = resetCurrency(input);
                    textField.setText(resetAmount);
                }
            }
        });
    }

    public void resetNumberFields() {
        // Đặt lại định dạng cho các trường có tên chứa từ "Number"
        textFieldMap.forEach((name, textField) -> {
            if (name.contains("Number")) {
                String input = textField.getText().trim();
                if (isValidNumber(input)) {
                    String resetAmount = resetNumber(input);
                    textField.setText(resetAmount);
                }
            }
        });
    }

    public void resetAllCurrencyFields() {
        // Đặt lại định dạng cho tất cả các trường
        textFieldMap.forEach((name, textField) -> {
            String resetAmount = resetCurrency(textField.getText().trim());
            textField.setText(resetAmount);
        });
    }

    private boolean isValidCurrency(String input) {
        // Kiểm tra xem chuỗi có phải là số tiền hợp lệ không
        return input.matches("^\\d{1,3}(\\.\\d{3})*(,\\d{2})?(\\s*\\w+)?$");
    }

    private boolean isValidNumber(String input) {
        // Kiểm tra xem chuỗi có phải là số hợp lệ không
        return input.matches("\\d+(\\.\\d+)?");
    }

    private String resetCurrency(String input) {
        // Xóa tất cả các ký tự không phải số và khoảng trắng
        return input.replaceAll("[^\\d]", "");
    }

    private String resetNumber(String input) {
        // Xóa tất cả các ký tự không phải số và khoảng trắng
        return input.replaceAll("\\D+", "");
    }

    public void stopAutoUpdate() {
        if (formatTimer != null) {
            formatTimer.stop();
        }
    }
}
