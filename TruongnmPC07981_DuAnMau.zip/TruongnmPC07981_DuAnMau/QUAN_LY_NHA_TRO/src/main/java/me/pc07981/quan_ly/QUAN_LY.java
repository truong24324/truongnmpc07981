/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package me.pc07981.quan_ly;

/**
 *
 * @author someo
 */
public class QUAN_LY {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
