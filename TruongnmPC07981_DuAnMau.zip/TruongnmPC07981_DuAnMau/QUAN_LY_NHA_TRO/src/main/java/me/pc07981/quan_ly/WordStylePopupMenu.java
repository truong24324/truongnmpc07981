package me.pc07981.quan_ly;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WordStylePopupMenu extends JPopupMenu {

    public WordStylePopupMenu() {
        // Hàng đầu tiên có 4 ô
        add(createMenuItem("Cut"));
        add(createMenuItem("Copy"));
        add(createMenuItem("Paste"));
        add(createMenuItem("Undo"));
        addSeparator(); // Thêm một đường ngăn cách

        // Các hàng tiếp theo, mỗi hàng có 1 ô
        for (int i = 1; i <= 12; i++) {
            add(createMenuItem("Item " + (i + 4)));
        }

        // Ví dụ ActionListener cho các JMenuItem
        for (Component component : getComponents()) {
            if (component instanceof JMenuItem) {
                JMenuItem menuItem = (JMenuItem) component;
                menuItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println(menuItem.getText() + " clicked");
                    }
                });
            }
        }
    }

    private JMenuItem createMenuItem(String text) {
        JMenuItem menuItem = new JMenuItem(text);
        menuItem.setPreferredSize(new Dimension(150, 30)); // Điều chỉnh kích thước nếu cần
        return menuItem;
    }
}
