import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import Entity_Dao.User;
import Entity_Dao.UserDao;

@WebServlet({ "/account/sign-up", "/account/sign-in", "/account/sign-out", "/home/*", "/admin/*" })
public class LogServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDao userDao;

    public LogServlet() {
        super();
        userDao = new UserDao();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();

        if (action.startsWith("/home")) {
            HttpSession session = request.getSession(false);
            if (session != null && session.getAttribute("user") != null) {
                // Allow access
                request.getRequestDispatcher("/views/home.jsp").forward(request, response);
            } else {
                response.sendRedirect(request.getContextPath() + "/account/sign-in");
            }
        } else if (action.startsWith("/admin")) {
            HttpSession session = request.getSession(false);
            if (session != null && session.getAttribute("user") != null) {
                User user = (User) session.getAttribute("user");
                if ("Admin".equals(user.getRole())) {
                    // Allow access to admin page
                    request.getRequestDispatcher("/views/admin/dashboard.jsp").forward(request, response);
                } else {
                    response.sendRedirect(request.getContextPath() + "/home");
                }
            } else {
                response.sendRedirect(request.getContextPath() + "/account/sign-in");
            }
        } else {
            switch (action) {
                case "/account/sign-up":
                    showSignUpForm(request, response);
                    break;
                case "/account/sign-in":
                    showSignInForm(request, response);
                    break;
                case "/account/sign-out":
                    signOut(request, response);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                    break;
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();

        switch (action) {
            case "/account/sign-up":
                signUp(request, response);
                break;
            case "/account/sign-in":
                signIn(request, response);
                break;
            default:
                doGet(request, response);
                break;
        }
    }

    private void showSignUpForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
    }

    private void showSignInForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
    }

    private void signUp(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idUser = request.getParameter("idUser");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = new User();
        user.setIdUser(idUser);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole("USER"); // Default role for new users

        try {
            userDao.create(user);
            request.setAttribute("message", "Đăng ký thành công! Vui lòng đăng nhập.");
            request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Đã xảy ra lỗi trong quá trình đăng ký.");
            request.getRequestDispatcher("/views/account/sign-up.jsp").forward(request, response);
        }
    }

    private void signIn(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idUser = request.getParameter("idUser");
        String password = request.getParameter("password");

        User user = userDao.findById(idUser);

        if (user != null && user.getPassword().equals(password)) { // Add proper password hashing check
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("role", user.getRole());
            
            // Create a message indicating the role the user has signed in with
            String loginMessage = "Đăng nhập thành công với tư cách: " + user.getRole();
            session.setAttribute("loginMessage", loginMessage);
            
            response.sendRedirect(request.getContextPath() + "/home"); // Redirect to home page after sign-in
        } else {
            request.setAttribute("message", "Thông tin đăng nhập không chính xác, vui lòng thử lại.");
            request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
        }
    }

    private void signOut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();
        request.setAttribute("message", "Đã đăng xuất.");

        response.sendRedirect(request.getContextPath() + "/home"); // Redirect to home page after sign-out
    }
}
