package Servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity_Dao.ProductDao;
import Entity_Dao.Products;

/**
 * Nguyễn Minh Trường - PC07981 
 */
@WebServlet({"/product/index", "/product/edit/*", "/product/create", "/product/update", "/product/delete"})
public class ProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ProductServlet() {
        super();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ProductDao dao = new ProductDao();
        String uri = req.getRequestURI();

        try {
            if (uri.contains("create")) {
                create(req, resp, dao);
            } else if (uri.contains("edit")) {
                edit(req, resp, dao);
            } else if (uri.contains("update")) {
                update(req, resp, dao);
            } else if (uri.contains("delete")) {
                delete(req, resp, dao);
            } else {
                index(req, resp, dao);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    // Tính năng thêm (Create)
    private void create(HttpServletRequest req, HttpServletResponse resp, ProductDao dao) throws ServletException, IOException {
        try {
            Products product = new Products();
            product.setIdPro(req.getParameter("idPro"));
            product.setNamePro(req.getParameter("namePro"));
            product.setPrice(parsePrice(req.getParameter("price")));
            product.setCreationDate(parseDate(req.getParameter("creationDate")));
            product.setImage(req.getParameter("image"));
            product.setBarcode(parseBarcode(req.getParameter("barcode")));

            // Cần thiết lập thêm thuộc tính người dùng (User) nếu có

            dao.create(product);
            req.getSession().setAttribute("message", "Sản phẩm đã được tạo thành công!");
            req.getSession().setAttribute("messageType", "success");
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi tạo sản phẩm!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/product/index");
    }

    // Tính năng sửa (Edit)
    private void edit(HttpServletRequest req, HttpServletResponse resp, ProductDao dao) throws ServletException, IOException {
        String id = req.getPathInfo().substring(1);
        Products product = dao.findById(id);
        req.setAttribute("product", product);
        req.getRequestDispatcher("/product/edit.jsp").forward(req, resp);
    }

    // Tính năng cập nhật (Update)
    private void update(HttpServletRequest req, HttpServletResponse resp, ProductDao dao) throws ServletException, IOException {
        try {
            Products product = dao.findById(req.getParameter("idPro"));
            if (product != null) {
                product.setNamePro(req.getParameter("namePro"));
                product.setPrice(parsePrice(req.getParameter("price")));
                product.setCreationDate(parseDate(req.getParameter("creationDate")));
                product.setImage(req.getParameter("image"));
                product.setBarcode(parseBarcode(req.getParameter("barcode")));

                // Cần thiết lập thêm thuộc tính người dùng (User) nếu có

                dao.update(product);
                req.getSession().setAttribute("message", "Sản phẩm đã được cập nhật thành công!");
                req.getSession().setAttribute("messageType", "success");
            } else {
                req.getSession().setAttribute("message", "Sản phẩm không tồn tại!");
                req.getSession().setAttribute("messageType", "danger");
            }
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi cập nhật sản phẩm!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/product/index");
    }

    // Tính năng xóa (Delete)
    private void delete(HttpServletRequest req, HttpServletResponse resp, ProductDao dao) throws ServletException, IOException {
        try {
            String id = req.getParameter("idPro");
            Products product = dao.findById(id);
            if (product != null) {
                dao.remove(product);
                req.getSession().setAttribute("message", "Sản phẩm đã được xóa thành công!");
                req.getSession().setAttribute("messageType", "success");
            } else {
                req.getSession().setAttribute("message", "Sản phẩm không tồn tại!");
                req.getSession().setAttribute("messageType", "danger");
            }
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi xóa sản phẩm!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/product/index");
    }

    private void index(HttpServletRequest req, HttpServletResponse resp, ProductDao dao) throws ServletException, IOException {
        List<Products> products = dao.findAll();
        req.setAttribute("products", products);
        req.getRequestDispatcher("/views/product/index.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Redirect to create product form
        req.getRequestDispatcher("/product/create.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        service(req, resp);
    }

    // Utility method to parse date
    private Date parseDate(String dateString) {
        try {
            if (dateString != null && !dateString.trim().isEmpty()) {
                return new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
            }
        } catch (ParseException e) {
            e.printStackTrace(); // Optional: log the exception
        }
        return null;
    }

    // Utility method to parse price
    private BigDecimal parsePrice(String priceString) {
        try {
            if (priceString != null && !priceString.trim().isEmpty()) {
                return new BigDecimal(priceString);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace(); // Optional: log the exception
        }
        return null;
    }

    // Utility method to parse barcode
    private Long parseBarcode(String barcodeString) {
        try {
            if (barcodeString != null && !barcodeString.trim().isEmpty()) {
                return Long.parseLong(barcodeString);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace(); // Optional: log the exception
        }
        return null;
    }
}
