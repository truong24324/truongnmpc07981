package Servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity_Dao.User;
import Entity_Dao.UserDao;

/**
 * Nguyễn Minh Trường - PC07981 
 * 
 */
@WebServlet({"/user/index", "/user/edit/*", "/user/create", "/user/update", "/user/delete"})
public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UserServlet() {
        super();
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserDao dao = new UserDao();
        String uri = req.getRequestURI();

        try {
            if (uri.contains("create")) {
                create(req, resp, dao);
            } else if (uri.contains("edit")) {
                edit(req, resp, dao);
            } else if (uri.contains("update")) {
                update(req, resp, dao);
            } else if (uri.contains("delete")) {
                delete(req, resp, dao);
            } else {
                index(req, resp, dao);
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    // Tính năng thêm (Create)
    private void create(HttpServletRequest req, HttpServletResponse resp, UserDao dao) throws ServletException, IOException {
        try {
            User user = new User();
            user.setIdUser(req.getParameter("id")); // Use setIdUser
            user.setFullName(req.getParameter("fullname")); // Use setFullName
            user.setEmail(req.getParameter("email"));
            user.setPhone(req.getParameter("phone"));
            user.setAddress(req.getParameter("address"));
            user.setGender(req.getParameter("gender"));
            user.setBirthday(parseDate(req.getParameter("birthday")));
            user.setRole(req.getParameter("role"));
            user.setImage(req.getParameter("image"));
            user.setPassword(req.getParameter("password"));;

            dao.create(user);
            req.getSession().setAttribute("message", "Người dùng đã được tạo thành công!");
            req.getSession().setAttribute("messageType", "success");
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi tạo người dùng!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/user/index");
    }

    // Tính năng sửa (Edit)
    private void edit(HttpServletRequest req, HttpServletResponse resp, UserDao dao) throws ServletException, IOException {
        String id = req.getPathInfo().substring(1);
        User user = dao.findById(id);
        req.setAttribute("user", user);
        req.getRequestDispatcher("/user/edit.jsp").forward(req, resp);
    }

    // Tính năng cập nhật (Update)
    private void update(HttpServletRequest req, HttpServletResponse resp, UserDao dao) throws ServletException, IOException {
        try {
            User user = dao.findById(req.getParameter("id"));
            if (user != null) {
                user.setFullName(req.getParameter("fullname")); // Use setFullName
                user.setEmail(req.getParameter("email"));
                user.setPhone(req.getParameter("phone"));
                user.setAddress(req.getParameter("address"));
                user.setGender(req.getParameter("gender"));
                user.setBirthday(parseDate(req.getParameter("birthday")));
                user.setRole(req.getParameter("role"));
                user.setImage(req.getParameter("image"));
                user.setPassword(req.getParameter("password"));


                dao.update(user);
                req.getSession().setAttribute("message", "Người dùng đã được cập nhật thành công!");
                req.getSession().setAttribute("messageType", "success");
            } else {
                req.getSession().setAttribute("message", "Người dùng không tồn tại!");
                req.getSession().setAttribute("messageType", "danger");
            }
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi cập nhật người dùng!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/user/index");
    }

    // Tính năng xóa (Delete)
    private void delete(HttpServletRequest req, HttpServletResponse resp, UserDao dao) throws ServletException, IOException {
        try {
            String id = req.getParameter("id");
            User user = dao.findById(id);
            if (user != null) {
                dao.remove(user);
                req.getSession().setAttribute("message", "Người dùng đã được xóa thành công!");
                req.getSession().setAttribute("messageType", "success");
            } else {
                req.getSession().setAttribute("message", "Người dùng không tồn tại!");
                req.getSession().setAttribute("messageType", "danger");
            }
        } catch (Exception e) {
            req.getSession().setAttribute("message", "Lỗi khi xóa người dùng!");
            req.getSession().setAttribute("messageType", "danger");
        }
        resp.sendRedirect(req.getContextPath() + "/user/index");
    }

    private void index(HttpServletRequest req, HttpServletResponse resp, UserDao dao) throws ServletException, IOException {
        List<User> users = dao.findAll();
        req.setAttribute("users", users);
        req.getRequestDispatcher("/views/user/index.jsp").forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Redirect to create user form
        req.getRequestDispatcher("/user/create.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        service(req, resp);
    }

    // Utility method to parse date
    private Date parseDate(String dateString) {
        try {
            if (dateString != null && !dateString.trim().isEmpty()) {
                return new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
            }
        } catch (ParseException e) {
            // Handle parsing exception
            e.printStackTrace(); // Optional: log the exception
        }
        return null; // Return null if parsing fails or dateString is invalid
    }
}
