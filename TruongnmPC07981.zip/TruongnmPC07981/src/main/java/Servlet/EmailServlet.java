package Servlet;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity_Dao.User;
import Entity_Dao.UserDao;

@WebServlet({"/forgot-password"})
public class EmailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String EMAIL = "nguyentruong858301@gmail.com";
    private static final String PASSWORD = "gfpecmvzgdnmugxh";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");

        // Tạo một instance của UserDao để kiểm tra email
        UserDao userDao = new UserDao();
        User user = userDao.findById(userId);

        if (user == null || user.getEmail() == null) {
            request.setAttribute("message", "Tài khoản không tồn tại hoặc email không hợp lệ.");
            request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
            return;
        }

        // Tạo mã xác nhận ngẫu nhiên gồm 6 chữ số
        String confirmationCode = generateConfirmationCode();
        user.setConfirmation(confirmationCode);

        // Cập nhật mã xác nhận vào cơ sở dữ liệu
        userDao.update(user);

        // Cấu hình email
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.ssl.protocols", "TLSv1.2");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL, PASSWORD);
            }
        });

        // Soạn thảo email
        String receiverEmail = user.getEmail(); // Lấy email từ đối tượng User
        String subject = "Đặt lại mật khẩu";
        String content = "<!DOCTYPE html>"
                + "<html>"
                + "<head>"
                + "<style>"
                + "body {"
                + "    font-family: Arial, sans-serif;"
                + "    background-color: #f4f4f4;"
                + "    margin: 0;"
                + "    padding: 0;"
                + "}"
                + ".container {"
                + "    width: 80%;"
                + "    max-width: 600px;"
                + "    margin: auto;"
                + "    background-color: #ffffff;"
                + "    padding: 20px;"
                + "    border-radius: 8px;"
                + "    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);"
                + "}"
                + ".header {"
                + "    background-color: #007bff;"
                + "    color: #ffffff;"
                + "    padding: 10px;"
                + "    text-align: center;"
                + "    border-radius: 8px 8px 0 0;"
                + "}"
                + ".content {"
                + "    margin: 20px 0;"
                + "}"
                + ".confirmation-code {"
                + "    font-size: 24px;"
                + "    color: #007bff;"
                + "    display: inline-block;"
                + "    padding: 10px;"
                + "    border: 1px solid #007bff;"
                + "    border-radius: 4px;"
                + "}"
                + ".button {"
                + "    display: inline-block;"
                + "    font-size: 16px;"
                + "    color: #ffffff;"
                + "    background-color: #007bff;"
                + "    padding: 10px 20px;"
                + "    border-radius: 4px;"
                + "    text-decoration: none;"
                + "    margin-top: 20px;"
                + "}"
                + ".footer {"
                + "    font-size: 12px;"
                + "    color: #888888;"
                + "    text-align: center;"
                + "    margin-top: 20px;"
                + "}"
                + "</style>"
                + "<script>"
                + "function copyToClipboard(text) {"
                + "    var textArea = document.createElement('textarea');"
                + "    textArea.value = text;"
                + "    document.body.appendChild(textArea);"
                + "    textArea.select();"
                + "    document.execCommand('copy');"
                + "    document.body.removeChild(textArea);"
                + "    alert('Mã xác nhận đã được sao chép vào clipboard: ' + text);"
                + "}"
                + "</script>"
                + "</head>"
                + "<body>"
                + "<div class='container'>"
                + "<div class='header'>"
                + "<h1>Đặt lại mật khẩu</h1>"
                + "</div>"
                + "<div class='content'>"
                + "<p>Chúng tôi đã nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn.</p>"
                + "<p>Mã xác nhận của bạn là:</p>"
                + "<p class='confirmation-code'>" + confirmationCode + "</p>"
                + "<p>Vui lòng nhập mã xác nhận này để đặt lại mật khẩu.</p>"
                + "<p>Nhấn vào nút dưới đây để sao chép mã xác nhận:</p>"
                + "<a href='#' class='button' onclick='copyToClipboard(\"" + confirmationCode + "\")'>Sao chép mã xác nhận</a>"
                + "</div>"
                + "<div class='footer'>"
                + "<p>Chúng tôi không yêu cầu thông tin cá nhân qua email. Nếu bạn không yêu cầu đặt lại mật khẩu, vui lòng bỏ qua email này.</p>"
                + "</div>"
                + "</div>"
                + "</body>"
                + "</html>";



        MimeMessage message = new MimeMessage(session);
        try {
            message.setFrom(new InternetAddress(EMAIL));
            message.setRecipients(MimeMessage.RecipientType.TO, InternetAddress.parse(receiverEmail));
            message.setSubject(subject, "utf-8");
            message.setContent(content, "text/html; charset=utf-8");
            Transport.send(message);
            request.setAttribute("message", "Đã gửi mã xác nhận. Vui lòng kiểm tra email của bạn.");
            request.setAttribute("userId", userId);

        } catch (MessagingException e) {
            System.out.println("Error message: " + e.getMessage());
            System.out.println("Error cause: " + e.getCause());
            e.printStackTrace();
            request.setAttribute("message", "Có lỗi xảy ra khi gửi email. Vui lòng thử lại.");
        }

        request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
    }

    // Phương thức tạo mã xác nhận ngẫu nhiên gồm 6 chữ số
    private String generateConfirmationCode() {
        SecureRandom random = new SecureRandom();
        int code = random.nextInt(900000) + 100000; // Tạo số ngẫu nhiên từ 100000 đến 999999
        return String.valueOf(code);
    }
   
    
}
