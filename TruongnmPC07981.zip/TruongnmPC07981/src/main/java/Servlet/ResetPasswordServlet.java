package Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Entity_Dao.User;
import Entity_Dao.UserDao;

@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = request.getParameter("userId");
        String confirmationCode = request.getParameter("confirmationCode");
        String newPassword = request.getParameter("newPassword");

        // Create an instance of UserDao to access the database
        UserDao userDao = new UserDao();
        User user = userDao.findById(userId);
        request.setAttribute("userId", userId);


        if (user == null) {
            request.setAttribute("message", "Tài khoản không tồn tại.");
            request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
            return;
        }

        if (!confirmationCode.equals(user.getConfirmation())) {
            request.setAttribute("message", "Mã xác nhận không chính xác.");
            request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
            return;
        }

        // Update the user's password
        user.setPassword(newPassword); // Ensure to hash the new password before saving
        user.setConfirmation(null); // Clear the confirmation code
        userDao.update(user);

        request.setAttribute("message", "Mật khẩu đã được đặt lại thành công.");
        request.getRequestDispatcher("/views/account/sign-in.jsp").forward(request, response);
    }
}
