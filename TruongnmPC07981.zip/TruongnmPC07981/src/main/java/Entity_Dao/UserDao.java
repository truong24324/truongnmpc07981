package Entity_Dao;

import java.util.List;
import Servlet.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

public class UserDao {
    EntityManager entityManager = JpaUtil.getEntityManager();
    
    public void create(User user) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(user);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            // Handle exception
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }

    public void update(User user) {
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(user);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            // Handle exception
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }
    public boolean emailExists(String email) {
        String jpql = "SELECT COUNT(u) FROM User u WHERE u.email = :email";
        TypedQuery<Long> query = entityManager.createQuery(jpql, Long.class);
        query.setParameter("email", email);
        return query.getSingleResult() > 0;
    }
    public User findByEmail(String email) {
        String jpql = "SELECT u FROM User u WHERE u.email = :email";
        try {
            return entityManager.createQuery(jpql, User.class)
                                .setParameter("email", email)
                                .getSingleResult();
        } catch (NoResultException e) {
            return null; // Hoặc xử lý theo cách khác nếu không tìm thấy người dùng
        }
    }




    public void remove(User user) {
        try {
            entityManager.getTransaction().begin();
            if (!entityManager.contains(user)) {
                user = entityManager.merge(user);
            }
            entityManager.remove(user);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            // Handle exception
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }
    

    public User findById(String idUser) {
        return entityManager.find(User.class, idUser);
    }

    public List<User> findAll() {
        String jpql = "Select u from User u";
        TypedQuery<User> query = entityManager.createQuery(jpql, User.class);
        return query.getResultList();
    }
}
