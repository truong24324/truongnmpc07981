package Entity_Dao;

import java.util.List;
import Servlet.JpaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.TypedQuery;

public class ProductDao {
    EntityManager entityManager = JpaUtil.getEntityManager();
    
    public void create(Products product) {
        try {
            entityManager.getTransaction().begin();
            entityManager.persist(product);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }

    public void update(Products product) {
        try {
            entityManager.getTransaction().begin();
            entityManager.merge(product);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }

    public void remove(Products product) {
        try {
            entityManager.getTransaction().begin();
            if (!entityManager.contains(product)) {
                product = entityManager.merge(product);
            }
            entityManager.remove(product);
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            entityManager.getTransaction().rollback();
            e.printStackTrace(); // Optional: log or handle the exception appropriately
        }
    }
    
    public Products findById(String idPro) {
        return entityManager.find(Products.class, idPro);
    }

    public List<Products> findAll() {
        String jpql = "SELECT p FROM Products p";
        TypedQuery<Products> query = entityManager.createQuery(jpql, Products.class);
        return query.getResultList();
    }

    public List<Products> findByUserId(String userId) {
        String jpql = "SELECT p FROM Products p WHERE p.user.idUser = :userId";
        TypedQuery<Products> query = entityManager.createQuery(jpql, Products.class);
        query.setParameter("userId", userId);
        return query.getResultList();
    }

    public Products findByBarcode(Long barcode) {
        String jpql = "SELECT p FROM Products p WHERE p.barcode = :barcode";
        try {
            return entityManager.createQuery(jpql, Products.class)
                                .setParameter("barcode", barcode)
                                .getSingleResult();
        } catch (NoResultException e) {
            return null; // Or handle differently if no product is found
        }
    }
}
