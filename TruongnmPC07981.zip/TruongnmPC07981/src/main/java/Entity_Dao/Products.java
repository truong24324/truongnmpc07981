package Entity_Dao;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "PRODUCTS")
public class Products {

    @Id
    @Column(name = "ID_PRO", length = 20)
    private String idPro;

    @ManyToOne
    @JoinColumn(name = "ID_USER", referencedColumnName = "ID_USER")
    private User user;

    @Column(name = "NAME_PRO", length = 255, nullable = false)
    private String namePro;

    @Temporal(TemporalType.DATE)
    @Column(name = "CREATION_DATE", nullable = false)
    private Date creationDate;

    @Column(name = "PRICE", nullable = false)
    private BigDecimal price;

    @Column(name = "IMAGE")
    private String image;

    @Column(name = "BARCODE")
    private Long barcode;

    // Constructors, getters and setters

    public Products() {
    }

    public Products(String idPro, User user, String namePro, Date creationDate, BigDecimal price, String image, Long barcode) {
        this.idPro = idPro;
        this.user = user;
        this.namePro = namePro;
        this.creationDate = creationDate;
        this.price = price;
        this.image = image;
        this.barcode = barcode;
    }

    public String getIdPro() {
        return idPro;
    }

    public void setIdPro(String idPro) {
        this.idPro = idPro;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getNamePro() {
        return namePro;
    }

    public void setNamePro(String namePro) {
        this.namePro = namePro;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Long getBarcode() {
        return barcode;
    }

    public void setBarcode(Long barcode) {
        this.barcode = barcode;
    }
}
