package Entity_Dao;


import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "USERS")
public class User {

    @Id
    @Column(name = "ID_USER", length = 20, nullable = false)
    private String idUser;

    @Column(name = "FULLNAME", length = 100, nullable = false)
    private String fullName;

    @Column(name = "PHONE", length = 10)
    private String phone;

    @Column(name = "ADDRESS", columnDefinition = "NVARCHAR(MAX)")
    private String address;

    @Column(name = "GENDER", length = 10)
    private String gender;

    @Column(name = "BRITHDAY")
    @Temporal(TemporalType.DATE)
    private Date birthday;

    @Column(name = "EMAIL", length = 100)
    private String email;

    @Column(name = "ROLE", length = 50)
    private String role;

    @Column(name = "IMAGE", columnDefinition = "NVARCHAR(MAX)")
    private String image;
    
    @Column(name = "PASSWORD", columnDefinition = "NVARCHAR(MAX)")
    private String password;
    
    @Column(name = "CONFIRMATION_CODE", length= 6)
    private String confirmation;

    // Getters and Setters

    public String getConfirmation() {
		return confirmation;
	}

	public void setConfirmation(String confirmation) {
		this.confirmation = confirmation;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIdUser() {
        return idUser;
    }

    public void setIdUser(String idUser) {
        this.idUser = idUser;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
