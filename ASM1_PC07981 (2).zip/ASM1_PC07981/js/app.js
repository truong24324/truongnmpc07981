const app = angular.module('AMS-PC07981', ["ngRoute"]);

app.config(function ($routeProvider) {
    $routeProvider
        .when("/Nav", {
            templateUrl: "./trangChu/Navbar.html",
        })
        .when("/Slide", {
            templateUrl: "./trangChu/Slide.html",
        })
        .when("/Option", {
            templateUrl: "./trangChu/Option.html",
        })
        .when("/ProductPrort", {
            templateUrl: "./trangChu/ProductPrort.html",
            controller: "TableProduct",
        })
        .when("/IMG", {
            templateUrl: "./trangChu/IMG.html",
        })
        .when("/Today", {
            templateUrl: "./trangChu/Today.html",
            controller: "TodayProduct",
        })
        .when("/Introduce", {
            templateUrl: "./trangChu/Introduce.html",
        })
        .when("/Category", {
            templateUrl: "./trangChu/Category.html",
        })
        .when("/Footer", {
            templateUrl: "./trangChu/footer.html",
        })
        .when("/LogUp", {
            templateUrl: "./miniNavBar/logUp.html",
        })
        .when("/LogIn", {
            templateUrl: "./miniNavBar/logIn.html",
        })
        .when("/help", {
            templateUrl: "./miniNavBar/help.html",
        })
        .when("/Notification", {
            templateUrl: "./miniNavBar/Notification.html",
        })
        .when("/home", {
            templateUrl: "./trangChu/home.html",
        })
        .when("/home2", {
            templateUrl: "./trangChu/home2.html",
        })
        .when("/Male", {
            templateUrl: "./trangChu/Male.html",
        })
        .when("/Female", {
            templateUrl: "./trangChu/Female.html",
        })
        .when("/Beauty", {
            templateUrl: "./trangChu/Beauty.html",
        })
        .when("/Information/:name", {
            templateUrl: "./trangChu/Information.html",
            controller: "InformationController",
        })

        .when("/cart", {
            templateUrl: "./trangChu/cart.html",
            controller: "CartController"
        })
        .otherwise({ redirectTo: '/home2' });
});

app.run(function ($rootScope) {
    $rootScope.$on('$routeChangeStart', function () {
        $rootScope.loading = true;
    });
    $rootScope.$on('$routeChangeSuccess', function () {
        $rootScope.loading = false;
    });
    $rootScope.$on('$routeChangeError', function () {
        $rootScope.loading = false;
        alert('Không thể tải dữ liệu');
    });
});

app.controller('NavController', function ($scope) {
    $scope.navSelected = false;

    $scope.selectNav = function () {
        $scope.navSelected = true;
    };
});

app.controller('selectController', function ($scope) {
    $scope.selected = false;

    $scope.select = function () {
        $scope.selected = true;
    };

    $scope.deselect = function () {
        $scope.selected = false;
    };
});

app.service('CartService', function () {
    var cart = [];

    this.addItem = function (product) {
        var found = false;
        for (var i = 0; i < cart.length; i++) {
            if (cart[i].name === product.name) {
                cart[i].quantity++;
                found = true;
                break;
            }
        }
        if (!found) {
            product.quantity = 1;
            cart.push(product);
        }
    };

    this.removeItem = function (index) {
        cart.splice(index, 1);
    };

    this.getCart = function () {
        return cart;
    };

    this.getTotal = function () {
        var total = 0;
        for (var i = 0; i < cart.length; i++) {
            total += cart[i].quantity * parseFloat(cart[i].price.replace(' VND', '').replace('.', ''));
        }
        return total;
    };
});

app.controller('TodayProduct', function ($scope, $http, $timeout, CartService) {
    $http({
        method: 'GET',
        url: 'http://localhost:3000/Today-Product'
    }).then(function successCallback(response) {
        $scope.products = response.data;
        $scope.searchQuery = ''; // Biến để lưu từ khóa tìm kiếm

        // Initialize the success message flags for each product after fetching the data
        $scope.products.forEach(product => {
            product.addedToCart = false;
        });

        $scope.searchProducts(); // Khởi tạo danh sách sản phẩm được lọc
    }, function errorCallback(response) {
        console.error('Lỗi khi lấy dữ liệu sản phẩm:', response);
    });

    $scope.addToCart = function (product) {
        CartService.addItem(product);
        product.addedToCart = true;

        // Hide the success message after 3 seconds
        $timeout(function () {
            product.addedToCart = false;
        }, 3000);
    };

    // Phương thức tìm kiếm sản phẩm
    $scope.searchProducts = function () {
        $scope.filteredProducts = $scope.products.filter(product => 
            product.name.toLowerCase().includes($scope.searchQuery.toLowerCase())
        );
    };

    // Theo dõi sự thay đổi của từ khóa tìm kiếm
    $scope.$watch('searchQuery', function (newVal, oldVal) {
        if (newVal !== oldVal) {
            $scope.searchProducts();
        }
    });
});



app.service('CartService', function () {
    var cart = [];

    this.addItem = function (product) {
        var found = false;
        for (var i = 0; i < cart.length; i++) {
            if (cart[i].name === product.name) {
                cart[i].quantity++;
                found = true;
                break;
            }
        }
        if (!found) {
            product.quantity = 1;
            cart.push(product);
        }
    };

    this.removeItem = function (index) {
        cart.splice(index, 1);
    };

    this.clearCart = function () {
        cart.length = 0;
    };

    this.getCart = function () {
        return cart;
    };

    this.getTotal = function () {
        var total = 0;
        for (var i = 0; i < cart.length; i++) {
            total += cart[i].quantity * parseFloat(cart[i].price.replace(' VND', '').replace('.', ''));
        }
        return total;
    };
});

app.controller('CartController', function ($scope, $timeout, CartService) {
    $scope.cart = CartService.getCart();
    $scope.cartCleared = false; // Flag to indicate cart was cleared
    $scope.updateTotal = function () {
        $scope.totalPrice = CartService.getTotal();
        $scope.emptyCart = ($scope.cart.length === 0);
        $scope.Carts = ($scope.cart.length > 0);
    };
    $scope.updateTotal();

    $scope.removeItem = function (index) {
        CartService.removeItem(index);
        $scope.updateTotal();
    };

    $scope.removeAll = function () {
        CartService.clearCart();
        $scope.updateTotal();
        $scope.cartCleared = true; // Set the flag to true when the cart is cleared
        $scope.emptyCart = false;
        // Hide the success message after 3 seconds
        $timeout(function () {
            $scope.cartCleared = false;
            $scope.emptyCart = true;
        }, 3000);
    };

  // Trong hàm CartController
$scope.submitOrder = function() {
    // Kiểm tra xem form có hợp lệ không
    if ($scope.orderForm.$valid) {
        // Hiển thị modal khi form hợp lệ
        $('#exampleModal').modal('show');
    }
}});










app.controller('TableProduct', function ($scope, $http) {
    $http({
        method: 'GET',
        url: 'http://localhost:3000/products-table'
    }).then(function successCallback(response) {
        $scope.products = response.data;
        $scope.pageSize = 6;
        $scope.currentPage = 0;
    }, function errorCallback(response) {
        console.error('Lỗi khi lấy dữ liệu sản phẩm:', response);
    });

    $scope.paginatedProducts = function () {
        const start = $scope.currentPage * $scope.pageSize;
        return $scope.products.slice(start, start + $scope.pageSize);
    };

    $scope.prevRow = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };

    $scope.nextRow = function () {
        if ($scope.currentPage < Math.ceil($scope.products.length / $scope.pageSize) - 1) {
            $scope.currentPage++;
        }
    };


});

app.controller('InformationController', function ($scope, $routeParams, $http, ProductService) {
    var name = $routeParams.name; // Lấy giá trị của tham số từ URL

    $http({
        method: 'GET',
        url: 'http://localhost:3000/products-table/' + name

    }).then(function successCallback(response) {
        $scope.product = response.data; // Gán dữ liệu của sản phẩm vào $scope.product
    }, function errorCallback(response) {
        console.error('Lỗi khi lấy dữ liệu sản phẩm:', response);
    });
});

app.controller('logIn', function($scope) {
    $scope.btnlogIn = function() {
        if ($scope.logInForm.$valid) {
            alert('Đăng nhập thành công');
            // Add your login logic here
        } else {
            alert('Vui lòng điền đầy đủ thông tin');
        }
    };
});

app.controller('logUp', function($scope) {
    $scope.btnlogIn = function() {
        if ($scope.logInForm.$valid) {
            alert('Đăng nhập thành công');
            // Add your login logic here
        } else {
            alert('Vui lòng điền đầy đủ thông tin');
        }
    };
});
